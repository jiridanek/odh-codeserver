# Installation
> `npm install --save @types/p-all`

# Summary
This package contains type definitions for p-all (https://github.com/sindresorhus/p-all#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/p-all

Additional Details
 * Last updated: Thu, 03 Aug 2017 13:57:01 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
