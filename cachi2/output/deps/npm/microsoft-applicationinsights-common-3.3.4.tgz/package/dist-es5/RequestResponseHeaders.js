/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { createValueMap } from "@microsoft/applicationinsights-core-js";
export var RequestHeaders = createValueMap({
    requestContextHeader: [0 /* eRequestHeaders.requestContextHeader */, "Request-Context"],
    requestContextTargetKey: [1 /* eRequestHeaders.requestContextTargetKey */, "appId"],
    requestContextAppIdFormat: [2 /* eRequestHeaders.requestContextAppIdFormat */, "appId=cid-v1:"],
    requestIdHeader: [3 /* eRequestHeaders.requestIdHeader */, "Request-Id"],
    traceParentHeader: [4 /* eRequestHeaders.traceParentHeader */, "traceparent"],
    traceStateHeader: [5 /* eRequestHeaders.traceStateHeader */, "tracestate"],
    sdkContextHeader: [6 /* eRequestHeaders.sdkContextHeader */, "Sdk-Context"],
    sdkContextHeaderAppIdRequest: [7 /* eRequestHeaders.sdkContextHeaderAppIdRequest */, "appId"],
    requestContextHeaderLowerCase: [8 /* eRequestHeaders.requestContextHeaderLowerCase */, "request-context"]
});
//# sourceMappingURL=RequestResponseHeaders.js.map