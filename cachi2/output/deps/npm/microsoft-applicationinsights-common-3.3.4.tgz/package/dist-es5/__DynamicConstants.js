/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_SPLIT = "split"; // Count: 6
export var _DYN_LENGTH = "length"; // Count: 41
export var _DYN_TO_LOWER_CASE = "toLowerCase"; // Count: 6
export var _DYN_INGESTIONENDPOINT = "ingestionendpoint"; // Count: 6
export var _DYN_TO_STRING = "toString"; // Count: 9
export var _DYN_PUSH = "push"; // Count: 5
export var _DYN_REMOVE_ITEM = "removeItem"; // Count: 3
export var _DYN_NAME = "name"; // Count: 11
export var _DYN_MESSAGE = "message"; // Count: 10
export var _DYN_COUNT = "count"; // Count: 8
export var _DYN_PRE_TRIGGER_DATE = "preTriggerDate"; // Count: 4
export var _DYN_DISABLED = "disabled"; // Count: 3
export var _DYN_INTERVAL = "interval"; // Count: 3
export var _DYN_DAYS_OF_MONTH = "daysOfMonth"; // Count: 3
export var _DYN_DATE = "date"; // Count: 5
export var _DYN_GET_UTCDATE = "getUTCDate"; // Count: 3
export var _DYN_STRINGIFY = "stringify"; // Count: 4
export var _DYN_PATHNAME = "pathname"; // Count: 4
export var _DYN_CORRELATION_HEADER_E0 = "correlationHeaderExcludePatterns"; // Count: 2
export var _DYN_EXTENSION_CONFIG = "extensionConfig"; // Count: 4
export var _DYN_EXCEPTIONS = "exceptions"; // Count: 6
export var _DYN_PARSED_STACK = "parsedStack"; // Count: 13
export var _DYN_PROPERTIES = "properties"; // Count: 9
export var _DYN_MEASUREMENTS = "measurements"; // Count: 9
export var _DYN_SIZE_IN_BYTES = "sizeInBytes"; // Count: 11
export var _DYN_TYPE_NAME = "typeName"; // Count: 11
export var _DYN_SEVERITY_LEVEL = "severityLevel"; // Count: 5
export var _DYN_PROBLEM_GROUP = "problemGroup"; // Count: 3
export var _DYN_IS_MANUAL = "isManual"; // Count: 3
export var _DYN__CREATE_FROM_INTERFA1 = "CreateFromInterface"; // Count: 2
export var _DYN_ASSEMBLY = "assembly"; // Count: 7
export var _DYN_FILE_NAME = "fileName"; // Count: 8
export var _DYN_HAS_FULL_STACK = "hasFullStack"; // Count: 6
export var _DYN_LEVEL = "level"; // Count: 5
export var _DYN_METHOD = "method"; // Count: 7
export var _DYN_LINE = "line"; // Count: 6
export var _DYN_DURATION = "duration"; // Count: 4
export var _DYN_RECEIVED_RESPONSE = "receivedResponse"; // Count: 2
//# sourceMappingURL=__DynamicConstants.js.map