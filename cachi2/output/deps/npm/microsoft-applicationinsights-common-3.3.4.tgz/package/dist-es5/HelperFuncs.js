/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { arrForEach, isString } from "@microsoft/applicationinsights-core-js";
import { _DYN_LENGTH, _DYN_TO_LOWER_CASE } from "./__DynamicConstants";
var strEmpty = "";
export function stringToBoolOrDefault(str, defaultValue) {
    if (defaultValue === void 0) { defaultValue = false; }
    if (str === undefined || str === null) {
        return defaultValue;
    }
    return str.toString()[_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]() === "true";
}
/**
 * Convert ms to c# time span format
 */
export function msToTimeSpan(totalms) {
    if (isNaN(totalms) || totalms < 0) {
        totalms = 0;
    }
    totalms = Math.round(totalms);
    var ms = strEmpty + totalms % 1000;
    var sec = strEmpty + Math.floor(totalms / 1000) % 60;
    var min = strEmpty + Math.floor(totalms / (1000 * 60)) % 60;
    var hour = strEmpty + Math.floor(totalms / (1000 * 60 * 60)) % 24;
    var days = Math.floor(totalms / (1000 * 60 * 60 * 24));
    ms = ms[_DYN_LENGTH /* @min:%2elength */] === 1 ? "00" + ms : ms[_DYN_LENGTH /* @min:%2elength */] === 2 ? "0" + ms : ms;
    sec = sec[_DYN_LENGTH /* @min:%2elength */] < 2 ? "0" + sec : sec;
    min = min[_DYN_LENGTH /* @min:%2elength */] < 2 ? "0" + min : min;
    hour = hour[_DYN_LENGTH /* @min:%2elength */] < 2 ? "0" + hour : hour;
    return (days > 0 ? days + "." : strEmpty) + hour + ":" + min + ":" + sec + "." + ms;
}
export function getExtensionByName(extensions, identifier) {
    var extension = null;
    arrForEach(extensions, function (value) {
        if (value.identifier === identifier) {
            extension = value;
            return -1;
        }
    });
    return extension;
}
export function isCrossOriginError(message, url, lineNumber, columnNumber, error) {
    return !error && isString(message) && (message === "Script error." || message === "Script error");
}
//# sourceMappingURL=HelperFuncs.js.map