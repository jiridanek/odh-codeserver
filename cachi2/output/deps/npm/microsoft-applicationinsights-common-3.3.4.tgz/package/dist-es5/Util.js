/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { arrForEach, arrIndexOf, dateNow, getPerformance, isNullOrUndefined, isValidSpanId, isValidTraceId } from "@microsoft/applicationinsights-core-js";
import { strIndexOf } from "@nevware21/ts-utils";
import { DEFAULT_BREEZE_ENDPOINT, DEFAULT_BREEZE_PATH } from "./Constants";
import { RequestHeaders } from "./RequestResponseHeaders";
import { dataSanitizeString } from "./Telemetry/Common/DataSanitizer";
import { urlParseFullHost, urlParseUrl } from "./UrlHelperFuncs";
import { _DYN_CORRELATION_HEADER_E0, _DYN_LENGTH, _DYN_NAME, _DYN_PATHNAME, _DYN_SPLIT, _DYN_TO_LOWER_CASE } from "./__DynamicConstants";
// listing only non-geo specific locations
var _internalEndpoints = [
    DEFAULT_BREEZE_ENDPOINT + DEFAULT_BREEZE_PATH,
    "https://breeze.aimon.applicationinsights.io" + DEFAULT_BREEZE_PATH,
    "https://dc-int.services.visualstudio.com" + DEFAULT_BREEZE_PATH
];
var _correlationIdPrefix = "cid-v1:";
export function isInternalApplicationInsightsEndpoint(endpointUrl) {
    return arrIndexOf(_internalEndpoints, endpointUrl[_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]()) !== -1;
}
export function correlationIdSetPrefix(prefix) {
    _correlationIdPrefix = prefix;
}
export function correlationIdGetPrefix() {
    return _correlationIdPrefix;
}
/**
 * Checks if a request url is not on a excluded domain list and if it is safe to add correlation headers.
 * Headers are always included if the current domain matches the request domain. If they do not match (CORS),
 * they are regex-ed across correlationHeaderDomains and correlationHeaderExcludedDomains to determine if headers are included.
 * Some environments don't give information on currentHost via window.location.host (e.g. Cordova). In these cases, the user must
 * manually supply domains to include correlation headers on. Else, no headers will be included at all.
 */
export function correlationIdCanIncludeCorrelationHeader(config, requestUrl, currentHost) {
    if (!requestUrl || (config && config.disableCorrelationHeaders)) {
        return false;
    }
    if (config && config[_DYN_CORRELATION_HEADER_E0 /* @min:%2ecorrelationHeaderExcludePatterns */]) {
        for (var i = 0; i < config.correlationHeaderExcludePatterns[_DYN_LENGTH /* @min:%2elength */]; i++) {
            if (config[_DYN_CORRELATION_HEADER_E0 /* @min:%2ecorrelationHeaderExcludePatterns */][i].test(requestUrl)) {
                return false;
            }
        }
    }
    var requestHost = urlParseUrl(requestUrl).host[_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]();
    if (requestHost && (strIndexOf(requestHost, ":443") !== -1 || strIndexOf(requestHost, ":80") !== -1)) {
        // [Bug #1260] IE can include the port even for http and https URLs so if present
        // try and parse it to remove if it matches the default protocol port
        requestHost = (urlParseFullHost(requestUrl, true) || "")[_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]();
    }
    if ((!config || !config.enableCorsCorrelation) && (requestHost && requestHost !== currentHost)) {
        return false;
    }
    var includedDomains = config && config.correlationHeaderDomains;
    if (includedDomains) {
        var matchExists_1;
        arrForEach(includedDomains, function (domain) {
            var regex = new RegExp(domain.toLowerCase().replace(/\\/g, "\\\\").replace(/\./g, "\\.").replace(/\*/g, ".*"));
            matchExists_1 = matchExists_1 || regex.test(requestHost);
        });
        if (!matchExists_1) {
            return false;
        }
    }
    var excludedDomains = config && config.correlationHeaderExcludedDomains;
    if (!excludedDomains || excludedDomains[_DYN_LENGTH /* @min:%2elength */] === 0) {
        return true;
    }
    for (var i = 0; i < excludedDomains[_DYN_LENGTH /* @min:%2elength */]; i++) {
        var regex = new RegExp(excludedDomains[i].toLowerCase().replace(/\\/g, "\\\\").replace(/\./g, "\\.").replace(/\*/g, ".*"));
        if (regex.test(requestHost)) {
            return false;
        }
    }
    // if we don't know anything about the requestHost, require the user to use included/excludedDomains.
    // Previously we always returned false for a falsy requestHost
    return requestHost && requestHost[_DYN_LENGTH /* @min:%2elength */] > 0;
}
/**
 * Combines target appId and target role name from response header.
 */
export function correlationIdGetCorrelationContext(responseHeader) {
    if (responseHeader) {
        var correlationId = correlationIdGetCorrelationContextValue(responseHeader, RequestHeaders[1 /* eRequestHeaders.requestContextTargetKey */]);
        if (correlationId && correlationId !== _correlationIdPrefix) {
            return correlationId;
        }
    }
}
/**
 * Gets key from correlation response header
 */
export function correlationIdGetCorrelationContextValue(responseHeader, key) {
    if (responseHeader) {
        var keyValues = responseHeader[_DYN_SPLIT /* @min:%2esplit */](",");
        for (var i = 0; i < keyValues[_DYN_LENGTH /* @min:%2elength */]; ++i) {
            var keyValue = keyValues[i][_DYN_SPLIT /* @min:%2esplit */]("=");
            if (keyValue[_DYN_LENGTH /* @min:%2elength */] === 2 && keyValue[0] === key) {
                return keyValue[1];
            }
        }
    }
}
export function AjaxHelperParseDependencyPath(logger, absoluteUrl, method, commandName) {
    var target, name = commandName, data = commandName;
    if (absoluteUrl && absoluteUrl[_DYN_LENGTH /* @min:%2elength */] > 0) {
        var parsedUrl = urlParseUrl(absoluteUrl);
        target = parsedUrl.host;
        if (!name) {
            if (parsedUrl[_DYN_PATHNAME /* @min:%2epathname */] != null) {
                var pathName = (parsedUrl.pathname[_DYN_LENGTH /* @min:%2elength */] === 0) ? "/" : parsedUrl[_DYN_PATHNAME /* @min:%2epathname */];
                if (pathName.charAt(0) !== "/") {
                    pathName = "/" + pathName;
                }
                data = parsedUrl[_DYN_PATHNAME /* @min:%2epathname */];
                name = dataSanitizeString(logger, method ? method + " " + pathName : pathName);
            }
            else {
                name = dataSanitizeString(logger, absoluteUrl);
            }
        }
    }
    else {
        target = commandName;
        name = commandName;
    }
    return {
        target: target,
        name: name,
        data: data
    };
}
export function dateTimeUtilsNow() {
    // returns the window or webworker performance object
    var perf = getPerformance();
    if (perf && perf.now && perf.timing) {
        var now = perf.now() + perf.timing.navigationStart;
        // Known issue with IE where this calculation can be negative, so if it is then ignore and fallback
        if (now > 0) {
            return now;
        }
    }
    return dateNow();
}
export function dateTimeUtilsDuration(start, end) {
    var result = null;
    if (start !== 0 && end !== 0 && !isNullOrUndefined(start) && !isNullOrUndefined(end)) {
        result = end - start;
    }
    return result;
}
/**
 * Creates a IDistributedTraceContext from an optional telemetryTrace
 * @param telemetryTrace - The telemetryTrace instance that is being wrapped
 * @param parentCtx - An optional parent distributed trace instance, almost always undefined as this scenario is only used in the case of multiple property handlers.
 * @returns A new IDistributedTraceContext instance that is backed by the telemetryTrace or temporary object
 */
export function createDistributedTraceContextFromTrace(telemetryTrace, parentCtx) {
    var trace = telemetryTrace || {};
    return {
        getName: function () {
            return trace[_DYN_NAME /* @min:%2ename */];
        },
        setName: function (newValue) {
            parentCtx && parentCtx.setName(newValue);
            trace[_DYN_NAME /* @min:%2ename */] = newValue;
        },
        getTraceId: function () {
            return trace.traceID;
        },
        setTraceId: function (newValue) {
            parentCtx && parentCtx.setTraceId(newValue);
            if (isValidTraceId(newValue)) {
                trace.traceID = newValue;
            }
        },
        getSpanId: function () {
            return trace.parentID;
        },
        setSpanId: function (newValue) {
            parentCtx && parentCtx.setSpanId(newValue);
            if (isValidSpanId(newValue)) {
                trace.parentID = newValue;
            }
        },
        getTraceFlags: function () {
            return trace.traceFlags;
        },
        setTraceFlags: function (newTraceFlags) {
            parentCtx && parentCtx.setTraceFlags(newTraceFlags);
            trace.traceFlags = newTraceFlags;
        }
    };
}
//# sourceMappingURL=Util.js.map