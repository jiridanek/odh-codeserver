/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */

// Licensed under the
export { correlationIdSetPrefix, correlationIdGetPrefix, correlationIdCanIncludeCorrelationHeader, correlationIdGetCorrelationContext, correlationIdGetCorrelationContextValue, dateTimeUtilsNow, dateTimeUtilsDuration, isInternalApplicationInsightsEndpoint, createDistributedTraceContextFromTrace } from "./Util";
export { ThrottleMgr } from "./ThrottleMgr";
export { parseConnectionString, ConnectionStringParser } from "./ConnectionStringParser";
export { RequestHeaders } from "./RequestResponseHeaders";
export { DisabledPropertyName, ProcessLegacy, SampleRate, HttpMethod, DEFAULT_BREEZE_ENDPOINT, DEFAULT_BREEZE_PATH, strNotSpecified } from "./Constants";
export { Envelope } from "./Telemetry/Common/Envelope";
export { Event } from "./Telemetry/Event";
export { Exception } from "./Telemetry/Exception";
export { Metric } from "./Telemetry/Metric";
export { PageView } from "./Telemetry/PageView";
export { RemoteDependencyData } from "./Telemetry/RemoteDependencyData";
export { Trace } from "./Telemetry/Trace";
export { PageViewPerformance } from "./Telemetry/PageViewPerformance";
export { Data } from "./Telemetry/Common/Data";
export { SeverityLevel } from "./Interfaces/Contracts/SeverityLevel";
export { ConfigurationManager } from "./Interfaces/IConfig";
export { ContextTagKeys } from "./Interfaces/Contracts/ContextTagKeys";
export { dataSanitizeKeyAndAddUniqueness, dataSanitizeKey, dataSanitizeString, dataSanitizeUrl, dataSanitizeMessage, dataSanitizeException, dataSanitizeProperties, dataSanitizeMeasurements, dataSanitizeId, dataSanitizeInput, dsPadNumber } from "./Telemetry/Common/DataSanitizer";
export { TelemetryItemCreator, createTelemetryItem } from "./TelemetryItemCreator";
export { CtxTagKeys, Extensions } from "./Interfaces/PartAExtensions";
export { DistributedTracingModes, EventPersistence } from "./Enums";
export { stringToBoolOrDefault, msToTimeSpan, getExtensionByName, isCrossOriginError } from "./HelperFuncs";
export { isBeaconsSupported as isBeaconApiSupported, createTraceParent, parseTraceParent, isValidTraceId, isValidSpanId, isValidTraceParent, isSampledFlag, formatTraceParent, findW3cTraceParent, findAllScripts } from "@microsoft/applicationinsights-core-js";
export { createDomEvent } from "./DomHelperFuncs";
export { utlDisableStorage, utlEnableStorage, utlCanUseLocalStorage, utlGetLocalStorage, utlSetLocalStorage, utlRemoveStorage, utlCanUseSessionStorage, utlGetSessionStorageKeys, utlGetSessionStorage, utlSetSessionStorage, utlRemoveSessionStorage, utlSetStoragePrefix } from "./StorageHelperFuncs";
export { urlParseUrl, urlGetAbsoluteUrl, urlGetPathName, urlGetCompleteUrl, urlParseHost, urlParseFullHost } from "./UrlHelperFuncs";
export { createOfflineListener } from "./Offline";
export var PropertiesPluginIdentifier = "AppInsightsPropertiesPlugin";
export var BreezeChannelIdentifier = "AppInsightsChannelPlugin";
export var AnalyticsPluginIdentifier = "ApplicationInsightsAnalytics";
//# sourceMappingURL=applicationinsights-common.js.map