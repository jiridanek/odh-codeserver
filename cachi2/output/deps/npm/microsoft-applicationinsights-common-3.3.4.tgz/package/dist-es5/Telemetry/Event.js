/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { strNotSpecified } from "../Constants";
import { _DYN_MEASUREMENTS, _DYN_NAME, _DYN_PROPERTIES } from "../__DynamicConstants";
import { dataSanitizeMeasurements, dataSanitizeProperties, dataSanitizeString } from "./Common/DataSanitizer";
var Event = /** @class */ (function () {
    /**
     * Constructs a new instance of the EventTelemetry object
     */
    function Event(logger, name, properties, measurements) {
        this.aiDataContract = {
            ver: 1 /* FieldType.Required */,
            name: 1 /* FieldType.Required */,
            properties: 0 /* FieldType.Default */,
            measurements: 0 /* FieldType.Default */
        };
        var _self = this;
        _self.ver = 2;
        _self[_DYN_NAME /* @min:%2ename */] = dataSanitizeString(logger, name) || strNotSpecified;
        _self[_DYN_PROPERTIES /* @min:%2eproperties */] = dataSanitizeProperties(logger, properties);
        _self[_DYN_MEASUREMENTS /* @min:%2emeasurements */] = dataSanitizeMeasurements(logger, measurements);
    }
    Event.envelopeType = "Microsoft.ApplicationInsights.{0}.Event";
    Event.dataType = "EventData";
    return Event;
}());
export { Event };
//# sourceMappingURL=Event.js.map