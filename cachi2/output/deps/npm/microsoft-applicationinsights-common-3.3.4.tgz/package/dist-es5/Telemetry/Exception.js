/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { __assignFn as __assign } from "@microsoft/applicationinsights-shims";
import { arrForEach, arrMap, isArray, isError, isFunction, isNullOrUndefined, isObject, isString, strTrim } from "@microsoft/applicationinsights-core-js";
import { getWindow, strIndexOf } from "@nevware21/ts-utils";
import { strNotSpecified } from "../Constants";
import { _DYN_ASSEMBLY, _DYN_EXCEPTIONS, _DYN_FILE_NAME, _DYN_HAS_FULL_STACK, _DYN_IS_MANUAL, _DYN_LENGTH, _DYN_LEVEL, _DYN_LINE, _DYN_MEASUREMENTS, _DYN_MESSAGE, _DYN_METHOD, _DYN_NAME, _DYN_PARSED_STACK, _DYN_PROBLEM_GROUP, _DYN_PROPERTIES, _DYN_PUSH, _DYN_SEVERITY_LEVEL, _DYN_SIZE_IN_BYTES, _DYN_SPLIT, _DYN_STRINGIFY, _DYN_TO_STRING, _DYN_TYPE_NAME, _DYN__CREATE_FROM_INTERFA1 } from "../__DynamicConstants";
import { dataSanitizeException, dataSanitizeMeasurements, dataSanitizeMessage, dataSanitizeProperties, dataSanitizeString } from "./Common/DataSanitizer";
var NoMethod = "<no_method>";
var strError = "error";
var strStack = "stack";
var strStackDetails = "stackDetails";
var strErrorSrc = "errorSrc";
var strMessage = "message";
var strDescription = "description";
function _stringify(value, convertToString) {
    var result = value;
    if (result && !isString(result)) {
        if (JSON && JSON[_DYN_STRINGIFY /* @min:%2estringify */]) {
            result = JSON[_DYN_STRINGIFY /* @min:%2estringify */](value);
            if (convertToString && (!result || result === "{}")) {
                if (isFunction(value[_DYN_TO_STRING /* @min:%2etoString */])) {
                    result = value[_DYN_TO_STRING /* @min:%2etoString */]();
                }
                else {
                    result = "" + value;
                }
            }
        }
        else {
            result = "" + value + " - (Missing JSON.stringify)";
        }
    }
    return result || "";
}
function _formatMessage(theEvent, errorType) {
    var evtMessage = theEvent;
    if (theEvent) {
        if (evtMessage && !isString(evtMessage)) {
            evtMessage = theEvent[strMessage] || theEvent[strDescription] || evtMessage;
        }
        // Make sure the message is a string
        if (evtMessage && !isString(evtMessage)) {
            // tslint:disable-next-line: prefer-conditional-expression
            evtMessage = _stringify(evtMessage, true);
        }
        if (theEvent["filename"]) {
            // Looks like an event object with filename
            evtMessage = evtMessage + " @" + (theEvent["filename"] || "") + ":" + (theEvent["lineno"] || "?") + ":" + (theEvent["colno"] || "?");
        }
    }
    // Automatically add the error type to the message if it does already appear to be present
    if (errorType && errorType !== "String" && errorType !== "Object" && errorType !== "Error" && strIndexOf(evtMessage || "", errorType) === -1) {
        evtMessage = errorType + ": " + evtMessage;
    }
    return evtMessage || "";
}
function _isExceptionDetailsInternal(value) {
    try {
        if (isObject(value)) {
            return "hasFullStack" in value && "typeName" in value;
        }
    }
    catch (e) {
        // This can happen with some native browser objects, but should not happen for the type we are checking for
    }
    return false;
}
function _isExceptionInternal(value) {
    try {
        if (isObject(value)) {
            return ("ver" in value && "exceptions" in value && "properties" in value);
        }
    }
    catch (e) {
        // This can happen with some native browser objects, but should not happen for the type we are checking for
    }
    return false;
}
function _isStackDetails(details) {
    return details && details.src && isString(details.src) && details.obj && isArray(details.obj);
}
function _convertStackObj(errorStack) {
    var src = errorStack || "";
    if (!isString(src)) {
        if (isString(src[strStack])) {
            src = src[strStack];
        }
        else {
            src = "" + src;
        }
    }
    var items = src[_DYN_SPLIT /* @min:%2esplit */]("\n");
    return {
        src: src,
        obj: items
    };
}
function _getOperaStack(errorMessage) {
    var stack = [];
    var lines = errorMessage[_DYN_SPLIT /* @min:%2esplit */]("\n");
    for (var lp = 0; lp < lines[_DYN_LENGTH /* @min:%2elength */]; lp++) {
        var entry = lines[lp];
        if (lines[lp + 1]) {
            entry += "@" + lines[lp + 1];
            lp++;
        }
        stack[_DYN_PUSH /* @min:%2epush */](entry);
    }
    return {
        src: errorMessage,
        obj: stack
    };
}
function _getStackFromErrorObj(errorObj) {
    var details = null;
    if (errorObj) {
        try {
            /* Using bracket notation is support older browsers (IE 7/8 -- dont remember the version) that throw when using dot
            notation for undefined objects and we don't want to loose the error from being reported */
            if (errorObj[strStack]) {
                // Chrome/Firefox
                details = _convertStackObj(errorObj[strStack]);
            }
            else if (errorObj[strError] && errorObj[strError][strStack]) {
                // Edge error event provides the stack and error object
                details = _convertStackObj(errorObj[strError][strStack]);
            }
            else if (errorObj["exception"] && errorObj.exception[strStack]) {
                details = _convertStackObj(errorObj.exception[strStack]);
            }
            else if (_isStackDetails(errorObj)) {
                details = errorObj;
            }
            else if (_isStackDetails(errorObj[strStackDetails])) {
                details = errorObj[strStackDetails];
            }
            else if (getWindow() && getWindow()["opera"] && errorObj[strMessage]) {
                // Opera
                details = _getOperaStack(errorObj[_DYN_MESSAGE /* @min:%2emessage */]);
            }
            else if (errorObj["reason"] && errorObj.reason[strStack]) {
                // UnhandledPromiseRejection
                details = _convertStackObj(errorObj.reason[strStack]);
            }
            else if (isString(errorObj)) {
                details = _convertStackObj(errorObj);
            }
            else {
                var evtMessage = errorObj[strMessage] || errorObj[strDescription] || "";
                if (isString(errorObj[strErrorSrc])) {
                    if (evtMessage) {
                        evtMessage += "\n";
                    }
                    evtMessage += " from " + errorObj[strErrorSrc];
                }
                if (evtMessage) {
                    details = _convertStackObj(evtMessage);
                }
            }
        }
        catch (e) {
            // something unexpected happened so to avoid failing to report any error lets swallow the exception
            // and fallback to the callee/caller method
            details = _convertStackObj(e);
        }
    }
    return details || {
        src: "",
        obj: null
    };
}
function _formatStackTrace(stackDetails) {
    var stack = "";
    if (stackDetails) {
        if (stackDetails.obj) {
            arrForEach(stackDetails.obj, function (entry) {
                stack += entry + "\n";
            });
        }
        else {
            stack = stackDetails.src || "";
        }
    }
    return stack;
}
function _parseStack(stack) {
    var parsedStack;
    var frames = stack.obj;
    if (frames && frames[_DYN_LENGTH /* @min:%2elength */] > 0) {
        parsedStack = [];
        var level_1 = 0;
        var totalSizeInBytes_1 = 0;
        arrForEach(frames, function (frame) {
            var theFrame = frame[_DYN_TO_STRING /* @min:%2etoString */]();
            if (_StackFrame.regex.test(theFrame)) {
                var parsedFrame = new _StackFrame(theFrame, level_1++);
                totalSizeInBytes_1 += parsedFrame[_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */];
                parsedStack[_DYN_PUSH /* @min:%2epush */](parsedFrame);
            }
        });
        // DP Constraint - exception parsed stack must be < 32KB
        // remove frames from the middle to meet the threshold
        var exceptionParsedStackThreshold = 32 * 1024;
        if (totalSizeInBytes_1 > exceptionParsedStackThreshold) {
            var left = 0;
            var right = parsedStack[_DYN_LENGTH /* @min:%2elength */] - 1;
            var size = 0;
            var acceptedLeft = left;
            var acceptedRight = right;
            while (left < right) {
                // check size
                var lSize = parsedStack[left][_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */];
                var rSize = parsedStack[right][_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */];
                size += lSize + rSize;
                if (size > exceptionParsedStackThreshold) {
                    // remove extra frames from the middle
                    var howMany = acceptedRight - acceptedLeft + 1;
                    parsedStack.splice(acceptedLeft, howMany);
                    break;
                }
                // update pointers
                acceptedLeft = left;
                acceptedRight = right;
                left++;
                right--;
            }
        }
    }
    return parsedStack;
}
function _getErrorType(errorType) {
    // Gets the Error Type by passing the constructor (used to get the true type of native error object).
    var typeName = "";
    if (errorType) {
        typeName = errorType.typeName || errorType[_DYN_NAME /* @min:%2ename */] || "";
        if (!typeName) {
            try {
                var funcNameRegex = /function (.{1,200})\(/;
                var results = (funcNameRegex).exec((errorType).constructor[_DYN_TO_STRING /* @min:%2etoString */]());
                typeName = (results && results[_DYN_LENGTH /* @min:%2elength */] > 1) ? results[1] : "";
            }
            catch (e) {
                // eslint-disable-next-line no-empty -- Ignoring any failures as nothing we can do
            }
        }
    }
    return typeName;
}
/**
 * Formats the provided errorObj for display and reporting, it may be a String, Object, integer or undefined depending on the browser.
 * @param errorObj - The supplied errorObj
 */
export function _formatErrorCode(errorObj) {
    if (errorObj) {
        try {
            if (!isString(errorObj)) {
                var errorType = _getErrorType(errorObj);
                var result = _stringify(errorObj, false);
                if (!result || result === "{}") {
                    if (errorObj[strError]) {
                        // Looks like an MS Error Event
                        errorObj = errorObj[strError];
                        errorType = _getErrorType(errorObj);
                    }
                    result = _stringify(errorObj, true);
                }
                if (strIndexOf(result, errorType) !== 0 && errorType !== "String") {
                    return errorType + ":" + result;
                }
                return result;
            }
        }
        catch (e) {
            // eslint-disable-next-line no-empty -- Ignoring any failures as nothing we can do
        }
    }
    // Fallback to just letting the object format itself into a string
    return "" + (errorObj || "");
}
var Exception = /** @class */ (function () {
    /**
     * Constructs a new instance of the ExceptionTelemetry object
     */
    function Exception(logger, exception, properties, measurements, severityLevel, id) {
        this.aiDataContract = {
            ver: 1 /* FieldType.Required */,
            exceptions: 1 /* FieldType.Required */,
            severityLevel: 0 /* FieldType.Default */,
            properties: 0 /* FieldType.Default */,
            measurements: 0 /* FieldType.Default */
        };
        var _self = this;
        _self.ver = 2; // TODO: handle the CS"4.0" ==> breeze 2 conversion in a better way
        if (!_isExceptionInternal(exception)) {
            if (!properties) {
                properties = {};
            }
            if (id) {
                properties.id = id;
            }
            _self[_DYN_EXCEPTIONS /* @min:%2eexceptions */] = [new _ExceptionDetails(logger, exception, properties)];
            _self[_DYN_PROPERTIES /* @min:%2eproperties */] = dataSanitizeProperties(logger, properties);
            _self[_DYN_MEASUREMENTS /* @min:%2emeasurements */] = dataSanitizeMeasurements(logger, measurements);
            if (severityLevel) {
                _self[_DYN_SEVERITY_LEVEL /* @min:%2eseverityLevel */] = severityLevel;
            }
            if (id) {
                _self.id = id;
            }
        }
        else {
            _self[_DYN_EXCEPTIONS /* @min:%2eexceptions */] = exception[_DYN_EXCEPTIONS /* @min:%2eexceptions */] || [];
            _self[_DYN_PROPERTIES /* @min:%2eproperties */] = exception[_DYN_PROPERTIES /* @min:%2eproperties */];
            _self[_DYN_MEASUREMENTS /* @min:%2emeasurements */] = exception[_DYN_MEASUREMENTS /* @min:%2emeasurements */];
            if (exception[_DYN_SEVERITY_LEVEL /* @min:%2eseverityLevel */]) {
                _self[_DYN_SEVERITY_LEVEL /* @min:%2eseverityLevel */] = exception[_DYN_SEVERITY_LEVEL /* @min:%2eseverityLevel */];
            }
            if (exception.id) {
                _self.id = exception.id;
                exception[_DYN_PROPERTIES /* @min:%2eproperties */].id = exception.id;
            }
            if (exception[_DYN_PROBLEM_GROUP /* @min:%2eproblemGroup */]) {
                _self[_DYN_PROBLEM_GROUP /* @min:%2eproblemGroup */] = exception[_DYN_PROBLEM_GROUP /* @min:%2eproblemGroup */];
            }
            // bool/int types, use isNullOrUndefined
            if (!isNullOrUndefined(exception[_DYN_IS_MANUAL /* @min:%2eisManual */])) {
                _self[_DYN_IS_MANUAL /* @min:%2eisManual */] = exception[_DYN_IS_MANUAL /* @min:%2eisManual */];
            }
        }
    }
    Exception.CreateAutoException = function (message, url, lineNumber, columnNumber, error, evt, stack, errorSrc) {
        var _a;
        var errorType = _getErrorType(error || evt || message);
        return _a = {},
            _a[_DYN_MESSAGE /* @min:message */] = _formatMessage(message, errorType),
            _a.url = url,
            _a.lineNumber = lineNumber,
            _a.columnNumber = columnNumber,
            _a.error = _formatErrorCode(error || evt || message),
            _a.evt = _formatErrorCode(evt || message),
            _a[_DYN_TYPE_NAME /* @min:typeName */] = errorType,
            _a.stackDetails = _getStackFromErrorObj(stack || error || evt),
            _a.errorSrc = errorSrc,
            _a;
    };
    Exception.CreateFromInterface = function (logger, exception, properties, measurements) {
        var exceptions = exception[_DYN_EXCEPTIONS /* @min:%2eexceptions */]
            && arrMap(exception[_DYN_EXCEPTIONS /* @min:%2eexceptions */], function (ex) { return _ExceptionDetails[_DYN__CREATE_FROM_INTERFA1 /* @min:%2eCreateFromInterface */](logger, ex); });
        var exceptionData = new Exception(logger, __assign(__assign({}, exception), { exceptions: exceptions }), properties, measurements);
        return exceptionData;
    };
    Exception.prototype.toInterface = function () {
        var _a;
        var _b = this, exceptions = _b.exceptions, properties = _b.properties, measurements = _b.measurements, severityLevel = _b.severityLevel, problemGroup = _b.problemGroup, id = _b.id, isManual = _b.isManual;
        var exceptionDetailsInterface = exceptions instanceof Array
            && arrMap(exceptions, function (exception) { return exception.toInterface(); })
            || undefined;
        return _a = {
                ver: "4.0"
            },
            _a[_DYN_EXCEPTIONS /* @min:exceptions */] = exceptionDetailsInterface,
            _a.severityLevel = severityLevel,
            _a.properties = properties,
            _a.measurements = measurements,
            _a.problemGroup = problemGroup,
            _a.id = id,
            _a.isManual = isManual,
            _a;
    };
    /**
     * Creates a simple exception with 1 stack frame. Useful for manual constracting of exception.
     */
    Exception.CreateSimpleException = function (message, typeName, assembly, fileName, details, line) {
        var _a;
        return {
            exceptions: [
                (_a = {},
                    _a[_DYN_HAS_FULL_STACK /* @min:hasFullStack */] = true,
                    _a.message = message,
                    _a.stack = details,
                    _a.typeName = typeName,
                    _a)
            ]
        };
    };
    Exception.envelopeType = "Microsoft.ApplicationInsights.{0}.Exception";
    Exception.dataType = "ExceptionData";
    Exception.formatError = _formatErrorCode;
    return Exception;
}());
export { Exception };
var _ExceptionDetails = /** @class */ (function () {
    function _ExceptionDetails(logger, exception, properties) {
        this.aiDataContract = {
            id: 0 /* FieldType.Default */,
            outerId: 0 /* FieldType.Default */,
            typeName: 1 /* FieldType.Required */,
            message: 1 /* FieldType.Required */,
            hasFullStack: 0 /* FieldType.Default */,
            stack: 0 /* FieldType.Default */,
            parsedStack: 2 /* FieldType.Array */
        };
        var _self = this;
        if (!_isExceptionDetailsInternal(exception)) {
            var error = exception;
            var evt = error && error.evt;
            if (!isError(error)) {
                error = error[strError] || evt || error;
            }
            _self[_DYN_TYPE_NAME /* @min:%2etypeName */] = dataSanitizeString(logger, _getErrorType(error)) || strNotSpecified;
            _self[_DYN_MESSAGE /* @min:%2emessage */] = dataSanitizeMessage(logger, _formatMessage(exception || error, _self[_DYN_TYPE_NAME /* @min:%2etypeName */])) || strNotSpecified;
            var stack = exception[strStackDetails] || _getStackFromErrorObj(exception);
            _self[_DYN_PARSED_STACK /* @min:%2eparsedStack */] = _parseStack(stack);
            // after parsedStack is inited, iterate over each frame object, sanitize its assembly field
            if (isArray(_self[_DYN_PARSED_STACK /* @min:%2eparsedStack */])) {
                arrMap(_self[_DYN_PARSED_STACK /* @min:%2eparsedStack */], function (frame) {
                    frame[_DYN_ASSEMBLY /* @min:%2eassembly */] = dataSanitizeString(logger, frame[_DYN_ASSEMBLY /* @min:%2eassembly */]);
                    frame[_DYN_FILE_NAME /* @min:%2efileName */] = dataSanitizeString(logger, frame[_DYN_FILE_NAME /* @min:%2efileName */]);
                });
            }
            _self[strStack] = dataSanitizeException(logger, _formatStackTrace(stack));
            _self.hasFullStack = isArray(_self.parsedStack) && _self.parsedStack[_DYN_LENGTH /* @min:%2elength */] > 0;
            if (properties) {
                properties[_DYN_TYPE_NAME /* @min:%2etypeName */] = properties[_DYN_TYPE_NAME /* @min:%2etypeName */] || _self[_DYN_TYPE_NAME /* @min:%2etypeName */];
            }
        }
        else {
            _self[_DYN_TYPE_NAME /* @min:%2etypeName */] = exception[_DYN_TYPE_NAME /* @min:%2etypeName */];
            _self[_DYN_MESSAGE /* @min:%2emessage */] = exception[_DYN_MESSAGE /* @min:%2emessage */];
            _self[strStack] = exception[strStack];
            _self[_DYN_PARSED_STACK /* @min:%2eparsedStack */] = exception[_DYN_PARSED_STACK /* @min:%2eparsedStack */] || [];
            _self[_DYN_HAS_FULL_STACK /* @min:%2ehasFullStack */] = exception[_DYN_HAS_FULL_STACK /* @min:%2ehasFullStack */];
        }
    }
    _ExceptionDetails.prototype.toInterface = function () {
        var _a;
        var _self = this;
        var parsedStack = _self[_DYN_PARSED_STACK /* @min:%2eparsedStack */] instanceof Array
            && arrMap(_self[_DYN_PARSED_STACK /* @min:%2eparsedStack */], function (frame) { return frame.toInterface(); });
        var exceptionDetailsInterface = (_a = {
                id: _self.id,
                outerId: _self.outerId,
                typeName: _self[_DYN_TYPE_NAME /* @min:%2etypeName */],
                message: _self[_DYN_MESSAGE /* @min:%2emessage */],
                hasFullStack: _self[_DYN_HAS_FULL_STACK /* @min:%2ehasFullStack */],
                stack: _self[strStack]
            },
            _a[_DYN_PARSED_STACK /* @min:parsedStack */] = parsedStack || undefined,
            _a);
        return exceptionDetailsInterface;
    };
    _ExceptionDetails.CreateFromInterface = function (logger, exception) {
        var parsedStack = (exception[_DYN_PARSED_STACK /* @min:%2eparsedStack */] instanceof Array
            && arrMap(exception[_DYN_PARSED_STACK /* @min:%2eparsedStack */], function (frame) { return _StackFrame[_DYN__CREATE_FROM_INTERFA1 /* @min:%2eCreateFromInterface */](frame); }))
            || exception[_DYN_PARSED_STACK /* @min:%2eparsedStack */];
        var exceptionDetails = new _ExceptionDetails(logger, __assign(__assign({}, exception), { parsedStack: parsedStack }));
        return exceptionDetails;
    };
    return _ExceptionDetails;
}());
export { _ExceptionDetails };
var _StackFrame = /** @class */ (function () {
    function _StackFrame(sourceFrame, level) {
        this.aiDataContract = {
            level: 1 /* FieldType.Required */,
            method: 1 /* FieldType.Required */,
            assembly: 0 /* FieldType.Default */,
            fileName: 0 /* FieldType.Default */,
            line: 0 /* FieldType.Default */
        };
        var _self = this;
        _self[_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */] = 0;
        // Not converting this to isString() as typescript uses this logic to "understand" the different
        // types for the 2 different code paths
        if (typeof sourceFrame === "string") {
            var frame = sourceFrame;
            _self[_DYN_LEVEL /* @min:%2elevel */] = level;
            _self[_DYN_METHOD /* @min:%2emethod */] = NoMethod;
            _self[_DYN_ASSEMBLY /* @min:%2eassembly */] = strTrim(frame);
            _self[_DYN_FILE_NAME /* @min:%2efileName */] = "";
            _self[_DYN_LINE /* @min:%2eline */] = 0;
            var matches = frame.match(_StackFrame.regex);
            if (matches && matches[_DYN_LENGTH /* @min:%2elength */] >= 5) {
                _self[_DYN_METHOD /* @min:%2emethod */] = strTrim(matches[2]) || _self[_DYN_METHOD /* @min:%2emethod */];
                _self[_DYN_FILE_NAME /* @min:%2efileName */] = strTrim(matches[4]);
                _self[_DYN_LINE /* @min:%2eline */] = parseInt(matches[5]) || 0;
            }
        }
        else {
            _self[_DYN_LEVEL /* @min:%2elevel */] = sourceFrame[_DYN_LEVEL /* @min:%2elevel */];
            _self[_DYN_METHOD /* @min:%2emethod */] = sourceFrame[_DYN_METHOD /* @min:%2emethod */];
            _self[_DYN_ASSEMBLY /* @min:%2eassembly */] = sourceFrame[_DYN_ASSEMBLY /* @min:%2eassembly */];
            _self[_DYN_FILE_NAME /* @min:%2efileName */] = sourceFrame[_DYN_FILE_NAME /* @min:%2efileName */];
            _self[_DYN_LINE /* @min:%2eline */] = sourceFrame[_DYN_LINE /* @min:%2eline */];
            _self[_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */] = 0;
        }
        _self.sizeInBytes += _self.method[_DYN_LENGTH /* @min:%2elength */];
        _self.sizeInBytes += _self.fileName[_DYN_LENGTH /* @min:%2elength */];
        _self.sizeInBytes += _self.assembly[_DYN_LENGTH /* @min:%2elength */];
        // todo: these might need to be removed depending on how the back-end settles on their size calculation
        _self[_DYN_SIZE_IN_BYTES /* @min:%2esizeInBytes */] += _StackFrame.baseSize;
        _self.sizeInBytes += _self.level.toString()[_DYN_LENGTH /* @min:%2elength */];
        _self.sizeInBytes += _self.line.toString()[_DYN_LENGTH /* @min:%2elength */];
    }
    _StackFrame.CreateFromInterface = function (frame) {
        return new _StackFrame(frame, null /* level is available in frame interface */);
    };
    _StackFrame.prototype.toInterface = function () {
        var _self = this;
        return {
            level: _self[_DYN_LEVEL /* @min:%2elevel */],
            method: _self[_DYN_METHOD /* @min:%2emethod */],
            assembly: _self[_DYN_ASSEMBLY /* @min:%2eassembly */],
            fileName: _self[_DYN_FILE_NAME /* @min:%2efileName */],
            line: _self[_DYN_LINE /* @min:%2eline */]
        };
    };
    // regex to match stack frames from ie/chrome/ff
    // methodName=$2, fileName=$4, lineNo=$5, column=$6
    _StackFrame.regex = /^([\s]+at)?[\s]{0,50}([^\@\()]+?)[\s]{0,50}(\@|\()([^\(\n]+):([0-9]+):([0-9]+)(\)?)$/;
    _StackFrame.baseSize = 58; // '{"method":"","level":,"assembly":"","fileName":"","line":}'.length
    return _StackFrame;
}());
export { _StackFrame };
//# sourceMappingURL=Exception.js.map