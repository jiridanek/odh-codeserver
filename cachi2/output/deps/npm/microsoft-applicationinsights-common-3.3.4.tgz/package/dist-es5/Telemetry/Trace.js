/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { strNotSpecified } from "../Constants";
import { _DYN_MEASUREMENTS, _DYN_MESSAGE, _DYN_PROPERTIES, _DYN_SEVERITY_LEVEL } from "../__DynamicConstants";
import { dataSanitizeMeasurements, dataSanitizeMessage, dataSanitizeProperties } from "./Common/DataSanitizer";
var Trace = /** @class */ (function () {
    /**
     * Constructs a new instance of the TraceTelemetry object
     */
    function Trace(logger, message, severityLevel, properties, measurements) {
        this.aiDataContract = {
            ver: 1 /* FieldType.Required */,
            message: 1 /* FieldType.Required */,
            severityLevel: 0 /* FieldType.Default */,
            properties: 0 /* FieldType.Default */
        };
        var _self = this;
        _self.ver = 2;
        message = message || strNotSpecified;
        _self[_DYN_MESSAGE /* @min:%2emessage */] = dataSanitizeMessage(logger, message);
        _self[_DYN_PROPERTIES /* @min:%2eproperties */] = dataSanitizeProperties(logger, properties);
        _self[_DYN_MEASUREMENTS /* @min:%2emeasurements */] = dataSanitizeMeasurements(logger, measurements);
        if (severityLevel) {
            _self[_DYN_SEVERITY_LEVEL /* @min:%2eseverityLevel */] = severityLevel;
        }
    }
    Trace.envelopeType = "Microsoft.ApplicationInsights.{0}.Message";
    Trace.dataType = "MessageData";
    return Trace;
}());
export { Trace };
//# sourceMappingURL=Trace.js.map