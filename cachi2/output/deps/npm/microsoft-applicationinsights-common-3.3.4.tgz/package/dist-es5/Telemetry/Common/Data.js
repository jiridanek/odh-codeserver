/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


var Data = /** @class */ (function () {
    /**
     * Constructs a new instance of telemetry data.
     */
    function Data(baseType, data) {
        /**
         * The data contract for serializing this object.
         */
        this.aiDataContract = {
            baseType: 1 /* FieldType.Required */,
            baseData: 1 /* FieldType.Required */
        };
        this.baseType = baseType;
        this.baseData = data;
    }
    return Data;
}());
export { Data };
//# sourceMappingURL=Data.js.map