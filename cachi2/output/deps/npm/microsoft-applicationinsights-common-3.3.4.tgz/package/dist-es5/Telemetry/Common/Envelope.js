/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { toISOString } from "@microsoft/applicationinsights-core-js";
import { strNotSpecified } from "../../Constants";
import { _DYN_NAME } from "../../__DynamicConstants";
import { dataSanitizeString } from "./DataSanitizer";
var Envelope = /** @class */ (function () {
    /**
     * Constructs a new instance of telemetry data.
     */
    function Envelope(logger, data, name) {
        var _this = this;
        var _self = this;
        _self.ver = 1;
        _self.sampleRate = 100.0;
        _self.tags = {};
        _self[_DYN_NAME /* @min:%2ename */] = dataSanitizeString(logger, name) || strNotSpecified;
        _self.data = data;
        _self.time = toISOString(new Date());
        _self.aiDataContract = {
            time: 1 /* FieldType.Required */,
            iKey: 1 /* FieldType.Required */,
            name: 1 /* FieldType.Required */,
            sampleRate: function () {
                return (_this.sampleRate === 100) ? 4 /* FieldType.Hidden */ : 1 /* FieldType.Required */;
            },
            tags: 1 /* FieldType.Required */,
            data: 1 /* FieldType.Required */
        };
    }
    return Envelope;
}());
export { Envelope };
//# sourceMappingURL=Envelope.js.map