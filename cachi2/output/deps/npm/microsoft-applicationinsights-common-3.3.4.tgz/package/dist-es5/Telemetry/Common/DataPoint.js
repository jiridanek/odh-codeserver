/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


var DataPoint = /** @class */ (function () {
    function DataPoint() {
        /**
         * The data contract for serializing this object.
         */
        this.aiDataContract = {
            name: 1 /* FieldType.Required */,
            kind: 0 /* FieldType.Default */,
            value: 1 /* FieldType.Required */,
            count: 0 /* FieldType.Default */,
            min: 0 /* FieldType.Default */,
            max: 0 /* FieldType.Default */,
            stdDev: 0 /* FieldType.Default */
        };
        /**
         * Metric type. Single measurement or the aggregated value.
         */
        this.kind = 0 /* DataPointType.Measurement */;
    }
    return DataPoint;
}());
export { DataPoint };
//# sourceMappingURL=DataPoint.js.map