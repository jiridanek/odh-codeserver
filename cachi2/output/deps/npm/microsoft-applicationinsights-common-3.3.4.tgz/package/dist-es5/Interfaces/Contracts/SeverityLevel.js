/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { createEnumStyle } from "@microsoft/applicationinsights-core-js";
/**
 * Defines the level of severity for the event.
 */
export var SeverityLevel = createEnumStyle({
    Verbose: 0 /* eSeverityLevel.Verbose */,
    Information: 1 /* eSeverityLevel.Information */,
    Warning: 2 /* eSeverityLevel.Warning */,
    Error: 3 /* eSeverityLevel.Error */,
    Critical: 4 /* eSeverityLevel.Critical */
});
//# sourceMappingURL=SeverityLevel.js.map