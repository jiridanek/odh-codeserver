/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { isNullOrUndefined } from "@microsoft/applicationinsights-core-js";
import { _DYN_EXTENSION_CONFIG } from "../__DynamicConstants";
var ConfigurationManager = /** @class */ (function () {
    function ConfigurationManager() {
    }
    ConfigurationManager.getConfig = function (config, field, identifier, defaultValue) {
        if (defaultValue === void 0) { defaultValue = false; }
        var configValue;
        if (identifier && config[_DYN_EXTENSION_CONFIG /* @min:%2eextensionConfig */] && config[_DYN_EXTENSION_CONFIG /* @min:%2eextensionConfig */][identifier] && !isNullOrUndefined(config[_DYN_EXTENSION_CONFIG /* @min:%2eextensionConfig */][identifier][field])) {
            configValue = config[_DYN_EXTENSION_CONFIG /* @min:%2eextensionConfig */][identifier][field];
        }
        else {
            configValue = config[field];
        }
        return !isNullOrUndefined(configValue) ? configValue : defaultValue;
    };
    return ConfigurationManager;
}());
export { ConfigurationManager };
//# sourceMappingURL=IConfig.js.map