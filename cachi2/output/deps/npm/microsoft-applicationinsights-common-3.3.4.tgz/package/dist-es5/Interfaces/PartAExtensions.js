/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */
import { ContextTagKeys } from "./Contracts/ContextTagKeys";
export var Extensions = {
    UserExt: "user",
    DeviceExt: "device",
    TraceExt: "trace",
    WebExt: "web",
    AppExt: "app",
    OSExt: "os",
    SessionExt: "ses",
    SDKExt: "sdk"
};
export var CtxTagKeys = new ContextTagKeys();
//# sourceMappingURL=PartAExtensions.js.map