/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


export {};
//# sourceMappingURL=IPageViewData.js.map