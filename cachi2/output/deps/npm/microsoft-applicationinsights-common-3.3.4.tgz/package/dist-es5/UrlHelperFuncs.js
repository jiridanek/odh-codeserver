/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { getDocument, isString } from "@microsoft/applicationinsights-core-js";
import { _DYN_LENGTH, _DYN_PATHNAME, _DYN_TO_LOWER_CASE } from "./__DynamicConstants";
var _document = getDocument() || {};
var _htmlAnchorIdx = 0;
// Use an array of temporary values as it's possible for multiple calls to parseUrl() will be called with different URLs
// Using a cache size of 5 for now as it current depth usage is at least 2, so adding a minor buffer to handle future updates
var _htmlAnchorElement = [null, null, null, null, null];
export function urlParseUrl(url) {
    var anchorIdx = _htmlAnchorIdx;
    var anchorCache = _htmlAnchorElement;
    var tempAnchor = anchorCache[anchorIdx];
    if (!_document.createElement) {
        // Always create the temp instance if createElement is not available
        tempAnchor = { host: urlParseHost(url, true) };
    }
    else if (!anchorCache[anchorIdx]) {
        // Create and cache the unattached anchor instance
        tempAnchor = anchorCache[anchorIdx] = _document.createElement("a");
    }
    tempAnchor.href = url;
    // Move the cache index forward
    anchorIdx++;
    if (anchorIdx >= anchorCache[_DYN_LENGTH /* @min:%2elength */]) {
        anchorIdx = 0;
    }
    _htmlAnchorIdx = anchorIdx;
    return tempAnchor;
}
export function urlGetAbsoluteUrl(url) {
    var result;
    var a = urlParseUrl(url);
    if (a) {
        result = a.href;
    }
    return result;
}
export function urlGetPathName(url) {
    var result;
    var a = urlParseUrl(url);
    if (a) {
        result = a[_DYN_PATHNAME /* @min:%2epathname */];
    }
    return result;
}
export function urlGetCompleteUrl(method, absoluteUrl) {
    if (method) {
        return method.toUpperCase() + " " + absoluteUrl;
    }
    return absoluteUrl;
}
// Fallback method to grab host from url if document.createElement method is not available
export function urlParseHost(url, inclPort) {
    var fullHost = urlParseFullHost(url, inclPort) || "";
    if (fullHost) {
        var match = fullHost.match(/(www\d{0,5}\.)?([^\/:]{1,256})(:\d{1,20})?/i);
        if (match != null && match[_DYN_LENGTH /* @min:%2elength */] > 3 && isString(match[2]) && match[2][_DYN_LENGTH /* @min:%2elength */] > 0) {
            return match[2] + (match[3] || "");
        }
    }
    return fullHost;
}
export function urlParseFullHost(url, inclPort) {
    var result = null;
    if (url) {
        var match = url.match(/(\w{1,150}):\/\/([^\/:]{1,256})(:\d{1,20})?/i);
        if (match != null && match[_DYN_LENGTH /* @min:%2elength */] > 2 && isString(match[2]) && match[2][_DYN_LENGTH /* @min:%2elength */] > 0) {
            result = match[2] || "";
            if (inclPort && match[_DYN_LENGTH /* @min:%2elength */] > 2) {
                var protocol = (match[1] || "")[_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]();
                var port = match[3] || "";
                // IE includes the standard port so pass it off if it's the same as the protocol
                if (protocol === "http" && port === ":80") {
                    port = "";
                }
                else if (protocol === "https" && port === ":443") {
                    port = "";
                }
                result += port;
            }
        }
    }
    return result;
}
//# sourceMappingURL=UrlHelperFuncs.js.map