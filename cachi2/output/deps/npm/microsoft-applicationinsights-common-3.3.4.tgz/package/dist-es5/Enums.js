/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { createEnumStyle } from "@microsoft/applicationinsights-core-js";
export var StorageType = createEnumStyle({
    LocalStorage: 0 /* eStorageType.LocalStorage */,
    SessionStorage: 1 /* eStorageType.SessionStorage */
});
export var DistributedTracingModes = createEnumStyle({
    AI: 0 /* eDistributedTracingModes.AI */,
    AI_AND_W3C: 1 /* eDistributedTracingModes.AI_AND_W3C */,
    W3C: 2 /* eDistributedTracingModes.W3C */
});
/**
 * The EventPersistence contains a set of values that specify the event's persistence.
 */
export var EventPersistence = createEnumStyle({
    /**
     * Normal persistence.
     */
    Normal: 1 /* EventPersistenceValue.Normal */,
    /**
     * Critical persistence.
     */
    Critical: 2 /* EventPersistenceValue.Critical */
});
//# sourceMappingURL=Enums.js.map