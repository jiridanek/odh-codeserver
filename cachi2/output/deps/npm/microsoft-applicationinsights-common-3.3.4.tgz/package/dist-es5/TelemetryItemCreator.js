/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { isNullOrUndefined, objForEachKey, throwError, toISOString } from "@microsoft/applicationinsights-core-js";
import { strIkey, strNotSpecified } from "./Constants";
import { dataSanitizeString } from "./Telemetry/Common/DataSanitizer";
import { _DYN_NAME } from "./__DynamicConstants";
/**
 * Create a telemetry item that the 1DS channel understands
 * @param item - domain specific properties; part B
 * @param baseType - telemetry item type. ie PageViewData
 * @param envelopeName - name of the envelope. ie Microsoft.ApplicationInsights.<instrumentation key>.PageView
 * @param customProperties - user defined custom properties; part C
 * @param systemProperties - system properties that are added to the context; part A
 * @returns ITelemetryItem that is sent to channel
 */
export function createTelemetryItem(item, baseType, envelopeName, logger, customProperties, systemProperties) {
    var _a;
    envelopeName = dataSanitizeString(logger, envelopeName) || strNotSpecified;
    if (isNullOrUndefined(item) ||
        isNullOrUndefined(baseType) ||
        isNullOrUndefined(envelopeName)) {
        throwError("Input doesn't contain all required fields");
    }
    var iKey = "";
    if (item[strIkey]) {
        iKey = item[strIkey];
        delete item[strIkey];
    }
    var telemetryItem = (_a = {},
        _a[_DYN_NAME /* @min:name */] = envelopeName,
        _a.time = toISOString(new Date()),
        _a.iKey = iKey,
        _a.ext = systemProperties ? systemProperties : {},
        _a.tags = [],
        _a.data = {},
        _a.baseType = baseType,
        _a.baseData = item // Part B
    ,
        _a);
    // Part C
    if (!isNullOrUndefined(customProperties)) {
        objForEachKey(customProperties, function (prop, value) {
            telemetryItem.data[prop] = value;
        });
    }
    return telemetryItem;
}
var TelemetryItemCreator = /** @class */ (function () {
    function TelemetryItemCreator() {
    }
    /**
     * Create a telemetry item that the 1DS channel understands
     * @param item - domain specific properties; part B
     * @param baseType - telemetry item type. ie PageViewData
     * @param envelopeName - name of the envelope. ie Microsoft.ApplicationInsights.<instrumentation key>.PageView
     * @param customProperties - user defined custom properties; part C
     * @param systemProperties - system properties that are added to the context; part A
     * @returns ITelemetryItem that is sent to channel
     */
    TelemetryItemCreator.create = createTelemetryItem;
    return TelemetryItemCreator;
}());
export { TelemetryItemCreator };
//# sourceMappingURL=TelemetryItemCreator.js.map