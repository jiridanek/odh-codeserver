/*
 * Application Insights JavaScript SDK - Common, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { arrReduce, objKeys, strEndsWith } from "@microsoft/applicationinsights-core-js";
import { DEFAULT_BREEZE_ENDPOINT } from "./Constants";
import { _DYN_INGESTIONENDPOINT, _DYN_LENGTH, _DYN_SPLIT, _DYN_TO_LOWER_CASE } from "./__DynamicConstants";
var _FIELDS_SEPARATOR = ";";
var _FIELD_KEY_VALUE_SEPARATOR = "=";
export function parseConnectionString(connectionString) {
    if (!connectionString) {
        return {};
    }
    var kvPairs = connectionString[_DYN_SPLIT /* @min:%2esplit */](_FIELDS_SEPARATOR);
    var result = arrReduce(kvPairs, function (fields, kv) {
        var kvParts = kv[_DYN_SPLIT /* @min:%2esplit */](_FIELD_KEY_VALUE_SEPARATOR);
        if (kvParts[_DYN_LENGTH /* @min:%2elength */] === 2) { // only save fields with valid formats
            var key = kvParts[0][_DYN_TO_LOWER_CASE /* @min:%2etoLowerCase */]();
            var value = kvParts[1];
            fields[key] = value;
        }
        return fields;
    }, {});
    if (objKeys(result)[_DYN_LENGTH /* @min:%2elength */] > 0) {
        // this is a valid connection string, so parse the results
        if (result.endpointsuffix) {
            // apply the default endpoints
            var locationPrefix = result.location ? result.location + "." : "";
            result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */] = result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */] || ("https://" + locationPrefix + "dc." + result.endpointsuffix);
        }
        // apply user override endpoint or the default endpoints
        result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */] = result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */] || DEFAULT_BREEZE_ENDPOINT;
        if (strEndsWith(result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */], "/")) {
            result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */] = result[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */].slice(0, -1);
        }
    }
    return result;
}
export var ConnectionStringParser = {
    parse: parseConnectionString
};
//# sourceMappingURL=ConnectionStringParser.js.map