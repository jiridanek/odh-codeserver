# Installation
> `npm install --save @types/gulp-svgmin`

# Summary
This package contains type definitions for gulp-svgmin (https://github.com/ben-eb/gulp-svgmin).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-svgmin.

### Additional Details
 * Last updated: Sun, 07 Mar 2021 10:09:12 GMT
 * Dependencies: [@types/svgo](https://npmjs.com/package/@types/svgo), [@types/vinyl](https://npmjs.com/package/@types/vinyl), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Aankhen](https://github.com/Aankhen).
