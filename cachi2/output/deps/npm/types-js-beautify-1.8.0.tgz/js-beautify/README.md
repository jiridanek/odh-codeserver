# Installation
> `npm install --save @types/js-beautify`

# Summary
This package contains type definitions for js_beautify (https://github.com/beautify-web/js-beautify/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/js-beautify

Additional Details
 * Last updated: Wed, 05 Sep 2018 15:50:35 GMT
 * Dependencies: none
 * Global values: js_beautify

# Credits
These definitions were written by Josh Goldberg <https://github.com/JoshuaKGoldberg>, Hans Windhoff <https://github.com/hansrwindhoff>.
