# Installation
> `npm install --save @types/vscode`

# Summary
This package contains type definitions for vscode (https://github.com/microsoft/vscode).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vscode.

### Additional Details
 * Last updated: Thu, 03 Oct 2024 16:40:40 GMT
 * Dependencies: none

# Credits
These definitions were written by [Visual Studio Code Team, and Microsoft](https://github.com/microsoft).
