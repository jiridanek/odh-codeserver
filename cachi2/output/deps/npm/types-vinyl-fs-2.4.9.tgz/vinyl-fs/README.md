# Installation
> `npm install --save @types/vinyl-fs`

# Summary
This package contains type definitions for vinyl-fs (https://github.com/wearefractal/vinyl-fs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vinyl-fs

Additional Details
 * Last updated: Sat, 04 Aug 2018 00:56:33 GMT
 * Dependencies: events, vinyl, glob-stream, node
 * Global values: none

# Credits
These definitions were written by vvakame <https://github.com/vvakame>, remisery <https://github.com/remisery>.
