// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { extractPartitionKey } from "../extractPartitionKey";
import { v4 } from "uuid";
import { bodyFromData } from "../request/request";
import { Constants } from "../common/constants";
const uuid = v4;
export function isKeyInRange(min, max, key) {
    const isAfterMinInclusive = key.localeCompare(min) >= 0;
    const isBeforeMax = key.localeCompare(max) < 0;
    return isAfterMinInclusive && isBeforeMax;
}
export const BulkOperationType = {
    Create: "Create",
    Upsert: "Upsert",
    Read: "Read",
    Delete: "Delete",
    Replace: "Replace",
    Patch: "Patch",
};
export function hasResource(operation) {
    return (operation.operationType !== "Patch" &&
        operation.resourceBody !== undefined);
}
export function getPartitionKeyToHash(operation, partitionProperty) {
    const toHashKey = hasResource(operation)
        ? deepFind(operation.resourceBody, partitionProperty)
        : (operation.partitionKey && operation.partitionKey.replace(/[[\]"']/g, "")) ||
            operation.partitionKey;
    // We check for empty object since replace will stringify the value
    // The second check avoids cases where the partitionKey value is actually the string '{}'
    if (toHashKey === "{}" && operation.partitionKey === "[{}]") {
        return {};
    }
    if (toHashKey === "null" && operation.partitionKey === "[null]") {
        return null;
    }
    if (toHashKey === "0" && operation.partitionKey === "[0]") {
        return 0;
    }
    return toHashKey;
}
export function decorateOperation(operation, definition, options = {}) {
    if (operation.operationType === BulkOperationType.Create ||
        operation.operationType === BulkOperationType.Upsert) {
        if ((operation.resourceBody.id === undefined || operation.resourceBody.id === "") &&
            !options.disableAutomaticIdGeneration) {
            operation.resourceBody.id = uuid();
        }
    }
    if ("partitionKey" in operation) {
        const extracted = extractPartitionKey(operation, { paths: ["/partitionKey"] });
        return Object.assign(Object.assign({}, operation), { partitionKey: JSON.stringify(extracted) });
    }
    else if (operation.operationType === BulkOperationType.Create ||
        operation.operationType === BulkOperationType.Replace ||
        operation.operationType === BulkOperationType.Upsert) {
        const pk = extractPartitionKey(operation.resourceBody, definition);
        return Object.assign(Object.assign({}, operation), { partitionKey: JSON.stringify(pk) });
    }
    else if (operation.operationType === BulkOperationType.Read ||
        operation.operationType === BulkOperationType.Delete) {
        return Object.assign(Object.assign({}, operation), { partitionKey: "[{}]" });
    }
    return operation;
}
/**
 * Splits a batch into array of batches based on cumulative size of its operations by making sure
 * cumulative size of an individual batch is not larger than {@link Constants.DefaultMaxBulkRequestBodySizeInBytes}.
 * If a single operation itself is larger than {@link Constants.DefaultMaxBulkRequestBodySizeInBytes}, that
 * operation would be moved into a batch containing only that operation.
 * @param originalBatch - A batch of operations needed to be checked.
 * @returns
 * @hidden
 */
export function splitBatchBasedOnBodySize(originalBatch) {
    if ((originalBatch === null || originalBatch === void 0 ? void 0 : originalBatch.operations) === undefined || originalBatch.operations.length < 1)
        return [];
    let currentBatchSize = calculateObjectSizeInBytes(originalBatch.operations[0]);
    let currentBatch = Object.assign(Object.assign({}, originalBatch), { operations: [originalBatch.operations[0]], indexes: [originalBatch.indexes[0]] });
    const processedBatches = [];
    processedBatches.push(currentBatch);
    for (let index = 1; index < originalBatch.operations.length; index++) {
        const operation = originalBatch.operations[index];
        const currentOpSize = calculateObjectSizeInBytes(operation);
        if (currentBatchSize + currentOpSize > Constants.DefaultMaxBulkRequestBodySizeInBytes) {
            currentBatch = Object.assign(Object.assign({}, originalBatch), { operations: [], indexes: [] });
            processedBatches.push(currentBatch);
            currentBatchSize = 0;
        }
        currentBatch.operations.push(operation);
        currentBatch.indexes.push(originalBatch.indexes[index]);
        currentBatchSize += currentOpSize;
    }
    return processedBatches;
}
/**
 * Calculates size of an JSON object in bytes with utf-8 encoding.
 * @hidden
 */
export function calculateObjectSizeInBytes(obj) {
    return new TextEncoder().encode(bodyFromData(obj)).length;
}
export function decorateBatchOperation(operation, options = {}) {
    if (operation.operationType === BulkOperationType.Create ||
        operation.operationType === BulkOperationType.Upsert) {
        if ((operation.resourceBody.id === undefined || operation.resourceBody.id === "") &&
            !options.disableAutomaticIdGeneration) {
            operation.resourceBody.id = uuid();
        }
    }
    return operation;
}
/**
 * Util function for finding partition key values nested in objects at slash (/) separated paths
 * @hidden
 */
export function deepFind(document, path) {
    const apath = path.split("/");
    let h = document;
    for (const p of apath) {
        if (p in h)
            h = h[p];
        else {
            if (p !== "_partitionKey") {
                console.warn(`Partition key not found, using undefined: ${path} at ${p}`);
            }
            return "{}";
        }
    }
    return h;
}
//# sourceMappingURL=batch.js.map