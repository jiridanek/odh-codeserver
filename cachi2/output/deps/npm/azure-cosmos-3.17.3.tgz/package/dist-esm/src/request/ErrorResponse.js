export class ErrorResponse extends Error {
}
//# sourceMappingURL=ErrorResponse.js.map