import { ClientContext } from "../../ClientContext";
import { CosmosClient } from "../../CosmosClient";
import { RequestOptions } from "../../request";
import { Container, Containers } from "../Container";
import { User, Users } from "../User";
import { DatabaseResponse } from "./DatabaseResponse";
import { OfferResponse } from "../Offer";
/**
 * Operations for reading or deleting an existing database.
 *
 * @see {@link Databases} for creating new databases, and reading/querying all databases; use `client.databases`.
 *
 * Note: all these operations make calls against a fixed budget.
 * You should design your system such that these calls scale sublinearly with your application.
 * For instance, do not call `database.read()` before every single `item.read()` call, to ensure the database exists;
 * do this once on application start up.
 */
export declare class Database {
    readonly client: CosmosClient;
    readonly id: string;
    private clientContext;
    /**
     * Used for creating new containers, or querying/reading all containers.
     *
     * Use `.database(id)` to read, replace, or delete a specific, existing {@link Database} by id.
     *
     * @example Create a new container
     * ```typescript
     * const {body: containerDefinition, container} = await client.database("<db id>").containers.create({id: "<container id>"});
     * ```
     */
    readonly containers: Containers;
    /**
     * Used for creating new users, or querying/reading all users.
     *
     * Use `.user(id)` to read, replace, or delete a specific, existing {@link User} by id.
     */
    readonly users: Users;
    /**
     * Returns a reference URL to the resource. Used for linking in Permissions.
     */
    get url(): string;
    /** Returns a new {@link Database} instance.
     *
     * Note: the intention is to get this object from {@link CosmosClient} via `client.database(id)`, not to instantiate it yourself.
     */
    constructor(client: CosmosClient, id: string, clientContext: ClientContext);
    /**
     * Used to read, replace, or delete a specific, existing {@link Database} by id.
     *
     * Use `.containers` creating new containers, or querying/reading all containers.
     *
     * @example Delete a container
     * ```typescript
     * await client.database("<db id>").container("<container id>").delete();
     * ```
     */
    container(id: string): Container;
    /**
     * Used to read, replace, or delete a specific, existing {@link User} by id.
     *
     * Use `.users` for creating new users, or querying/reading all users.
     */
    user(id: string): User;
    /** Read the definition of the given Database. */
    read(options?: RequestOptions): Promise<DatabaseResponse>;
    /** Delete the given Database. */
    delete(options?: RequestOptions): Promise<DatabaseResponse>;
    /**
     * Gets offer on database. If none exists, returns an OfferResponse with undefined.
     */
    readOffer(options?: RequestOptions): Promise<OfferResponse>;
}
//# sourceMappingURL=Database.d.ts.map