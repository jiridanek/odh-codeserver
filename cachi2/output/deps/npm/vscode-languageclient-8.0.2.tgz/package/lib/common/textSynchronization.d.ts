import { TextDocument, TextDocumentChangeEvent, TextDocumentWillSaveEvent, TextEdit as VTextEdit, DocumentSelector as VDocumentSelector, Event } from 'vscode';
import { ClientCapabilities, DidChangeTextDocumentParams, DidCloseTextDocumentParams, DidOpenTextDocumentParams, DidSaveTextDocumentParams, DocumentSelector, ProtocolNotificationType, RegistrationType, ServerCapabilities, TextDocumentChangeRegistrationOptions, TextDocumentRegistrationOptions, TextDocumentSaveRegistrationOptions, TextDocumentSyncOptions, WillSaveTextDocumentParams } from 'vscode-languageserver-protocol';
import { FeatureClient, TextDocumentEventFeature, DynamicFeature, NextSignature, TextDocumentSendFeature, NotifyingFeature, RegistrationData, DynamicDocumentFeature, NotificationSendEvent } from './features';
export interface TextDocumentSynchronizationMiddleware {
    didOpen?: NextSignature<TextDocument, Promise<void>>;
    didChange?: NextSignature<TextDocumentChangeEvent, Promise<void>>;
    willSave?: NextSignature<TextDocumentWillSaveEvent, Promise<void>>;
    willSaveWaitUntil?: NextSignature<TextDocumentWillSaveEvent, Thenable<VTextEdit[]>>;
    didSave?: NextSignature<TextDocument, Promise<void>>;
    didClose?: NextSignature<TextDocument, Promise<void>>;
}
export interface DidOpenTextDocumentFeatureShape extends DynamicFeature<TextDocumentRegistrationOptions>, TextDocumentSendFeature<(textDocument: TextDocument) => Promise<void>>, NotifyingFeature<TextDocument, DidOpenTextDocumentParams> {
    openDocuments: Iterable<TextDocument>;
}
export declare type ResolvedTextDocumentSyncCapabilities = {
    resolvedTextDocumentSync?: TextDocumentSyncOptions;
};
export declare class DidOpenTextDocumentFeature extends TextDocumentEventFeature<DidOpenTextDocumentParams, TextDocument, TextDocumentSynchronizationMiddleware> implements DidOpenTextDocumentFeatureShape {
    private readonly _syncedDocuments;
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>, syncedDocuments: Map<string, TextDocument>);
    get openDocuments(): IterableIterator<TextDocument>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    get registrationType(): RegistrationType<TextDocumentRegistrationOptions>;
    register(data: RegistrationData<TextDocumentRegistrationOptions>): void;
    protected notificationSent(textDocument: TextDocument, type: ProtocolNotificationType<DidOpenTextDocumentParams, TextDocumentRegistrationOptions>, params: DidOpenTextDocumentParams): void;
}
export interface DidCloseTextDocumentFeatureShape extends DynamicFeature<TextDocumentRegistrationOptions>, TextDocumentSendFeature<(textDocument: TextDocument) => Promise<void>>, NotifyingFeature<TextDocument, DidCloseTextDocumentParams> {
}
export declare class DidCloseTextDocumentFeature extends TextDocumentEventFeature<DidCloseTextDocumentParams, TextDocument, TextDocumentSynchronizationMiddleware> implements DidCloseTextDocumentFeatureShape {
    private readonly _syncedDocuments;
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>, syncedDocuments: Map<string, TextDocument>);
    get registrationType(): RegistrationType<TextDocumentRegistrationOptions>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    protected notificationSent(textDocument: TextDocument, type: ProtocolNotificationType<DidCloseTextDocumentParams, TextDocumentRegistrationOptions>, params: DidCloseTextDocumentParams): void;
    unregister(id: string): void;
}
export interface DidChangeTextDocumentFeatureShape extends DynamicFeature<TextDocumentChangeRegistrationOptions>, TextDocumentSendFeature<(event: TextDocumentChangeEvent) => Promise<void>>, NotifyingFeature<TextDocumentChangeEvent, DidChangeTextDocumentParams> {
}
export declare class DidChangeTextDocumentFeature extends DynamicDocumentFeature<TextDocumentChangeRegistrationOptions, TextDocumentSynchronizationMiddleware> implements DidChangeTextDocumentFeatureShape {
    private _listener;
    private readonly _changeData;
    private _forcingDelivery;
    private _changeDelayer;
    private readonly _onNotificationSent;
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>);
    get registrationType(): RegistrationType<TextDocumentChangeRegistrationOptions>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    register(data: RegistrationData<TextDocumentChangeRegistrationOptions>): void;
    getDocumentSelectors(): IterableIterator<VDocumentSelector>;
    private callback;
    get onNotificationSent(): Event<NotificationSendEvent<TextDocumentChangeEvent, DidChangeTextDocumentParams>>;
    private notificationSent;
    unregister(id: string): void;
    dispose(): void;
    forceDelivery(): Promise<void>;
    getProvider(document: TextDocument): {
        send: (event: TextDocumentChangeEvent) => Promise<void>;
    } | undefined;
}
export declare class WillSaveFeature extends TextDocumentEventFeature<WillSaveTextDocumentParams, TextDocumentWillSaveEvent, TextDocumentSynchronizationMiddleware> {
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>);
    get registrationType(): RegistrationType<TextDocumentRegistrationOptions>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
}
export declare class WillSaveWaitUntilFeature extends DynamicDocumentFeature<TextDocumentRegistrationOptions, TextDocumentSynchronizationMiddleware> {
    private _listener;
    private readonly _selectors;
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>);
    protected getDocumentSelectors(): IterableIterator<VDocumentSelector>;
    get registrationType(): RegistrationType<TextDocumentRegistrationOptions>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    register(data: RegistrationData<TextDocumentRegistrationOptions>): void;
    private callback;
    unregister(id: string): void;
    dispose(): void;
}
export interface DidSaveTextDocumentFeatureShape extends DynamicFeature<TextDocumentRegistrationOptions>, TextDocumentSendFeature<(textDocument: TextDocument) => Promise<void>>, NotifyingFeature<TextDocument, DidSaveTextDocumentParams> {
}
export declare class DidSaveTextDocumentFeature extends TextDocumentEventFeature<DidSaveTextDocumentParams, TextDocument, TextDocumentSynchronizationMiddleware> implements DidSaveTextDocumentFeatureShape {
    private _includeText;
    constructor(client: FeatureClient<TextDocumentSynchronizationMiddleware>);
    get registrationType(): RegistrationType<TextDocumentSaveRegistrationOptions>;
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    register(data: RegistrationData<TextDocumentSaveRegistrationOptions>): void;
}
