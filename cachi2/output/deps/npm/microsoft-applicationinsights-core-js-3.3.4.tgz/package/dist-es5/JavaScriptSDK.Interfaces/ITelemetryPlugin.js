/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


"use strict";
export {};
//# sourceMappingURL=ITelemetryPlugin.js.map