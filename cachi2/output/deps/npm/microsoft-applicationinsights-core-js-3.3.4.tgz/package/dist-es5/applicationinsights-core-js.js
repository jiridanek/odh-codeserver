/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */
export { MinChannelPriorty } from "./JavaScriptSDK.Interfaces/IChannelControls";
export { EventsDiscardedReason, BatchDiscardedReason } from "./JavaScriptSDK.Enums/EventsDiscardedReason";
export { ActiveStatus } from "./JavaScriptSDK.Enums/InitActiveStatusEnum";
export { throwAggregationError } from "./JavaScriptSDK/AggregationError";
export { AppInsightsCore } from "./JavaScriptSDK/AppInsightsCore";
export { BaseTelemetryPlugin } from "./JavaScriptSDK/BaseTelemetryPlugin";
export { randomValue, random32, mwcRandomSeed, mwcRandom32, newId } from "./JavaScriptSDK/RandomHelper";
export { Undefined, newGuid, generateW3CId } from "./JavaScriptSDK/CoreUtils";
export { runTargetUnload, doUnloadAll } from "./JavaScriptSDK/AsyncUtils";
export { normalizeJsName, toISOString, getExceptionName, strContains, setValue, getSetValue, proxyAssign, proxyFunctions, proxyFunctionAs, createClassFromInterface, optimizeObject, isNotUndefined, isNotNullOrUndefined, objExtend, isFeatureEnabled, getResponseText, formatErrorMessageXdr, formatErrorMessageXhr, prependTransports, openXhr, _appendHeader, _getAllResponseHeaders, convertAllHeadersToMap } from "./JavaScriptSDK/HelperFuncs";
export { parseResponse } from "./JavaScriptSDK/ResponseHelpers";
export { SenderPostManager } from "./JavaScriptSDK/SenderPostManager";
export { isArray, isTypeof, isUndefined, isNullOrUndefined, objHasOwnProperty as hasOwnProperty, isObject, isFunction, strEndsWith, strStartsWith, isDate, isError, isString, isNumber, isBoolean, arrForEach, arrIndexOf, arrReduce, arrMap, strTrim, objKeys, objDefineAccessors, throwError, isSymbol, isNotTruthy, isTruthy, objFreeze, objSeal, objToString, objDeepFreeze as deepFreeze, getInst as getGlobalInst, hasWindow, getWindow, hasDocument, getDocument, hasNavigator, getNavigator, hasHistory, getHistory, dumpObj, asString, objForEachKey, getPerformance, utcNow as dateNow, perfNow } from "@nevware21/ts-utils";
export { createEnumStyle, createValueMap } from "./JavaScriptSDK.Enums/EnumHelperFuncs";
export { attachEvent, detachEvent, addEventHandler, addEventListeners, addPageUnloadEventListener, addPageHideEventListener, addPageShowEventListener, removeEventHandler, removeEventListeners, removePageUnloadEventListener, removePageHideEventListener, removePageShowEventListener, eventOn, eventOff, mergeEvtNamespace, __getRegisteredEvents } from "./JavaScriptSDK/EventHelpers";
export { getCrypto, getMsCrypto, getLocation, hasJSON, getJSON, isReactNative, getConsole, isIE, getIEVersion, isSafari, setEnableEnvMocks, isBeaconsSupported, isFetchSupported, useXDomainRequest, isXhrSupported, findMetaTag, findNamedServerTiming, sendCustomEvent, dispatchEvent, createCustomDomEvent } from "./JavaScriptSDK/EnvUtils";
export { getGlobal, strShimPrototype as strPrototype, strShimFunction as strFunction, strShimUndefined as strUndefined, strShimObject as strObject } from "@microsoft/applicationinsights-shims";
export { NotificationManager } from "./JavaScriptSDK/NotificationManager";
export { PerfEvent, PerfManager, doPerf, getGblPerfMgr, setGblPerfMgr } from "./JavaScriptSDK/PerfManager";
export { safeGetLogger, DiagnosticLogger, _InternalLogMessage, _throwInternal, _warnToConsole, _logInternalMessage } from "./JavaScriptSDK/DiagnosticLogger";
export { ProcessTelemetryContext, createProcessTelemetryContext
// Explicitly NOT exporting createProcessTelemetryUnloadContext() and createProcessTelemetryUpdateContext() as these should only be created internally
 } from "./JavaScriptSDK/ProcessTelemetryContext";
export { initializePlugins, sortPlugins, unloadComponents } from "./JavaScriptSDK/TelemetryHelpers";
export { LoggingSeverity } from "./JavaScriptSDK.Enums/LoggingEnums";
export { InstrumentProto, InstrumentProtos, InstrumentFunc, InstrumentFuncs, InstrumentEvent } from "./JavaScriptSDK/InstrumentHooks";
export { createCookieMgr, safeGetCookieMgr, uaDisallowsSameSiteNone, areCookiesSupported } from "./JavaScriptSDK/CookieMgr";
export { getDebugListener, getDebugExt } from "./JavaScriptSDK/DbgExtensionUtils";
export { createUniqueNamespace } from "./JavaScriptSDK/DataCacheHelper";
export { createUnloadHandlerContainer } from "./JavaScriptSDK/UnloadHandlerContainer";
export { createUnloadHookContainer, _testHookMaxUnloadHooksCb } from "./JavaScriptSDK/UnloadHookContainer";
export { createTraceParent, parseTraceParent, isValidTraceId, isValidSpanId, isValidTraceParent, isSampledFlag, formatTraceParent, findW3cTraceParent, findAllScripts } from "./JavaScriptSDK/W3cTraceParent";
export { createDynamicConfig, onConfigChange } from "./Config/DynamicConfig";
export { getDynamicConfigHandler, blockDynamicConversion, forceDynamicConversion } from "./Config/DynamicSupport";
export { cfgDfValidate, cfgDfMerge, cfgDfBoolean, cfgDfFunc, cfgDfString, cfgDfSet, cfgDfBlockPropValue } from "./Config/ConfigDefaultHelpers";
//# sourceMappingURL=applicationinsights-core-js.js.map