/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_TO_LOWER_CASE = "toLowerCase"; // Count: 11
export var _DYN_BLK_VAL = "blkVal"; // Count: 5
export var _DYN_LENGTH = "length"; // Count: 55
export var _DYN_RD_ONLY = "rdOnly"; // Count: 4
export var _DYN_NOTIFY = "notify"; // Count: 4
export var _DYN_WARN_TO_CONSOLE = "warnToConsole"; // Count: 4
export var _DYN_THROW_INTERNAL = "throwInternal"; // Count: 5
export var _DYN_SET_DF = "setDf"; // Count: 6
export var _DYN_WATCH = "watch"; // Count: 8
export var _DYN_LOGGER = "logger"; // Count: 21
export var _DYN_APPLY = "apply"; // Count: 7
export var _DYN_PUSH = "push"; // Count: 35
export var _DYN_SPLICE = "splice"; // Count: 8
export var _DYN_HDLR = "hdlr"; // Count: 6
export var _DYN_CANCEL = "cancel"; // Count: 6
export var _DYN_INITIALIZE = "initialize"; // Count: 5
export var _DYN_IDENTIFIER = "identifier"; // Count: 8
export var _DYN_REMOVE_NOTIFICATION_0 = "removeNotificationListener"; // Count: 4
export var _DYN_ADD_NOTIFICATION_LIS1 = "addNotificationListener"; // Count: 4
export var _DYN_IS_INITIALIZED = "isInitialized"; // Count: 10
export var _DYN_INSTRUMENTATION_KEY = "instrumentationKey"; // Count: 2
export var _DYN__INACTIVE = "INACTIVE"; // Count: 3
export var _DYN_VALUE = "value"; // Count: 5
export var _DYN_GET_NOTIFY_MGR = "getNotifyMgr"; // Count: 5
export var _DYN_GET_PLUGIN = "getPlugin"; // Count: 6
export var _DYN_NAME = "name"; // Count: 12
export var _DYN_I_KEY = "iKey"; // Count: 5
export var _DYN_TIME = "time"; // Count: 6
export var _DYN_PROCESS_NEXT = "processNext"; // Count: 15
export var _DYN_GET_PROCESS_TEL_CONT2 = "getProcessTelContext"; // Count: 2
export var _DYN_POLL_INTERNAL_LOGS = "pollInternalLogs"; // Count: 2
export var _DYN_ENABLED = "enabled"; // Count: 6
export var _DYN_STOP_POLLING_INTERNA3 = "stopPollingInternalLogs"; // Count: 2
export var _DYN_UNLOAD = "unload"; // Count: 9
export var _DYN_ON_COMPLETE = "onComplete"; // Count: 5
export var _DYN_VERSION = "version"; // Count: 6
export var _DYN_LOGGING_LEVEL_CONSOL4 = "loggingLevelConsole"; // Count: 2
export var _DYN_CREATE_NEW = "createNew"; // Count: 7
export var _DYN_TEARDOWN = "teardown"; // Count: 9
export var _DYN_MESSAGE_ID = "messageId"; // Count: 4
export var _DYN_MESSAGE = "message"; // Count: 7
export var _DYN_IS_ASYNC = "isAsync"; // Count: 6
export var _DYN_DIAG_LOG = "diagLog"; // Count: 10
export var _DYN__DO_TEARDOWN = "_doTeardown"; // Count: 5
export var _DYN_UPDATE = "update"; // Count: 6
export var _DYN_GET_NEXT = "getNext"; // Count: 12
export var _DYN_SET_NEXT_PLUGIN = "setNextPlugin"; // Count: 5
export var _DYN_PROTOCOL = "protocol"; // Count: 3
export var _DYN_USER_AGENT = "userAgent"; // Count: 5
export var _DYN_SPLIT = "split"; // Count: 7
export var _DYN_NODE_TYPE = "nodeType"; // Count: 3
export var _DYN_REPLACE = "replace"; // Count: 9
export var _DYN_LOG_INTERNAL_MESSAGE = "logInternalMessage"; // Count: 2
export var _DYN_TYPE = "type"; // Count: 14
export var _DYN_HANDLER = "handler"; // Count: 5
export var _DYN_STATUS = "status"; // Count: 5
export var _DYN_GET_RESPONSE_HEADER = "getResponseHeader"; // Count: 2
export var _DYN_GET_ALL_RESPONSE_HEA5 = "getAllResponseHeaders"; // Count: 2
export var _DYN_IS_CHILD_EVT = "isChildEvt"; // Count: 3
export var _DYN_DATA = "data"; // Count: 7
export var _DYN_GET_CTX = "getCtx"; // Count: 6
export var _DYN_SET_CTX = "setCtx"; // Count: 10
export var _DYN_COMPLETE = "complete"; // Count: 3
export var _DYN_ITEMS_RECEIVED = "itemsReceived"; // Count: 3
export var _DYN_URL_STRING = "urlString"; // Count: 5
export var _DYN_SEND_POST = "sendPOST"; // Count: 3
export var _DYN_HEADERS = "headers"; // Count: 5
export var _DYN_TIMEOUT = "timeout"; // Count: 6
export var _DYN_SET_REQUEST_HEADER = "setRequestHeader"; // Count: 2
export var _DYN_TRACE_ID = "traceId"; // Count: 5
export var _DYN_SPAN_ID = "spanId"; // Count: 5
export var _DYN_TRACE_FLAGS = "traceFlags"; // Count: 6
export var _DYN_GET_ATTRIBUTE = "getAttribute"; // Count: 3
//# sourceMappingURL=__DynamicConstants.js.map