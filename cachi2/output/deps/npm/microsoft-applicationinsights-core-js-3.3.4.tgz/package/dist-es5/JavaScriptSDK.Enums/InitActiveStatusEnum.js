/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */
import { createEnumStyle } from "./EnumHelperFuncs";
export var ActiveStatus = createEnumStyle({
    NONE: 0 /* eActiveStatus.NONE */,
    PENDING: 3 /* eActiveStatus.PENDING */,
    INACTIVE: 1 /* eActiveStatus.INACTIVE */,
    ACTIVE: 2 /* eActiveStatus.ACTIVE */
});
//# sourceMappingURL=InitActiveStatusEnum.js.map