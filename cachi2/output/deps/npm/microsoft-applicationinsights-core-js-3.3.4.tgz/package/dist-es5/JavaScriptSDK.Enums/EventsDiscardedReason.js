/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { createEnumStyle } from "../JavaScriptSDK.Enums/EnumHelperFuncs";
/**
 * The EventsDiscardedReason enumeration contains a set of values that specify the reason for discarding an event.
 */
export var EventsDiscardedReason = createEnumStyle({
    /**
     * Unknown.
     */
    Unknown: 0 /* eEventsDiscardedReason.Unknown */,
    /**
     * Status set to non-retryable.
     */
    NonRetryableStatus: 1 /* eEventsDiscardedReason.NonRetryableStatus */,
    /**
     * The event is invalid.
     */
    InvalidEvent: 2 /* eEventsDiscardedReason.InvalidEvent */,
    /**
     * The size of the event is too large.
     */
    SizeLimitExceeded: 3 /* eEventsDiscardedReason.SizeLimitExceeded */,
    /**
     * The server is not accepting events from this instrumentation key.
     */
    KillSwitch: 4 /* eEventsDiscardedReason.KillSwitch */,
    /**
     * The event queue is full.
     */
    QueueFull: 5 /* eEventsDiscardedReason.QueueFull */
});
/**
 *  The eBatchDiscardedReason enumeration contains a set of values that specify the reason for discarding offline batches.
 */
export var BatchDiscardedReason = createEnumStyle({
    /**
     * Unknown.
     */
    Unknown: 0 /* eBatchDiscardedReason.Unknown */,
    /**
      * Status set to non-retryable after sending
      */
    NonRetryableStatus: 1 /* eBatchDiscardedReason.NonRetryableStatus */,
    /**
     * Batches with lower number of critical events are dropped to free up storage space
     */
    CleanStorage: 2 /* eBatchDiscardedReason.CleanStorage */,
    /**
     * The batches in storage exceed max allowed time
     */
    MaxInStorageTimeExceeded: 3 /* eBatchDiscardedReason.MaxInStorageTimeExceeded */
});
//# sourceMappingURL=EventsDiscardedReason.js.map