/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


//  @skip-file-minify
import { createEnumStyle } from "../JavaScriptSDK.Enums/EnumHelperFuncs";
export var LoggingSeverity = createEnumStyle({
    DISABLED: 0 /* eLoggingSeverity.DISABLED */,
    CRITICAL: 1 /* eLoggingSeverity.CRITICAL */,
    WARNING: 2 /* eLoggingSeverity.WARNING */,
    DEBUG: 3 /* eLoggingSeverity.DEBUG */
});
//# sourceMappingURL=LoggingEnums.js.map