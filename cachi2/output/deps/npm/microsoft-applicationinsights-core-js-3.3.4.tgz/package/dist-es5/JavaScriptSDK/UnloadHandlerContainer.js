/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { arrForEach, dumpObj } from "@nevware21/ts-utils";
import { _DYN_DIAG_LOG, _DYN_PUSH } from "../__DynamicConstants";
import { _throwInternal } from "./DiagnosticLogger";
export function createUnloadHandlerContainer() {
    var handlers = [];
    function _addHandler(handler) {
        if (handler) {
            handlers[_DYN_PUSH /* @min:%2epush */](handler);
        }
    }
    function _runHandlers(unloadCtx, unloadState) {
        arrForEach(handlers, function (handler) {
            try {
                handler(unloadCtx, unloadState);
            }
            catch (e) {
                _throwInternal(unloadCtx[_DYN_DIAG_LOG /* @min:%2ediagLog */](), 2 /* eLoggingSeverity.WARNING */, 73 /* _eInternalMessageId.PluginException */, "Unexpected error calling unload handler - " + dumpObj(e));
            }
        });
        handlers = [];
    }
    return {
        add: _addHandler,
        run: _runHandlers
    };
}
//# sourceMappingURL=UnloadHandlerContainer.js.map