/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


export var ChannelControllerPriority = 500;
export var DisabledPropertyName = "Microsoft_ApplicationInsights_BypassAjaxInstrumentation";
// export const SampleRate = "sampleRate";
// export const ProcessLegacy = "ProcessLegacy";
// export const HttpMethod = "http.method";
// export const DEFAULT_BREEZE_ENDPOINT = "https://dc.services.visualstudio.com";
// export const DEFAULT_BREEZE_PATH = "/v2/track";
// export const strNotSpecified = "not_specified";
// export const strIkey = "iKey";
//# sourceMappingURL=Constants.js.map