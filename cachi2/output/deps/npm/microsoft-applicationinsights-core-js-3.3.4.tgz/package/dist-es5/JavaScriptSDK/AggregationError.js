/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { arrForEach, createCustomError, dumpObj } from "@nevware21/ts-utils";
import { _DYN_LENGTH } from "../__DynamicConstants";
var aggregationErrorType;
/**
 * Throws an Aggregation Error which includes all of the errors that led to this error occurring
 * @param message - The message describing the aggregation error (the sourceError details are added to this)
 * @param sourceErrors - An array of the errors that caused this situation
 */
export function throwAggregationError(message, sourceErrors) {
    if (!aggregationErrorType) {
        aggregationErrorType = createCustomError("AggregationError", function (self, args) {
            if (args[_DYN_LENGTH /* @min:%2elength */] > 1) {
                // Save the provided errors
                self.errors = args[1];
            }
        });
    }
    var theMessage = message || "One or more errors occurred.";
    arrForEach(sourceErrors, function (srcError, idx) {
        theMessage += "\n".concat(idx, " > ").concat(dumpObj(srcError));
    });
    throw new aggregationErrorType(theMessage, sourceErrors || []);
}
//# sourceMappingURL=AggregationError.js.map