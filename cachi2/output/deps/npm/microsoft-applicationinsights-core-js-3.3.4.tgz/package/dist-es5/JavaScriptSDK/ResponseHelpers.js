/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { dumpObj } from "@nevware21/ts-utils";
import { _DYN_ITEMS_RECEIVED, _DYN_LENGTH, _DYN_NAME } from "../__DynamicConstants";
import { _throwInternal } from "./DiagnosticLogger";
import { getJSON } from "./EnvUtils";
/**
 * Parses the response from the backend.
 * @param response - XMLHttpRequest or XDomainRequest response
 */
export function parseResponse(response, diagLog) {
    try {
        if (response && response !== "") {
            var result = getJSON().parse(response);
            if (result && result[_DYN_ITEMS_RECEIVED /* @min:%2eitemsReceived */] && result[_DYN_ITEMS_RECEIVED /* @min:%2eitemsReceived */] >= result.itemsAccepted &&
                result.itemsReceived - result.itemsAccepted === result.errors[_DYN_LENGTH /* @min:%2elength */]) {
                return result;
            }
        }
    }
    catch (e) {
        _throwInternal(diagLog, 1 /* eLoggingSeverity.CRITICAL */, 43 /* _eInternalMessageId.InvalidBackendResponse */, "Cannot parse the response. " + (e[_DYN_NAME /* @min:%2ename */] || dumpObj(e)), {
            response: response
        });
    }
    return null;
}
//# sourceMappingURL=ResponseHelpers.js.map