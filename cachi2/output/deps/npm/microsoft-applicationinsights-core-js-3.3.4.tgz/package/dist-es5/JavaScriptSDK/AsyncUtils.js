/*
 * Application Insights JavaScript SDK - Core, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { createPromise, doAwaitResponse } from "@nevware21/ts-async";
import { arrSlice, getLength } from "@nevware21/ts-utils";
import { _DYN_UNLOAD } from "../__DynamicConstants";
/**
 * Run the unload function of the target object if it exists
 * @param target - The target object that contains the unload function
 * @param isAsync - The caller identifies whether it is expecting the operation to complete synchronously or asynchronously. Even
 * if the caller is not waiting the operation may still be performed asynchronously depending on the component and the reverse is
 * also true.
 * @returns The result of the target function
 */
export function runTargetUnload(target, isAsync) {
    if (target && target[_DYN_UNLOAD /* @min:%2eunload */]) {
        return target[_DYN_UNLOAD /* @min:%2eunload */](isAsync);
    }
}
/**
 * Call the unload function on all targets handling any returned [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
 * / Promise before calling the next targets unload
 * @param targets - An array of the targets to unload
 * @param isAsync - The caller identifies whether it is expecting the operations to complete synchronously or asynchronously.  Even
 * if the caller is not waiting the operation may still be performed asynchronously depending on the component and the reverse is
 * also true.
 * @param done - Optional callback function to call once all of the unload functions have been called.
 */
export function doUnloadAll(targets, isAsync, done) {
    var result;
    if (!done) {
        result = createPromise(function (resolved) {
            done = resolved;
        });
    }
    if (targets && getLength(targets) > 0) {
        doAwaitResponse(runTargetUnload(targets[0], isAsync), function () {
            doUnloadAll(arrSlice(targets, 1), isAsync, done);
        });
    }
    else {
        done();
    }
    return result;
}
//# sourceMappingURL=AsyncUtils.js.map