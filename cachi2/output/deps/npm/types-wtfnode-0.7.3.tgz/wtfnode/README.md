# Installation
> `npm install --save @types/wtfnode`

# Summary
This package contains type definitions for wtfnode (https://github.com/myndzi/wtfnode).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/wtfnode.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/wtfnode/index.d.ts)
````ts
export function dump(): void;
export function init(): void;
export function setLogger(type: "info" | "warn" | "error", fn: (message?: any, ...optionalParams: any[]) => void): void;
export function resetLoggers(): void;

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: none

# Credits
These definitions were written by [Piotr Roszatycki](https://github.com/dex4er).
