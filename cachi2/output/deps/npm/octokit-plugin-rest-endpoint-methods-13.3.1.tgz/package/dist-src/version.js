const VERSION = "13.3.1";
export {
  VERSION
};
//# sourceMappingURL=version.js.map
