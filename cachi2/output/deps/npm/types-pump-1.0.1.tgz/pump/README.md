# Installation
> `npm install --save @types/pump`

# Summary
This package contains type definitions for pump (https://github.com/mafintosh/pump).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/pump

Additional Details
 * Last updated: Thu, 30 Mar 2017 22:36:50 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Tomek Łaziuk <https://github.com/tlaziuk>.
