# native-is-elevated

[![NPM](https://nodei.co/npm/native-is-elevated.png?compact=true)](https://nodei.co/npm/native-is-elevated)

Checks if the process is running with elevated privileges (i.e., as root on Unix systems or Administrator on Windows).

Basically just a [native version](https://nodejs.org/api/addons.html) of [is-elevated](https://github.com/sindresorhus/is-elevated) that doesn't spawn a new process on Windows.


## Install

```
$ npm install --save native-is-elevated
```


## Usage

```js
const isElevated = require('native-is-elevated')();  // boolean value
```
