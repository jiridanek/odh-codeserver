// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export function processPassthroughOperationResult(response) {
    return Object.assign(Object.assign({}, response), { done: true });
}
//# sourceMappingURL=passthrough.js.map