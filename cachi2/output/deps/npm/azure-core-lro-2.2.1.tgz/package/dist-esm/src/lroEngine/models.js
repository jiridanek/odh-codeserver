// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export const successStates = ["succeeded"];
export const failureStates = ["failed", "canceled", "cancelled"];
/**
 * The LRO states that signal that the LRO has completed.
 */
export const terminalStates = successStates.concat(failureStates);
//# sourceMappingURL=models.js.map