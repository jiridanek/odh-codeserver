# Installation
> `npm install --save @types/debounce`

# Summary
This package contains type definitions for debounce (https://github.com/component/debounce).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/debounce

Additional Details
 * Last updated: Fri, 21 Apr 2017 15:59:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Denis Sokolov <https://github.com/denis-sokolov>.
