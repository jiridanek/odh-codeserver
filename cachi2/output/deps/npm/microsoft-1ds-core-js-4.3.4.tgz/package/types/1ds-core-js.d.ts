/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 *
 * Microsoft Application Insights Team
 * https://github.com/microsoft/ApplicationInsights-JS#readme
 *
 * ---------------------------------------------------------------------------
 * This is a single combined (rollup) declaration file for the package,
 * if you require a namespace wrapped version it is also available.
 * - Namespaced version: types/1ds-core-js.namespaced.d.ts
 * ---------------------------------------------------------------------------
 */

import { __getRegisteredEvents } from '@microsoft/applicationinsights-core-js';
import { ActiveStatus } from '@microsoft/applicationinsights-core-js';
import { addEventHandler } from '@microsoft/applicationinsights-core-js';
import { addEventListeners } from '@microsoft/applicationinsights-core-js';
import { addPageHideEventListener } from '@microsoft/applicationinsights-core-js';
import { addPageShowEventListener } from '@microsoft/applicationinsights-core-js';
import { addPageUnloadEventListener } from '@microsoft/applicationinsights-core-js';
import { _appendHeader } from '@microsoft/applicationinsights-core-js';
import { areCookiesSupported } from '@microsoft/applicationinsights-core-js';
import { arrForEach } from '@microsoft/applicationinsights-core-js';
import { arrIndexOf } from '@microsoft/applicationinsights-core-js';
import { arrMap } from '@microsoft/applicationinsights-core-js';
import { arrReduce } from '@microsoft/applicationinsights-core-js';
import { attachEvent } from '@microsoft/applicationinsights-core-js';
import { BaseTelemetryPlugin } from '@microsoft/applicationinsights-core-js';
import { blockDynamicConversion } from '@microsoft/applicationinsights-core-js';
import { convertAllHeadersToMap } from '@microsoft/applicationinsights-core-js';
import { createCookieMgr } from '@microsoft/applicationinsights-core-js';
import { createDynamicConfig } from '@microsoft/applicationinsights-core-js';
import { createEnumStyle } from '@microsoft/applicationinsights-core-js';
import { createProcessTelemetryContext } from '@microsoft/applicationinsights-core-js';
import { createTraceParent } from '@microsoft/applicationinsights-core-js';
import { createUniqueNamespace } from '@microsoft/applicationinsights-core-js';
import { createUnloadHandlerContainer } from '@microsoft/applicationinsights-core-js';
import { dateNow } from '@microsoft/applicationinsights-core-js';
import { detachEvent } from '@microsoft/applicationinsights-core-js';
import { DiagnosticLogger } from '@microsoft/applicationinsights-core-js';
import { uaDisallowsSameSiteNone as disallowsSameSiteNone } from '@microsoft/applicationinsights-core-js';
import { doPerf } from '@microsoft/applicationinsights-core-js';
import { dumpObj } from '@microsoft/applicationinsights-core-js';
import { eActiveStatus } from '@microsoft/applicationinsights-core-js';
import { _eInternalMessageId } from '@microsoft/applicationinsights-core-js';
import { eLoggingSeverity } from '@microsoft/applicationinsights-core-js';
import { EnumValue } from '@microsoft/applicationinsights-core-js';
import { eventOff } from '@microsoft/applicationinsights-core-js';
import { eventOn } from '@microsoft/applicationinsights-core-js';
import { EventsDiscardedReason } from '@microsoft/applicationinsights-core-js';
import { findW3cTraceParent } from '@microsoft/applicationinsights-core-js';
import { forceDynamicConversion } from '@microsoft/applicationinsights-core-js';
import { formatErrorMessageXdr } from '@microsoft/applicationinsights-core-js';
import { formatErrorMessageXhr } from '@microsoft/applicationinsights-core-js';
import { formatTraceParent } from '@microsoft/applicationinsights-core-js';
import { generateW3CId } from '@microsoft/applicationinsights-core-js';
import { _getAllResponseHeaders } from '@microsoft/applicationinsights-core-js';
import { getConsole } from '@microsoft/applicationinsights-core-js';
import { getCrypto } from '@microsoft/applicationinsights-core-js';
import { getDocument } from '@microsoft/applicationinsights-core-js';
import { getDynamicConfigHandler } from '@microsoft/applicationinsights-core-js';
import { getExceptionName } from '@microsoft/applicationinsights-core-js';
import { getGlobal } from '@microsoft/applicationinsights-core-js';
import { getGlobalInst } from '@microsoft/applicationinsights-core-js';
import { getHistory } from '@microsoft/applicationinsights-core-js';
import { getIEVersion } from '@microsoft/applicationinsights-core-js';
import { getJSON } from '@microsoft/applicationinsights-core-js';
import { getLocation } from '@microsoft/applicationinsights-core-js';
import { getMsCrypto } from '@microsoft/applicationinsights-core-js';
import { getNavigator } from '@microsoft/applicationinsights-core-js';
import { getPerformance } from '@microsoft/applicationinsights-core-js';
import { getResponseText } from '@microsoft/applicationinsights-core-js';
import { getSetValue } from '@microsoft/applicationinsights-core-js';
import { getWindow } from '@microsoft/applicationinsights-core-js';
import { hasDocument } from '@microsoft/applicationinsights-core-js';
import { hasHistory } from '@microsoft/applicationinsights-core-js';
import { hasJSON } from '@microsoft/applicationinsights-core-js';
import { hasNavigator } from '@microsoft/applicationinsights-core-js';
import { hasOwnProperty } from '@microsoft/applicationinsights-core-js';
import { hasWindow } from '@microsoft/applicationinsights-core-js';
import { IAppInsightsCore } from '@microsoft/applicationinsights-core-js';
import { IBackendResponse } from '@microsoft/applicationinsights-core-js';
import { IChannelControls } from '@microsoft/applicationinsights-core-js';
import { IConfigCheckFn } from '@microsoft/applicationinsights-core-js';
import { IConfigDefaultCheck } from '@microsoft/applicationinsights-core-js';
import { IConfigDefaults } from '@microsoft/applicationinsights-core-js';
import { IConfigSetFn } from '@microsoft/applicationinsights-core-js';
import { IConfiguration } from '@microsoft/applicationinsights-core-js';
import { ICookieMgr } from '@microsoft/applicationinsights-core-js';
import { ICookieMgrConfig } from '@microsoft/applicationinsights-core-js';
import { ICustomProperties } from '@microsoft/applicationinsights-core-js';
import { IDiagnosticLogger } from '@microsoft/applicationinsights-core-js';
import { IDistributedTraceContext } from '@microsoft/applicationinsights-core-js';
import { IDynamicConfigHandler } from '@microsoft/applicationinsights-core-js';
import { IDynamicPropertyHandler } from '@microsoft/applicationinsights-core-js';
import { IInternalOfflineSupport } from '@microsoft/applicationinsights-core-js';
import { _IInternalXhrOverride } from '@microsoft/applicationinsights-core-js';
import { ILegacyUnloadHook } from '@microsoft/applicationinsights-core-js';
import { INotificationListener } from '@microsoft/applicationinsights-core-js';
import { INotificationManager } from '@microsoft/applicationinsights-core-js';
import { AppInsightsCore as InternalAppInsightsCore } from '@microsoft/applicationinsights-core-js';
import { _InternalLogMessage } from '@microsoft/applicationinsights-core-js';
import { _InternalMessageId } from '@microsoft/applicationinsights-core-js';
import { IPayloadData } from '@microsoft/applicationinsights-core-js';
import { IPerfEvent } from '@microsoft/applicationinsights-core-js';
import { IPerfManager } from '@microsoft/applicationinsights-core-js';
import { IPerfManagerProvider } from '@microsoft/applicationinsights-core-js';
import { IPlugin } from '@microsoft/applicationinsights-core-js';
import { IProcessTelemetryContext } from '@microsoft/applicationinsights-core-js';
import { IProcessTelemetryUnloadContext } from '@microsoft/applicationinsights-core-js';
import { _IRegisteredEvents } from '@microsoft/applicationinsights-core-js';
import { isArray } from '@microsoft/applicationinsights-core-js';
import { isBeaconsSupported } from '@microsoft/applicationinsights-core-js';
import { isBoolean } from '@microsoft/applicationinsights-core-js';
import { isDate } from '@microsoft/applicationinsights-core-js';
import { _ISenderOnComplete } from '@microsoft/applicationinsights-core-js';
import { _ISendPostMgrConfig } from '@microsoft/applicationinsights-core-js';
import { isError } from '@microsoft/applicationinsights-core-js';
import { isFetchSupported } from '@microsoft/applicationinsights-core-js';
import { isFunction } from '@microsoft/applicationinsights-core-js';
import { isIE } from '@microsoft/applicationinsights-core-js';
import { isNotTruthy } from '@microsoft/applicationinsights-core-js';
import { isNullOrUndefined } from '@microsoft/applicationinsights-core-js';
import { isNumber } from '@microsoft/applicationinsights-core-js';
import { isObject } from '@microsoft/applicationinsights-core-js';
import { isReactNative } from '@microsoft/applicationinsights-core-js';
import { isSampledFlag } from '@microsoft/applicationinsights-core-js';
import { isString } from '@microsoft/applicationinsights-core-js';
import { isTruthy } from '@microsoft/applicationinsights-core-js';
import { isTypeof } from '@microsoft/applicationinsights-core-js';
import { isUndefined } from '@microsoft/applicationinsights-core-js';
import { isValidSpanId } from '@microsoft/applicationinsights-core-js';
import { isValidTraceId } from '@microsoft/applicationinsights-core-js';
import { isValidTraceParent } from '@microsoft/applicationinsights-core-js';
import { isXhrSupported } from '@microsoft/applicationinsights-core-js';
import { ITelemetryInitializerContainer } from '@microsoft/applicationinsights-core-js';
import { ITelemetryInitializerHandler } from '@microsoft/applicationinsights-core-js';
import { ITelemetryItem } from '@microsoft/applicationinsights-core-js';
import { ITelemetryPlugin } from '@microsoft/applicationinsights-core-js';
import { ITelemetryPluginChain } from '@microsoft/applicationinsights-core-js';
import { ITelemetryUnloadState } from '@microsoft/applicationinsights-core-js';
import { ITelemetryUpdateState } from '@microsoft/applicationinsights-core-js';
import { _ITimeoutOverrideWrapper } from '@microsoft/applicationinsights-core-js';
import { ITimerHandler } from '@nevware21/ts-utils';
import { IUnloadableComponent } from '@microsoft/applicationinsights-core-js';
import { IUnloadHandlerContainer } from '@microsoft/applicationinsights-core-js';
import { IUnloadHook } from '@microsoft/applicationinsights-core-js';
import { IUnloadHookContainer } from '@microsoft/applicationinsights-core-js';
import { IWatchDetails } from '@microsoft/applicationinsights-core-js';
import { IWatcherHandler } from '@microsoft/applicationinsights-core-js';
import { IXDomainRequest } from '@microsoft/applicationinsights-core-js';
import { IXHROverride } from '@microsoft/applicationinsights-core-js';
import { LoggingSeverity } from '@microsoft/applicationinsights-core-js';
import { _logInternalMessage } from '@microsoft/applicationinsights-core-js';
import { mergeEvtNamespace } from '@microsoft/applicationinsights-core-js';
import { MinChannelPriorty } from '@microsoft/applicationinsights-core-js';
import { newGuid } from '@microsoft/applicationinsights-core-js';
import { newId } from '@microsoft/applicationinsights-core-js';
import { normalizeJsName } from '@microsoft/applicationinsights-core-js';
import { NotificationManager } from '@microsoft/applicationinsights-core-js';
import { objDefineAccessors } from '@microsoft/applicationinsights-core-js';
import { objForEachKey } from '@microsoft/applicationinsights-core-js';
import { objFreeze } from '@microsoft/applicationinsights-core-js';
import { objKeys } from '@microsoft/applicationinsights-core-js';
import { objSeal } from '@microsoft/applicationinsights-core-js';
import { OnCompleteCallback } from '@microsoft/applicationinsights-core-js';
import { onConfigChange } from '@microsoft/applicationinsights-core-js';
import { optimizeObject } from '@microsoft/applicationinsights-core-js';
import { parseResponse } from '@microsoft/applicationinsights-core-js';
import { parseTraceParent } from '@microsoft/applicationinsights-core-js';
import { PerfEvent } from '@microsoft/applicationinsights-core-js';
import { PerfManager } from '@microsoft/applicationinsights-core-js';
import { perfNow } from '@microsoft/applicationinsights-core-js';
import { prependTransports } from '@microsoft/applicationinsights-core-js';
import { ProcessTelemetryContext } from '@microsoft/applicationinsights-core-js';
import { proxyAssign } from '@microsoft/applicationinsights-core-js';
import { proxyFunctionAs } from '@microsoft/applicationinsights-core-js';
import { proxyFunctions } from '@microsoft/applicationinsights-core-js';
import { random32 } from '@microsoft/applicationinsights-core-js';
import { randomValue } from '@microsoft/applicationinsights-core-js';
import { removeEventHandler } from '@microsoft/applicationinsights-core-js';
import { removeEventListeners } from '@microsoft/applicationinsights-core-js';
import { removePageHideEventListener } from '@microsoft/applicationinsights-core-js';
import { removePageShowEventListener } from '@microsoft/applicationinsights-core-js';
import { removePageUnloadEventListener } from '@microsoft/applicationinsights-core-js';
import { safeGetCookieMgr } from '@microsoft/applicationinsights-core-js';
import { safeGetLogger } from '@microsoft/applicationinsights-core-js';
import { SenderPostManager } from '@microsoft/applicationinsights-core-js';
import { SendPOSTFunction } from '@microsoft/applicationinsights-core-js';
import { SendRequestReason } from '@microsoft/applicationinsights-core-js';
import { setEnableEnvMocks } from '@microsoft/applicationinsights-core-js';
import { setValue } from '@microsoft/applicationinsights-core-js';
import { strContains } from '@microsoft/applicationinsights-core-js';
import { strEndsWith } from '@microsoft/applicationinsights-core-js';
import { strFunction } from '@microsoft/applicationinsights-core-js';
import { strObject } from '@microsoft/applicationinsights-core-js';
import { strPrototype } from '@microsoft/applicationinsights-core-js';
import { strStartsWith } from '@microsoft/applicationinsights-core-js';
import { strTrim } from '@microsoft/applicationinsights-core-js';
import { strUndefined } from '@microsoft/applicationinsights-core-js';
import { Tags } from '@microsoft/applicationinsights-core-js';
import { TelemetryInitializerFunction } from '@microsoft/applicationinsights-core-js';
import { TelemetryUnloadReason } from '@microsoft/applicationinsights-core-js';
import { _testHookMaxUnloadHooksCb } from '@microsoft/applicationinsights-core-js';
import { throwError } from '@microsoft/applicationinsights-core-js';
import { _throwInternal } from '@microsoft/applicationinsights-core-js';
import { toISOString } from '@microsoft/applicationinsights-core-js';
import { TransportType } from '@microsoft/applicationinsights-core-js';
import { UnloadHandler } from '@microsoft/applicationinsights-core-js';
import { useXDomainRequest } from '@microsoft/applicationinsights-core-js';
import { _warnToConsole } from '@microsoft/applicationinsights-core-js';
import { WatcherFunction } from '@microsoft/applicationinsights-core-js';

export { __getRegisteredEvents }

export { ActiveStatus }

export { addEventHandler }

export { addEventListeners }

export { addPageHideEventListener }

export { addPageShowEventListener }

export { addPageUnloadEventListener }

export { _appendHeader }

/**
 * @group Classes
 * @group Entrypoint
 */
export declare class AppInsightsCore<C extends IExtendedConfiguration = IExtendedConfiguration> extends InternalAppInsightsCore<C> {
    constructor();
    /**
     * Initialize the sdk.
     * @param config - The configuration to initialize the SDK.
     * @param extensions - An array of extensions that are to be used by the core.
     */
    initialize(config: C, extensions: IPlugin[], logger?: IDiagnosticLogger, notificationManager?: INotificationManager): void;
    track(item: IExtendedTelemetryItem | ITelemetryItem): void;
    /**
     * Periodically check logger.queue for
     */
    pollInternalLogs(eventName?: string): ITimerHandler;
}

export { areCookiesSupported }
export { areCookiesSupported as cookieAvailable }

export { arrForEach }

export { arrIndexOf }

export { arrMap }

export { arrReduce }

export { attachEvent }

export { BaseTelemetryPlugin }

export { blockDynamicConversion }

export { convertAllHeadersToMap }

export { createCookieMgr }

export { createDynamicConfig }

export { createEnumStyle }

/**
 * Create a new guid.
 * @param style - The style of guid to generated, defaults to Digits
 * Digits (Default) : 32 digits separated by hyphens: 00000000-0000-0000-0000-000000000000
 * Braces - 32 digits separated by hyphens, enclosed in braces: {00000000-0000-0000-0000-000000000000}
 * Parentheses - 32 digits separated by hyphens, enclosed in parentheses: (00000000-0000-0000-0000-000000000000)
 * Numeric - 32 digits: 00000000000000000000000000000000
 * @returns The formatted guid.
 */
export declare function createGuid(style?: GuidStyle): string;

export { createProcessTelemetryContext }

export { createTraceParent }

export { createUniqueNamespace }

export { createUnloadHandlerContainer }

export { dateNow }

export { detachEvent }

export { DiagnosticLogger }

export { disallowsSameSiteNone }

export { doPerf }

export { dumpObj }

export { eActiveStatus }

/**
 * Enum for property types.
 */
export declare const enum eEventPropertyType {
    Unspecified = 0,
    String = 1,
    Int32 = 2,
    UInt32 = 3,
    Int64 = 4,
    UInt64 = 5,
    Double = 6,
    Bool = 7,
    Guid = 8,
    DateTime = 9
}

export declare const enum _eExtendedInternalMessageId {
    AuthHandShakeError = 501,
    AuthRedirectFail = 502,
    BrowserCannotReadLocalStorage = 503,
    BrowserCannotWriteLocalStorage = 504,
    BrowserDoesNotSupportLocalStorage = 505,
    CannotParseBiBlobValue = 506,
    CannotParseDataAttribute = 507,
    CVPluginNotAvailable = 508,
    DroppedEvent = 509,
    ErrorParsingAISessionCookie = 510,
    ErrorProvidedChannels = 511,
    FailedToGetCookies = 512,
    FailedToInitializeCorrelationVector = 513,
    FailedToInitializeSDK = 514,
    InvalidContentBlob = 515,
    InvalidCorrelationValue = 516,
    SessionRenewalDateIsZero = 517,
    SendPostOnCompleteFailure = 518,
    PostResponseHandler = 519,
    SDKNotInitialized = 520
}

export { _eInternalMessageId }

export { eLoggingSeverity }

/**
 * The TraceLevel contains a set of values that specify the trace level for the trace messages.
 */
export declare const enum eTraceLevel {
    /**
     * None.
     */
    NONE = 0,
    /**
     * Error trace.
     */
    ERROR = 1,
    /**
     * Warning trace.
     */
    WARNING = 2,
    /**
     * Information trace.
     */
    INFORMATION = 3
}

/**
 * The eValueKind contains a set of values that specify value kind of the property.
 * Either PII (Personal Identifiable Information) or customer content.
 */
export declare const enum eValueKind {
    /**
     * No kind.
     */
    NotSet = 0,
    /**
     * An LDAP distinguished name. For example, CN=Jeff Smith,OU=Sales,DC=Fabrikam,DC=COM.
     */
    Pii_DistinguishedName = 1,
    /**
     * Generic information.
     */
    Pii_GenericData = 2,
    /**
     * An IPV4 Internet address. For example, 192.0.2.1.
     */
    Pii_IPV4Address = 3,
    /**
     * An IPV6 Internet address. For example, 2001:0db8:85a3:0000:0000:8a2e:0370:7334.
     */
    Pii_IPv6Address = 4,
    /**
     * The Subject of an e-mail message.
     */
    Pii_MailSubject = 5,
    /**
     * A telephone number.
     */
    Pii_PhoneNumber = 6,
    /**
     * A query string.
     */
    Pii_QueryString = 7,
    /**
     * An SIP (Session Internet Protocol) address.
     */
    Pii_SipAddress = 8,
    /**
     * An e-mail address.
     */
    Pii_SmtpAddress = 9,
    /**
     * An user ID.
     */
    Pii_Identity = 10,
    /**
     * A URI (Uniform Resource Identifier).
     */
    Pii_Uri = 11,
    /**
     * The fully-qualified domain name.
     */
    Pii_Fqdn = 12,
    /**
     * Scrubs the last octet in a IPV4 Internet address.
     * For example: 10.121.227.147 becomes 10.121.227.*
     */
    Pii_IPV4AddressLegacy = 13,
    /**
     * Scrubs the last 4 Hextets (last 64-bits) of an IPv6 address
     */
    Pii_IPv6ScrubLastHextets = 14,
    /**
     * Drops the value altogether, rather than hashing
     */
    Pii_DropValue = 15,
    /**
     * Generic content.
     */
    CustomerContent_GenericContent = 32
}

/**
 * The EventLatency contains a set of values that specify the latency with which an event is sent.
 */
export declare const EventLatency: EnumValue<typeof EventLatencyValue>;

export declare type EventLatency = number | EventLatencyValue;

/**
 * The EventLatency contains a set of values that specify the latency with which an event is sent.
 */
export declare const enum EventLatencyValue {
    /**
     * Normal latency.
     */
    Normal = 1,
    /**
     * Cost deferred latency. At the moment this latency is treated as Normal latency.
     */
    CostDeferred = 2,
    /**
     * Real time latency.
     */
    RealTime = 3,
    /**
     * Bypass normal batching/timing and send as soon as possible, this will still send asynchronously.
     * Added in v3.1.1
     */
    Immediate = 4
}

export { eventOff }

export { eventOn }

/**
 * The EventPersistence contains a set of values that specify the event's persistence.
 */
export declare const EventPersistence: EnumValue<typeof EventPersistenceValue>;

export declare type EventPersistence = number | EventPersistenceValue;

/**
 * The EventPersistence contains a set of values that specify the event's persistence.
 */
export declare const enum EventPersistenceValue {
    /**
     * Normal persistence.
     */
    Normal = 1,
    /**
     * Critical persistence.
     */
    Critical = 2
}

/**
 * Enum for property types.
 */
export declare const EventPropertyType: EnumValue<typeof eEventPropertyType>;

export declare type EventPropertyType = number | eEventPropertyType;

export { EventsDiscardedReason }

/**
 * Define a specific way to send an event synchronously
 */
export declare const enum EventSendType {
    /**
     * Batch and send the event asynchronously, this is the same as either setting the event `sync` flag to false or not setting at all.
     */
    Batched = 0,
    /**
     * Attempt to send the event synchronously, this is the same as setting the event `sync` flag to true
     */
    Synchronous = 1,
    /**
     * Attempt to send the event synchronously with a preference for the sendBeacon() API.
     * As per the specification, the payload of the event (when converted to JSON) must not be larger than 64kb,
     * the sendHook is also not supported or used when sendBeacon.
     */
    SendBeacon = 2,
    /**
     * Attempt to send the event synchronously with a preference for the fetch() API with the keepalive flag,
     * the SDK checks to ensure that the fetch() implementation supports the 'keepalive' flag and if not it
     * will fallback to either sendBeacon() or a synchronous XHR request.
     * As per the specification, the payload of the event (when converted to JSON) must not be larger than 64kb.
     * Note: Not all browsers support the keepalive flag so for those environments the events may still fail
     */
    SyncFetch = 3
}

/**
 * Pass in the objects to merge as arguments.
 * @param obj1 - object to merge.  Set this argument to 'true' for a deep extend.
 * @param obj2 - object to merge.
 * @param obj3 - object to merge.
 * @param obj4 - object to merge.
 * @param obj5 - object to merge.
 * @returns The extended object.
 */
export declare function extend(obj?: any, obj2?: any, obj3?: any, obj4?: any, obj5?: any): any;

export declare type _ExtendedInternalMessageId = number | _eExtendedInternalMessageId | _eInternalMessageId;

export declare type FieldValueSanitizerFunc = (details: IFieldSanitizerDetails) => IEventProperty | null;

export declare const enum FieldValueSanitizerType {
    NotSet = 0,
    String = 1,
    Number = 2,
    Boolean = 3,
    Object = 4,
    Array = 4096,
    EventProperty = 8192
}

export declare type FieldValueSanitizerTypes = string | number | boolean | object | string[] | number[] | boolean[] | IEventProperty;

export { findW3cTraceParent }

export { forceDynamicConversion }

export { formatErrorMessageXdr }

export { formatErrorMessageXhr }

export { formatTraceParent }

export declare const FullVersionString: string;

export { generateW3CId }

export { _getAllResponseHeaders }

export declare function getCommonSchemaMetaData(value: string | boolean | number | string[] | number[] | boolean[] | undefined, kind: number | undefined, type?: number | undefined): number;

export { getConsole }

/**
 * Helper to get and decode the cookie value using decodeURIComponent, this is for historical
 * backward compatibility where the document.cookie value was decoded before parsing.
 * @param cookieMgr - The cookie manager to use
 * @param name - The name of the cookie to get
 * @param decode - A flag to indicate whether the cookie value should be decoded
 * @returns The decoded cookie value (if available) otherwise an empty string.
 */
export declare function getCookieValue(cookieMgr: ICookieMgr, name: string, decode?: boolean): string;

export { getCrypto }

export { getDocument }

export { getDynamicConfigHandler }

export { getExceptionName }

/**
 * Returns a bitwise value for the FieldValueSanitizerType enum representing the decoded type of the passed value
 * @param value The value to determine the type
 */
export declare function getFieldValueType(value: any): FieldValueSanitizerType;

export { getGlobal }

export { getGlobalInst }

export { getHistory }

export { getIEVersion }

export { getJSON }

export { getLocation }

export { getMsCrypto }

export { getNavigator }

export { getPerformance }

export { getResponseText }

export { getSetValue }

/**
 * Gets the tenant id from the tenant token.
 * @param apiKey - The token from which the tenant id is to be extracted.
 * @returns The tenant id.
 */
export declare function getTenantId(apiKey: string | undefined): string;

export declare let getTime: typeof perfNow;

export { getWindow }

export declare const enum GuidStyle {
    Numeric = "N",
    Digits = "D",
    Braces = "B",
    Parentheses = "P"
}

export { hasDocument }

export { hasHistory }

export { hasJSON }

export { hasNavigator }

export { hasOwnProperty }

export { hasWindow }

export { IAppInsightsCore }

export { IBackendResponse }

export { IChannelControls }

export { IConfigCheckFn }

export { IConfigDefaultCheck }

export { IConfigDefaults }

export { IConfigSetFn }

export { IConfiguration }

export { ICookieMgr }

export { ICookieMgrConfig }

export { ICustomProperties }

export { IDiagnosticLogger }

export { IDistributedTraceContext }

export { IDynamicConfigHandler }

export { IDynamicPropertyHandler }

/**
 * An interface used to create an event property value along with tagging it as PII, or customer content.
 * <b>Caution:</b> Customer content and PII are mutually exclusive. You can use only one of them at a time.
 * If you use both, then the property will be considered invalid, and therefore won't be sent.
 */
export declare interface IEventProperty {
    /**
     * The value for the property.
     */
    value: string | number | boolean | string[] | number[] | boolean[];
    /**
     * [Optional] The value kind associated with property value. The constant enum ValueKind should be used to specify the
     * different kinds.
     */
    kind?: number;
    /**
     * [Optional] The data type for the property. Valid values accepted by onecollector are
     * "string", "bool", "double", "int64", "datetime", "guid".
     *  The EventPropertyType constant enum should be used to specify the different property type values.
     */
    propertyType?: number;
}

/**
 * An interface used for telemetry event timings.
 */
export declare interface IEventTiming {
    /**
     * Time when 1DS Core calls track
     */
    trackStart?: number;
    /**
     * Array of times when each plugin configured in 1DS calls processTelemetry method
     */
    processTelemetryStart?: {
        [key: string]: number;
    };
    /**
     * Array of times when a specific channel tried to send the telemetry to configured endpoint
     */
    sendEventStart?: {
        [key: string]: number;
    };
    /**
     * Array of times when a specific channel received a response from endpoint or request timed out
     */
    sendEventCompleted?: {
        [key: string]: number;
    };
    /**
     * Array of times when a specific channel started serialization of the telemetry event
     */
    serializationStart?: {
        [key: string]: number;
    };
    /**
     * Array of times when a specific channel completed serialization of the telemetry event
     */
    serializationCompleted?: {
        [key: string]: number;
    };
}

/**
 * The IExtendedConfiguration interface holds the configuration details passed to core during initialize.
 */
export declare interface IExtendedConfiguration extends IConfiguration {
    /**
     * [Optional] The property storage override that should be used to store
     * internal SDK properties, otherwise stored as cookies. It is needed where cookies are not available.
     */
    propertyStorageOverride?: IPropertyStorageOverride;
    /**
     * [Optional] A boolean that indicated whether to disable the use of cookies by the 1DS Web SDK. The cookies added by the SDK are
     * MicrosoftApplicationsTelemetryDeviceId. If cookies are disabled, then session events are not sent unless propertyStorageOverride
     * is provided to store the values elsewhere.
     */
    disableCookiesUsage?: boolean;
    /**
     * [Optional] Name of the Anon cookie.  The value will be set in the qsp header to collector requests.  Collector will use this value to look for specific cookie to use for anid property.
     */
    anonCookieName?: string;
    /**
     * [Optional] Disables additional internal event timings that are added during processing of events, the timings are not sent as part telemetry items to the server
     */
    disableEventTimings?: boolean;
    /**
     * [Optional] Enables support for objects with compound keys which indirectly represent an object where the "key" of the object contains a "." as part of it's name.
     * @example
     * ```typescript
     * event: { "somedata.embeddedvalue": 123 }
     * ```
     */
    enableCompoundKey?: boolean;
    /**
     * Add "&w=0" parameter to support UA Parsing when web-workers don't have access to Document.
     * Default is false
     */
    enableWParam?: boolean;
}

/**
 * An interface used to create an event, along with its name, properties, type, timestamp, and priority.
 */
export declare interface IExtendedTelemetryItem extends ITelemetryItem {
    /**
     * Properties to be captured about the telemetry item.
     * Custom properties (alternatively referred to as Part C properties for a Common Schema event) can be
     * directly added under data.
     */
    data?: {
        [key: string]: string | number | boolean | string[] | number[] | boolean[] | IEventProperty | object;
    };
    /**
     * Telemetry properties pertaining to domain about which data is being captured. Example, duration, referrerUri for browser page.
     * These are alternatively referred to as Part B properties for a Common Schema event.
     */
    baseData?: {
        [key: string]: string | number | boolean | string[] | number[] | boolean[] | IEventProperty | object;
    };
    /**
     * An EventLatency value, that specifies the latency for the event.The EventLatency constant should be
     * used to specify the different latency values.
     */
    latency?: number | EventLatencyValue;
    /**
     * [Optional] An EventPersistence value, that specifies the persistence for the event. The EventPersistence constant
     * should be used to specify the different persistence values.
     */
    persistence?: number | EventPersistenceValue;
    /**
     * [Optional] A boolean that specifies whether the event should be sent as a sync request.
     */
    sync?: boolean | EventSendType;
    /**
     * [Optional] A timings object.
     */
    timings?: IEventTiming;
}

/**
 * This interface defines the object that is passed to any provided FieldValueSanitizerFunc, it provides not only the value to be sanitized but also
 * some context about the value like it's location within the envelope (serialized object), the format is defined via the
 * [Common Schema 4.0](https://aka.ms/CommonSchema) specification.
 */
export declare interface IFieldSanitizerDetails {
    /**
     * The path within the event where the value is stored
     */
    path: string;
    /**
     * The name of the field with the event path that will store the value
     */
    name: string;
    /**
     * Identifies the type of the property value
     */
    type: FieldValueSanitizerType;
    /**
     * The value for the property.
     */
    prop: IEventProperty;
    /**
     * A reference to the value sanitizer that created the details
     */
    sanitizer: IValueSanitizer;
}

/**
 * This interface is used during the serialization of individual fields when converting the events into envelope (serialized object) which is sent to the services,
 * the format is defined via the [Common Schema 4.0](https://aka.ms/CommonSchema) specification. The path and field names used are based
 * on how the data is serialized to the service (CS 4.0 location) and not specifically the location on the event object you pass into the track methods (unless they are the same).
 */
export declare interface IFieldValueSanitizerProvider {
    /**
     * Does this field value sanitizer handle this path / field combination
     * @param path - The field path
     * @param name - The name of the field
     */
    handleField(path: string, name: string): boolean;
    /**
     * Get the field sanitizer for this type of field based on the field type, value kind and/or event property type
     * @param path - The field path
     * @param name - The name of the field
     * @param theType - The type of field
     * @param theKind - The value kind of the field
     * @param propType - The property type of the field
     */
    getSanitizer(path: string, name: string, theType: FieldValueSanitizerType, theKind?: number, propType?: number): FieldValueSanitizerFunc | null | undefined;
}

export { IInternalOfflineSupport }

export { _IInternalXhrOverride }

export { ILegacyUnloadHook }

export { INotificationListener }

export { INotificationManager }

export { InternalAppInsightsCore }

export { _InternalLogMessage }

export { _InternalMessageId }

export { IPayloadData }

export { IPerfEvent }

export { IPerfManager }

export { IPerfManagerProvider }

export { IPlugin }

export { IProcessTelemetryContext }

export { IProcessTelemetryUnloadContext }

/**
 * The IPropertyStorageOverride interface provides a custom interface for storing internal SDK properties - otherwise they are
 * stored as cookies.
 * You need this interface when you intend to run auto collection for common properties, or when you log a session in
 * a non browser environment.
 */
export declare interface IPropertyStorageOverride {
    /**
     * A function for passing key value pairs to be stored.
     * @param key   - The key for the key value pair.
     * @param value - The value for the key value pair.
     */
    setProperty: (key: string, value: string) => void;
    /**
     * A function that gets a value for a given key.
     * @param key - The key for which the value must be fetched.
     */
    getProperty: (key: string) => string;
}

export { _IRegisteredEvents }

export { isArray }

export declare function isArrayValid(value: any[]): boolean;

export { isBeaconsSupported }

export { isBoolean }

/**
 * Helper to identify whether we are running in a chromium based browser environment
 */
export declare function isChromium(): boolean;

export { isDate }

/**
 * Checks if document object is available
 */
export declare const isDocumentObjectAvailable: boolean;

export { _ISenderOnComplete }

export { _ISendPostMgrConfig }

export { isError }

export { isFetchSupported }

export { isFunction }

/**
 * Check to see if the value is > 0
 * @param value - The value to check
 * @returns true if > 0 otherwise false
 */
export declare function isGreaterThanZero(value: number): boolean;

export { isIE }

/**
 * Checks if the value is a valid EventLatency.
 * @param value - The value that needs to be checked.
 * @returns True if the value is in AWTEventLatency, false otherwise.
 */
export declare function isLatency(value: EventLatency | undefined): boolean;

export { isNotTruthy }

export { isNullOrUndefined }

export { isNumber }

export { isObject }

export { isReactNative }

export { isSampledFlag }

export { isString }

export { isTruthy }

export { isTypeof }

/**
 * Checks if Uint8Array are available in the current environment. Safari and Firefox along with
 * ReactNative are known to not support Uint8Array properly.
 * @returns True if available, false otherwise.
 */
export declare function isUint8ArrayAvailable(): boolean;

export { isUndefined }

export { isValidSpanId }

export { isValidTraceId }

export { isValidTraceParent }

/**
 * Checks if value is assigned to the given param.
 * @param value - The token from which the tenant id is to be extracted.
 * @returns True/false denoting if value is assigned to the param.
 */
export declare function isValueAssigned(value: any): boolean;

export declare function isValueKind(value: number | undefined): boolean;

/**
 * Checks if window object is available
 */
export declare const isWindowObjectAvailable: boolean;

export { isXhrSupported }

export { ITelemetryInitializerContainer }

export { ITelemetryInitializerHandler }

export { ITelemetryItem }

export { ITelemetryPlugin }

export { ITelemetryPluginChain }

export { ITelemetryUnloadState }

export { ITelemetryUpdateState }

export { _ITimeoutOverrideWrapper }

export { IUnloadableComponent }

export { IUnloadHandlerContainer }

export { IUnloadHook }

export { IUnloadHookContainer }

/**
 * This interface is used during the serialization of events into envelope (serialized object) which is sent to the services, the format is defined via the
 * [Common Schema 4.0](https://aka.ms/CommonSchema) specification. The path and field names used are based on how the data is serialized
 * to the service (CS 4.0 location) and not specifically the location on the event object you pass into the track methods (unless they are the same).
 */
export declare interface IValueSanitizer {
    /**
     * Add a value sanitizer as a fallback sanitizer if this sanitizer can't handle the path/name.
     */
    addSanitizer: (sanitizer: IValueSanitizer) => void;
    /**
     * Adds a field sanitizer to the evaluation list
     */
    addFieldSanitizer: (fieldSanitizer: IFieldValueSanitizerProvider) => void;
    /**
     * Removes the value sanitizer as a fallback sanitizer if this sanitizer can't handle the path/name if present.
     */
    rmSanitizer: (theSanitizer: IValueSanitizer) => void;
    /**
     * Removes the field sanitizer to the evaluation list if present
     */
    rmFieldSanitizer: (theFieldSanitizer: IFieldValueSanitizerProvider) => void;
    /**
     * Does this field value sanitizer handle this path / field combination
     * @param path - The field path
     * @param name - The name of the field
     */
    handleField: (path: string, name: string) => boolean;
    /**
     * Sanitizes the value. It checks the that the property name and value are valid. It also
     * checks/populates the correct type and pii of the property value.
     * @param path - The root path of the property
     * @param name - The property name.
     * @param value - The property value or an IEventProperty containing value, type ,pii and customer content.
     * @param stringifyObjects - If supplied tells the sanitizer that it should JSON stringify() objects
     * @returns IEventProperty containing valid name, value, pii and type or null if invalid.
     */
    value: (path: string, name: string, value: FieldValueSanitizerTypes, stringifyObjects?: boolean) => IEventProperty | null;
    /**
     * Sanitizes the Property. It checks the that the property name and value are valid. It also
     * checks/populates the correct type and pii of the property value.
     * @param path - The root path of the property
     * @param name - The property name.
     * @param property - The property value or an IEventProperty containing value, type ,pii and customer content.
     * @param stringifyObjects - If supplied tells the sanitizer that it should JSON stringify() objects
     * @returns IEventProperty containing valid name, value, pii and type or null if invalid.
     */
    property: (path: string, name: string, property: IEventProperty, stringifyObjects?: boolean) => IEventProperty | null;
}

export { IWatchDetails }

export { IWatcherHandler }

export { IXDomainRequest }

export { IXHROverride }

export { LoggingSeverity }

export { _logInternalMessage }

export { mergeEvtNamespace }

export { MinChannelPriorty }

export { newGuid }

export { newId }

export { normalizeJsName }

export { NotificationManager }

export { objDefineAccessors }

export { objForEachKey }

export { objFreeze }

export { objKeys }

export { objSeal }

export { OnCompleteCallback }

export { onConfigChange }

/**
 * Create and open an XMLHttpRequest object
 * @param method - The request method
 * @param urlString - The url
 * @param withCredentials - Option flag indicating that credentials should be sent
 * @param disabled - Optional flag indicating that the XHR object should be marked as disabled and not tracked (default is false)
 * @param isSync - Optional flag indicating if the instance should be a synchronous request (defaults to false)
 * @param timeout - Optional value identifying the timeout value that should be assigned to the XHR request
 * @returns A new opened XHR request
 */
export declare function openXhr(method: string, urlString: string, withCredentials?: boolean, disabled?: boolean, isSync?: boolean, timeout?: number): XMLHttpRequest;

export { optimizeObject }

export { parseResponse }

export { parseTraceParent }

export { PerfEvent }

export { PerfManager }

export { perfNow }

export { prependTransports }

export { ProcessTelemetryContext }

export { proxyAssign }

export { proxyFunctionAs }

export { proxyFunctions }

export { random32 }

export { randomValue }

export { removeEventHandler }

export { removeEventListeners }

export { removePageHideEventListener }

export { removePageShowEventListener }

export { removePageUnloadEventListener }

export { safeGetCookieMgr }

export { safeGetLogger }

/**
 * Sanitizes the Property. It checks the that the property name and value are valid. It also
 * checks/populates the correct type and pii of the property value.
 * @param name - property name                          - The property name.
 * @param property - The property value or an IEventProperty containing value,
 * type ,pii and customer content.
 * @returns IEventProperty containing valid name, value, pii and type or null if invalid.
 */
export declare function sanitizeProperty(name: string, property: string | number | boolean | string[] | number[] | boolean[] | object | IEventProperty, stringifyObjects?: boolean): IEventProperty | null;

export { SenderPostManager }

export { SendPOSTFunction }

export { SendRequestReason }

export { setEnableEnvMocks }

export declare function setProcessTelemetryTimings(event: ITelemetryItem, identifier: string): void;

export { setValue }

export { strContains }

export { strEndsWith }

export { strFunction }

export { strObject }

export { strPrototype }

export { strStartsWith }

export { strTrim }

export { strUndefined as Undefined }
export { strUndefined }

export { Tags }

export { TelemetryInitializerFunction }

export { TelemetryUnloadReason }

export { _testHookMaxUnloadHooksCb }

export { throwError }

export { _throwInternal }

export { toISOString as getISOString }
export { toISOString }

export declare const TraceLevel: EnumValue<typeof eTraceLevel>;

export declare type TraceLevel = number | eTraceLevel;

export { TransportType }

export { UnloadHandler }

export { useXDomainRequest }

/**
 * The ValueKind contains a set of values that specify value kind of the property.
 * Either PII (Personal Identifiable Information) or customer content.
 */
export declare const ValueKind: EnumValue<typeof eValueKind>;

export declare type ValueKind = number | eValueKind;

export declare class ValueSanitizer implements IValueSanitizer {
    static getFieldType: typeof getFieldValueType;
    /**
     * Clear the current value sanitizer cache.
     */
    clearCache: () => void;
    /**
     * Add a value sanitizer as a fallback sanitizer if this sanitizer can't handle the path/name.
     */
    addSanitizer: (sanitizer: IValueSanitizer) => void;
    /**
     * Adds a field sanitizer to the evaluation list
     */
    addFieldSanitizer: (fieldSanitizer: IFieldValueSanitizerProvider) => void;
    /**
     * Removes the value sanitizer as a fallback sanitizer if this sanitizer can't handle the path/name if present.
     */
    rmSanitizer: (theSanitizer: IValueSanitizer) => void;
    /**
     * Removes the field sanitizer to the evaluation list if present
     */
    rmFieldSanitizer: (theFieldSanitizer: IFieldValueSanitizerProvider) => void;
    /**
     * Does this field value sanitizer handle this path / field combination
     * @param path - The field path
     * @param name - The name of the field
     */
    handleField: (path: string, name: string) => boolean;
    /**
     * Sanitizes the value. It checks the that the property name and value are valid. It also
     * checks/populates the correct type and pii of the property value.
     * @param path - The root path of the property
     * @param name - The property name.
     * @param value - The property value or an IEventProperty containing value, type ,pii and customer content.
     * @param stringifyObjects - If supplied tells the sanitizer that it should JSON stringify() objects
     * @returns IEventProperty containing valid name, value, pii and type or null if invalid.
     */
    value: (path: string, name: string, value: FieldValueSanitizerTypes, stringifyObjects?: boolean) => IEventProperty | null;
    /**
     * Sanitizes the Property. It checks the that the property name and value are valid. It also
     * checks/populates the correct type and pii of the property value.
     * @param path - The root path of the property
     * @param name - The property name.
     * @param property - The property value or an IEventProperty containing value, type ,pii and customer content.
     * @param stringifyObjects - If supplied tells the sanitizer that it should JSON stringify() objects
     * @returns IEventProperty containing valid name, value, pii and type or null if invalid.
     */
    property: (path: string, name: string, property: IEventProperty, stringifyObjects?: boolean) => IEventProperty | null;
    /**
     * Returns whether this ValueSanitizer is empty
     * @return `true` if it contains no chained sanitizers or field sanitizers, otherwise `false`
     */
    isEmpty?: () => boolean;
    constructor(fieldSanitizerProvider?: IFieldValueSanitizerProvider);
}

export declare const Version = "4.3.4";

export { _warnToConsole }

export { WatcherFunction }

export { }
