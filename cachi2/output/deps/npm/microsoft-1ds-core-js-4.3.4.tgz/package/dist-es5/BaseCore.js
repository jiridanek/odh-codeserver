/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
import { __extendsFn as __extends } from "@microsoft/applicationinsights-shims";
/**
* BaseCore.ts
* Base Core is a subset of 1DS Web SDK Core. The purpose of Base Core is to generate a smaller bundle size while providing essential features of Core. Features that are not included in Base Core are:
* 1. Internal logging
* 2. Sending notifications on telemetry sent/discarded
* @author Abhilash Panwar (abpanwar) Hector Hernandez (hectorh)
* @copyright Microsoft 2018
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { AppInsightsCore as InternalCore, _throwInternal, createDynamicConfig, dumpObj } from "@microsoft/applicationinsights-core-js";
import { objDeepFreeze } from "@nevware21/ts-utils";
import { STR_DEFAULT_ENDPOINT_URL } from "./InternalConstants";
import { FullVersionString } from "./Utils";
import { _DYN_INITIALIZE, _DYN_LOGGER, _DYN_POLL_INTERNAL_LOGS } from "./__DynamicConstants";
/**
 * The default settings for the config.
 * WE MUST include all defaults here to ensure that the config is created with all of the properties
 * defined as dynamic.
 */
var defaultConfig = objDeepFreeze({
    endpointUrl: STR_DEFAULT_ENDPOINT_URL
});
var BaseCore = /** @class */ (function (_super) {
    __extends(BaseCore, _super);
    function BaseCore() {
        var _this = _super.call(this) || this;
        dynamicProto(BaseCore, _this, function (_self, _base) {
            _self[_DYN_INITIALIZE /* @min:%2einitialize */] = function (config, extensions, logger, notificationManager) {
                try {
                    _base[_DYN_INITIALIZE /* @min:%2einitialize */](createDynamicConfig(config, defaultConfig, logger || _self[_DYN_LOGGER /* @min:%2elogger */], false).cfg, extensions, logger, notificationManager);
                }
                catch (e) {
                    _throwInternal(_self[_DYN_LOGGER /* @min:%2elogger */], 1 /* eLoggingSeverity.CRITICAL */, 514 /* _eExtendedInternalMessageId.FailedToInitializeSDK */, "Initialization Failed: " + dumpObj(e) + "\n - Note: Channels must be provided through config.channels only");
                }
            };
            _self.track = function (item) {
                var telemetryItem = item;
                if (telemetryItem) {
                    var ext = telemetryItem.ext = telemetryItem.ext || {};
                    ext.sdk = ext.sdk || {};
                    ext.sdk.ver = FullVersionString;
                }
                _base.track(telemetryItem);
            };
            _self[_DYN_POLL_INTERNAL_LOGS /* @min:%2epollInternalLogs */] = function (eventName) {
                return _base[_DYN_POLL_INTERNAL_LOGS /* @min:%2epollInternalLogs */](eventName || "InternalLog");
            };
        });
        return _this;
    }
// Removed Stub for BaseCore.prototype.initialize.
// Removed Stub for BaseCore.prototype.track.
// Removed Stub for BaseCore.prototype.pollInternalLogs.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    BaseCore.__ieDyn=1;

    return BaseCore;
}(InternalCore));
export { BaseCore };
//# sourceMappingURL=BaseCore.js.map