/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */

// Licensed under the MIT License.
// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_INITIALIZE = "initialize"; // Count: 4
export var _DYN_LOGGER = "logger"; // Count: 4
export var _DYN_INDEX_OF = "indexOf"; // Count: 4
export var _DYN_TIMINGS = "timings"; // Count: 4
export var _DYN_POLL_INTERNAL_LOGS = "pollInternalLogs"; // Count: 4
export var _DYN_VALUE = "value"; // Count: 20
export var _DYN_KIND = "kind"; // Count: 5
export var _DYN_LENGTH = "length"; // Count: 7
export var _DYN_PROCESS_TELEMETRY_ST0 = "processTelemetryStart"; // Count: 3
export var _DYN_HANDLE_FIELD = "handleField"; // Count: 3
export var _DYN_RM_SANITIZER = "rmSanitizer"; // Count: 3
export var _DYN_RM_FIELD_SANITIZER = "rmFieldSanitizer"; // Count: 3
export var _DYN_CAN_HANDLE = "canHandle"; // Count: 7
//# sourceMappingURL=__DynamicConstants.js.map