/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
import { __extendsFn as __extends } from "@microsoft/applicationinsights-shims";
/**
* AppInsightsCore.ts
* @author Abhilash Panwar (abpanwar) Hector Hernandez (hectorh)
* @copyright Microsoft 2018
*/
import dynamicProto from "@microsoft/dynamicproto-js";
import { AppInsightsCore as InternalCore, _throwInternal, createDynamicConfig, doPerf, dumpObj, throwError } from "@microsoft/applicationinsights-core-js";
import { objDeepFreeze } from "@nevware21/ts-utils";
import { STR_DEFAULT_ENDPOINT_URL, STR_EMPTY, STR_PROPERTIES, STR_VERSION } from "./InternalConstants";
import { FullVersionString, getTime, isLatency } from "./Utils";
import { _DYN_INDEX_OF, _DYN_INITIALIZE, _DYN_LOGGER, _DYN_POLL_INTERNAL_LOGS, _DYN_TIMINGS } from "./__DynamicConstants";
/**
 * The default settings for the config.
 * WE MUST include all defaults here to ensure that the config is created with all of the properties
 * defined as dynamic.
 */
var defaultConfig = objDeepFreeze({
    endpointUrl: STR_DEFAULT_ENDPOINT_URL,
    propertyStorageOverride: { isVal: _chkPropOverride }
});
function _chkPropOverride(propertyStorageOverride) {
    // Validate property storage override
    if (propertyStorageOverride && (!propertyStorageOverride.getProperty || !propertyStorageOverride.setProperty)) {
        throwError("Invalid property storage override passed.");
    }
    return true;
}
/**
 * @group Classes
 * @group Entrypoint
 */
var AppInsightsCore = /** @class */ (function (_super) {
    __extends(AppInsightsCore, _super);
    function AppInsightsCore() {
        var _this = _super.call(this) || this;
        dynamicProto(AppInsightsCore, _this, function (_self, _base) {
            _self[_DYN_INITIALIZE /* @min:%2einitialize */] = function (config, extensions, logger, notificationManager) {
                doPerf(_self, function () { return "AppInsightsCore.initialize"; }, function () {
                    try {
                        _base[_DYN_INITIALIZE /* @min:%2einitialize */](createDynamicConfig(config, defaultConfig, logger || _self[_DYN_LOGGER /* @min:%2elogger */], false).cfg, extensions, logger, notificationManager);
                    }
                    catch (e) {
                        var logger_1 = _self[_DYN_LOGGER /* @min:%2elogger */];
                        var message = dumpObj(e);
                        if (message[_DYN_INDEX_OF /* @min:%2eindexOf */]("channels") !== -1) {
                            // Add some additional context to the underlying reported error
                            message += "\n - Channels must be provided through config.channels only!";
                        }
                        _throwInternal(logger_1, 1 /* eLoggingSeverity.CRITICAL */, 514 /* _eExtendedInternalMessageId.FailedToInitializeSDK */, "SDK Initialization Failed - no telemetry will be sent: " + message);
                    }
                }, function () { return ({ config: config, extensions: extensions, logger: logger, notificationManager: notificationManager }); });
            };
            _self.track = function (item) {
                doPerf(_self, function () { return "AppInsightsCore.track"; }, function () {
                    var telemetryItem = item;
                    if (telemetryItem) {
                        telemetryItem[_DYN_TIMINGS /* @min:%2etimings */] = telemetryItem[_DYN_TIMINGS /* @min:%2etimings */] || {};
                        telemetryItem[_DYN_TIMINGS /* @min:%2etimings */].trackStart = getTime();
                        if (!isLatency(telemetryItem.latency)) {
                            telemetryItem.latency = 1 /* EventLatencyValue.Normal */;
                        }
                        var itemExt = telemetryItem.ext = telemetryItem.ext || {};
                        itemExt.sdk = itemExt.sdk || {};
                        itemExt.sdk.ver = FullVersionString;
                        var baseData = telemetryItem.baseData = telemetryItem.baseData || {};
                        baseData[STR_PROPERTIES /* @min:%2eproperties */] = baseData[STR_PROPERTIES /* @min:%2eproperties */] || {};
                        var itemProperties = baseData[STR_PROPERTIES /* @min:%2eproperties */];
                        itemProperties[STR_VERSION] = itemProperties[STR_VERSION] || _self.pluginVersionString || STR_EMPTY;
                    }
                    _base.track(telemetryItem);
                }, function () { return ({ item: item }); }, !(item.sync));
            };
            _self[_DYN_POLL_INTERNAL_LOGS /* @min:%2epollInternalLogs */] = function (eventName) {
                return _base[_DYN_POLL_INTERNAL_LOGS /* @min:%2epollInternalLogs */](eventName || "InternalLog");
            };
        });
        return _this;
    }
// Removed Stub for AppInsightsCore.prototype.initialize.
// Removed Stub for AppInsightsCore.prototype.track.
// Removed Stub for AppInsightsCore.prototype.pollInternalLogs.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    AppInsightsCore.__ieDyn=1;

    return AppInsightsCore;
}(InternalCore));
export { AppInsightsCore };
//# sourceMappingURL=AppInsightsCore.js.map