/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* Index.ts
* @author Abhilash Panwar (abpanwar)
* @copyright Microsoft 2018
* File to export public classes, interfaces and enums.
*/
import { AppInsightsCore } from "./AppInsightsCore";
import { EventLatency, EventPersistence, EventPropertyType, TraceLevel, ValueKind } from "./Enums";
import { ValueSanitizer } from "./ValueSanitizer";
export { ValueKind, EventLatency, EventPersistence, TraceLevel, AppInsightsCore, EventPropertyType, ValueSanitizer };
export { NotificationManager, BaseTelemetryPlugin, ProcessTelemetryContext, MinChannelPriorty, EventsDiscardedReason, DiagnosticLogger, LoggingSeverity, PerfEvent, PerfManager, doPerf, AppInsightsCore as InternalAppInsightsCore, _InternalLogMessage, ActiveStatus, createEnumStyle, _throwInternal, _warnToConsole, _logInternalMessage, 
// The HelperFuncs functions
isTypeof, isUndefined, isNullOrUndefined, hasOwnProperty, isObject, isFunction, attachEvent, detachEvent, normalizeJsName, objForEachKey, strStartsWith, strEndsWith, strContains, strTrim, isDate, isArray, isError, isString, isNumber, isBoolean, toISOString, arrForEach, arrIndexOf, arrMap, arrReduce, objKeys, objDefineAccessors, dateNow, getExceptionName, throwError, setValue, getSetValue, isNotTruthy, isTruthy, proxyAssign, proxyFunctions, proxyFunctionAs, optimizeObject, addEventHandler, newGuid, perfNow, newId, generateW3CId, safeGetLogger, objFreeze, objSeal, 
// EnvUtils
getGlobal, getGlobalInst, hasWindow, getWindow, hasDocument, getDocument, getCrypto, getMsCrypto, hasNavigator, getNavigator, hasHistory, getHistory, getLocation, getPerformance, hasJSON, getJSON, isReactNative, getConsole, dumpObj, isIE, getIEVersion, strUndefined, strObject, strPrototype, strFunction, setEnableEnvMocks, strUndefined as Undefined, 
// Random
randomValue, random32, uaDisallowsSameSiteNone as disallowsSameSiteNone, areCookiesSupported, areCookiesSupported as cookieAvailable, createCookieMgr, safeGetCookieMgr, 
// Aliases
toISOString as getISOString, isBeaconsSupported, isFetchSupported, isXhrSupported, useXDomainRequest, addPageHideEventListener, addPageShowEventListener, addEventListeners, addPageUnloadEventListener, removeEventHandler, removeEventListeners, removePageUnloadEventListener, removePageHideEventListener, removePageShowEventListener, eventOn, eventOff, mergeEvtNamespace, createUniqueNamespace, __getRegisteredEvents, createProcessTelemetryContext, createUnloadHandlerContainer, createTraceParent, parseTraceParent, isValidTraceId, isValidSpanId, isValidTraceParent, isSampledFlag, formatTraceParent, findW3cTraceParent, createDynamicConfig, onConfigChange, getDynamicConfigHandler, blockDynamicConversion, forceDynamicConversion, SenderPostManager, getResponseText, formatErrorMessageXdr, formatErrorMessageXhr, prependTransports, parseResponse, convertAllHeadersToMap, _getAllResponseHeaders, _appendHeader, 
// Test Hooks
_testHookMaxUnloadHooksCb } from "@microsoft/applicationinsights-core-js";
export { isValueAssigned, isLatency, isUint8ArrayAvailable, getTenantId, sanitizeProperty, Version, FullVersionString, getCommonSchemaMetaData, getCookieValue, extend, createGuid, isDocumentObjectAvailable, isWindowObjectAvailable, setProcessTelemetryTimings, getTime, isArrayValid, isValueKind, getFieldValueType, isChromium, // Replace with ai-core version once published in ai-core
openXhr, isGreaterThanZero } from "./Utils";
//# sourceMappingURL=Index.js.map