/*
 * 1DS JS SDK Core, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
export {};
//# sourceMappingURL=DataModels.js.map