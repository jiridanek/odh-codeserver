import * as vscode from 'vscode';
import { ServiceConnection, Requests } from '@vscode/sync-api-common';
declare type ApiServiceConnection = ServiceConnection<Requests>;
export declare enum TerminalMode {
    idle = 1,
    inUse = 2
}
export interface ServicePseudoTerminal<D = any> extends vscode.Pseudoterminal {
    readonly onDidCtrlC: vscode.Event<void>;
    readonly onDidClose: vscode.Event<void>;
    readonly onAnyKey: vscode.Event<void>;
    setMode(mode: TerminalMode): void;
    setName(name: string): void;
    write(str: string): void;
    readline(): Promise<string>;
    data: D;
}
export declare namespace ServicePseudoTerminal {
    function create<D = any>(mode: TerminalMode): ServicePseudoTerminal<D>;
}
export declare type Options = {
    /**
     * A handler that is called when the WASM exists
     */
    exitHandler?: (rval: number) => void;
    /**
     * Whether to echo the service name in the terminal
     */
    echoName?: boolean;
    /**
     * The pty to use. If not provided a very simple PTY implementation that
     * only supports backspace is used.
     */
    pty?: ServicePseudoTerminal;
};
export declare class ApiService {
    private readonly connection;
    private readonly options;
    private readonly textEncoder;
    private readonly textDecoder;
    private readonly pty;
    constructor(_name: string, receiver: ApiServiceConnection, options?: Options);
    getPty(): vscode.Pseudoterminal;
    private asFileSystemError;
}
export {};
