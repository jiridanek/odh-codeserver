let imports = {};
imports['__wbindgen_placeholder__'] = module.exports;
let wasm;
const { TextDecoder, TextEncoder } = require(`util`);

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

let cachedUint8Memory0 = null;

function getUint8Memory0() {
    if (cachedUint8Memory0 === null || cachedUint8Memory0.byteLength === 0) {
        cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8Memory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

const heap = new Array(128).fill(undefined);

heap.push(undefined, null, true, false);

let heap_next = heap.length;

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function getObject(idx) { return heap[idx]; }

function dropObject(idx) {
    if (idx < 132) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let WASM_VECTOR_LEN = 0;

let cachedTextEncoder = new TextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

let cachedInt32Memory0 = null;

function getInt32Memory0() {
    if (cachedInt32Memory0 === null || cachedInt32Memory0.byteLength === 0) {
        cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32Memory0;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8Memory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}
/**
* @param {Uint8Array} input
* @returns {Graph}
*/
module.exports.decode_bytes = function(input) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArray8ToWasm0(input, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.decode_bytes(retptr, ptr0, len0);
        var r0 = getInt32Memory0()[retptr / 4 + 0];
        var r1 = getInt32Memory0()[retptr / 4 + 1];
        var r2 = getInt32Memory0()[retptr / 4 + 2];
        if (r2) {
            throw takeObject(r1);
        }
        return Graph.__wrap(r0);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
};

/**
*/
module.exports.init_panic_hook = function() {
    wasm.init_panic_hook();
};

let cachedUint32Memory0 = null;

function getUint32Memory0() {
    if (cachedUint32Memory0 === null || cachedUint32Memory0.byteLength === 0) {
        cachedUint32Memory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32Memory0;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getUint32Memory0();
    const slice = mem.subarray(ptr / 4, ptr / 4 + len);
    const result = [];
    for (let i = 0; i < slice.length; i++) {
        result.push(takeObject(slice[i]));
    }
    return result;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    const mem = getUint32Memory0();
    for (let i = 0; i < array.length; i++) {
        mem[ptr / 4 + i] = addHeapObject(array[i]);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32Memory0().subarray(ptr / 4, ptr / 4 + len);
}
/**
*/
module.exports.WasmSortBy = Object.freeze({ SelfSize:0,"0":"SelfSize",RetainedSize:1,"1":"RetainedSize",Name:2,"2":"Name", });
/**
*/
module.exports.NodeType = Object.freeze({ Hidden:0,"0":"Hidden",Array:1,"1":"Array",String:2,"2":"String",Object:3,"3":"Object",Code:4,"4":"Code",Closure:5,"5":"Closure",RegExp:6,"6":"RegExp",Number:7,"7":"Number",Native:8,"8":"Native",Syntheic:9,"9":"Syntheic",ConcatString:10,"10":"ConcatString",SliceString:11,"11":"SliceString",BigInt:12,"12":"BigInt",Other:13,"13":"Other", });
/**
*/
module.exports.EdgeType = Object.freeze({ Context:0,"0":"Context",Element:1,"1":"Element",Property:2,"2":"Property",Internal:3,"3":"Internal",Hidden:4,"4":"Hidden",Shortcut:5,"5":"Shortcut",Weak:6,"6":"Weak",Invisible:7,"7":"Invisible",Other:8,"8":"Other", });
/**
*/
class ClassGroup {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ClassGroup.prototype);
        obj.__wbg_ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_classgroup_free(ptr);
    }
    /**
    * @returns {bigint}
    */
    get self_size() {
        const ret = wasm.__wbg_get_classgroup_self_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set self_size(arg0) {
        wasm.__wbg_set_classgroup_self_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {bigint}
    */
    get retained_size() {
        const ret = wasm.__wbg_get_classgroup_retained_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set retained_size(arg0) {
        wasm.__wbg_set_classgroup_retained_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get children_len() {
        const ret = wasm.__wbg_get_classgroup_children_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set children_len(arg0) {
        wasm.__wbg_set_classgroup_children_len(this.__wbg_ptr, arg0);
    }
    /**
    * Gets the node's string name.
    * @returns {string}
    */
    name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.classgroup_name(retptr, this.__wbg_ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
module.exports.ClassGroup = ClassGroup;
/**
*/
class Graph {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Graph.prototype);
        obj.__wbg_ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graph_free(ptr);
    }
    /**
    * @returns {number}
    */
    get root_index() {
        const ret = wasm.__wbg_get_graph_root_index(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set root_index(arg0) {
        wasm.__wbg_set_graph_root_index(this.__wbg_ptr, arg0);
    }
    /**
    * Gets a range of class groups, sorted by retained size.
    * @param {number} start
    * @param {number} end
    * @param {boolean} no_retained
    * @returns {(ClassGroup)[]}
    */
    get_class_groups(start, end, no_retained) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.graph_get_class_groups(retptr, this.__wbg_ptr, start, end, no_retained);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * Gets a count of nodes of each class name
    * @param {(string)[]} class_names
    * @returns {Uint32Array}
    */
    get_class_counts(class_names) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passArrayJsValueToWasm0(class_names, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            wasm.graph_get_class_counts(retptr, this.__wbg_ptr, ptr0, len0);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v2 = getArrayU32FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v2;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * @param {number} index
    * @param {number} start
    * @param {number} end
    * @param {WasmSortBy} sort_by
    * @returns {(Node)[]}
    */
    class_children(index, start, end, sort_by) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.graph_class_children(retptr, this.__wbg_ptr, index, start, end, sort_by);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * @param {number} parent
    * @param {number} start
    * @param {number} end
    * @param {WasmSortBy} sort_by
    * @returns {(Node)[]}
    */
    node_children(parent, start, end, sort_by) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.graph_node_children(retptr, this.__wbg_ptr, parent, start, end, sort_by);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * Gets all nodes that retain the given index. Each structure returns
    * what node it retains; the queried node retains itself.
    * @param {number} index
    * @param {number} max_distance
    * @returns {(RetainerNode)[]}
    */
    get_all_retainers(index, max_distance) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.graph_get_all_retainers(retptr, this.__wbg_ptr, index, max_distance);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v1 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}
module.exports.Graph = Graph;
/**
*/
class Node {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Node.prototype);
        obj.__wbg_ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_node_free(ptr);
    }
    /**
    * @returns {number}
    */
    get children_len() {
        const ret = wasm.__wbg_get_classgroup_children_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set children_len(arg0) {
        wasm.__wbg_set_classgroup_children_len(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {bigint}
    */
    get self_size() {
        const ret = wasm.__wbg_get_classgroup_self_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set self_size(arg0) {
        wasm.__wbg_set_classgroup_self_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {bigint}
    */
    get retained_size() {
        const ret = wasm.__wbg_get_classgroup_retained_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set retained_size(arg0) {
        wasm.__wbg_set_classgroup_retained_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get index() {
        const ret = wasm.__wbg_get_node_index(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set index(arg0) {
        wasm.__wbg_set_node_index(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {NodeType}
    */
    get typ() {
        const ret = wasm.__wbg_get_node_typ(this.__wbg_ptr);
        return ret;
    }
    /**
    * @param {NodeType} arg0
    */
    set typ(arg0) {
        wasm.__wbg_set_node_typ(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get id() {
        const ret = wasm.__wbg_get_node_id(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set id(arg0) {
        wasm.__wbg_set_node_id(this.__wbg_ptr, arg0);
    }
    /**
    * Gets the node's string name.
    * @returns {string}
    */
    name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.node_name(retptr, this.__wbg_ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
module.exports.Node = Node;
/**
*/
class RetainerNode {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(RetainerNode.prototype);
        obj.__wbg_ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_retainernode_free(ptr);
    }
    /**
    * @returns {number}
    */
    get retains_index() {
        const ret = wasm.__wbg_get_retainernode_retains_index(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set retains_index(arg0) {
        wasm.__wbg_set_retainernode_retains_index(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get children_len() {
        const ret = wasm.__wbg_get_classgroup_children_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set children_len(arg0) {
        wasm.__wbg_set_classgroup_children_len(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {bigint}
    */
    get self_size() {
        const ret = wasm.__wbg_get_classgroup_self_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set self_size(arg0) {
        wasm.__wbg_set_classgroup_self_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {bigint}
    */
    get retained_size() {
        const ret = wasm.__wbg_get_classgroup_retained_size(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
    * @param {bigint} arg0
    */
    set retained_size(arg0) {
        wasm.__wbg_set_classgroup_retained_size(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get index() {
        const ret = wasm.__wbg_get_node_index(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set index(arg0) {
        wasm.__wbg_set_node_index(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {NodeType}
    */
    get typ() {
        const ret = wasm.__wbg_get_retainernode_typ(this.__wbg_ptr);
        return ret;
    }
    /**
    * @param {NodeType} arg0
    */
    set typ(arg0) {
        wasm.__wbg_set_retainernode_typ(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get id() {
        const ret = wasm.__wbg_get_node_id(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set id(arg0) {
        wasm.__wbg_set_node_id(this.__wbg_ptr, arg0);
    }
    /**
    * @returns {EdgeType}
    */
    get edge_typ() {
        const ret = wasm.__wbg_get_retainernode_edge_typ(this.__wbg_ptr);
        return ret;
    }
    /**
    * @param {EdgeType} arg0
    */
    set edge_typ(arg0) {
        wasm.__wbg_set_retainernode_edge_typ(this.__wbg_ptr, arg0);
    }
    /**
    * Gets the node's string name.
    * @returns {string}
    */
    name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.retainernode_name(retptr, this.__wbg_ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
module.exports.RetainerNode = RetainerNode;

module.exports.__wbindgen_string_new = function(arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return addHeapObject(ret);
};

module.exports.__wbindgen_object_drop_ref = function(arg0) {
    takeObject(arg0);
};

module.exports.__wbg_classgroup_new = function(arg0) {
    const ret = ClassGroup.__wrap(arg0);
    return addHeapObject(ret);
};

module.exports.__wbg_node_new = function(arg0) {
    const ret = Node.__wrap(arg0);
    return addHeapObject(ret);
};

module.exports.__wbg_retainernode_new = function(arg0) {
    const ret = RetainerNode.__wrap(arg0);
    return addHeapObject(ret);
};

module.exports.__wbg_new_abda76e883ba8a5f = function() {
    const ret = new Error();
    return addHeapObject(ret);
};

module.exports.__wbg_stack_658279fe44541cf6 = function(arg0, arg1) {
    const ret = getObject(arg1).stack;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len1;
    getInt32Memory0()[arg0 / 4 + 0] = ptr1;
};

module.exports.__wbg_error_f851667af71bcfc6 = function(arg0, arg1) {
    let deferred0_0;
    let deferred0_1;
    try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.error(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
    }
};

module.exports.__wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbindgen_string_get = function(arg0, arg1) {
    const obj = getObject(arg1);
    const ret = typeof(obj) === 'string' ? obj : undefined;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len1;
    getInt32Memory0()[arg0 / 4 + 0] = ptr1;
};

const path = require('path').join(__dirname, 'v8_heap_parser_bg.wasm');
const bytes = require('fs').readFileSync(path);

const wasmModule = new WebAssembly.Module(bytes);
const wasmInstance = new WebAssembly.Instance(wasmModule, imports);
wasm = wasmInstance.exports;
module.exports.__wasm = wasm;

