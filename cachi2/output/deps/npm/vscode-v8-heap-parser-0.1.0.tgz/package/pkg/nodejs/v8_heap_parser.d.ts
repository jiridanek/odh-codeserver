/* tslint:disable */
/* eslint-disable */
/**
* @param {Uint8Array} input
* @returns {Graph}
*/
export function decode_bytes(input: Uint8Array): Graph;
/**
*/
export function init_panic_hook(): void;
/**
*/
export enum WasmSortBy {
  SelfSize = 0,
  RetainedSize = 1,
  Name = 2,
}
/**
*/
export enum NodeType {
  Hidden = 0,
  Array = 1,
  String = 2,
  Object = 3,
  Code = 4,
  Closure = 5,
  RegExp = 6,
  Number = 7,
  Native = 8,
  Syntheic = 9,
  ConcatString = 10,
  SliceString = 11,
  BigInt = 12,
  Other = 13,
}
/**
*/
export enum EdgeType {
  Context = 0,
  Element = 1,
  Property = 2,
  Internal = 3,
  Hidden = 4,
  Shortcut = 5,
  Weak = 6,
  Invisible = 7,
  Other = 8,
}
/**
*/
export class ClassGroup {
  free(): void;
/**
* Gets the node's string name.
* @returns {string}
*/
  name(): string;
/**
*/
  children_len: number;
/**
*/
  retained_size: bigint;
/**
*/
  self_size: bigint;
}
/**
*/
export class Graph {
  free(): void;
/**
* Gets a range of class groups, sorted by retained size.
* @param {number} start
* @param {number} end
* @param {boolean} no_retained
* @returns {(ClassGroup)[]}
*/
  get_class_groups(start: number, end: number, no_retained: boolean): (ClassGroup)[];
/**
* Gets a count of nodes of each class name
* @param {(string)[]} class_names
* @returns {Uint32Array}
*/
  get_class_counts(class_names: (string)[]): Uint32Array;
/**
* @param {number} index
* @param {number} start
* @param {number} end
* @param {WasmSortBy} sort_by
* @returns {(Node)[]}
*/
  class_children(index: number, start: number, end: number, sort_by: WasmSortBy): (Node)[];
/**
* @param {number} parent
* @param {number} start
* @param {number} end
* @param {WasmSortBy} sort_by
* @returns {(Node)[]}
*/
  node_children(parent: number, start: number, end: number, sort_by: WasmSortBy): (Node)[];
/**
* Gets all nodes that retain the given index. Each structure returns
* what node it retains; the queried node retains itself.
* @param {number} index
* @param {number} max_distance
* @returns {(RetainerNode)[]}
*/
  get_all_retainers(index: number, max_distance: number): (RetainerNode)[];
/**
*/
  root_index: number;
}
/**
*/
export class Node {
  free(): void;
/**
* Gets the node's string name.
* @returns {string}
*/
  name(): string;
/**
*/
  children_len: number;
/**
*/
  id: number;
/**
*/
  index: number;
/**
*/
  retained_size: bigint;
/**
*/
  self_size: bigint;
/**
*/
  typ: NodeType;
}
/**
*/
export class RetainerNode {
  free(): void;
/**
* Gets the node's string name.
* @returns {string}
*/
  name(): string;
/**
*/
  children_len: number;
/**
*/
  edge_typ: EdgeType;
/**
*/
  id: number;
/**
*/
  index: number;
/**
*/
  retained_size: bigint;
/**
*/
  retains_index: number;
/**
*/
  self_size: bigint;
/**
*/
  typ: NodeType;
}
