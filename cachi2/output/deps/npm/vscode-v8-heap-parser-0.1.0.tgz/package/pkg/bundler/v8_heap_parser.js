import * as wasm from "./v8_heap_parser_bg.wasm";
import { __wbg_set_wasm } from "./v8_heap_parser_bg.js";
__wbg_set_wasm(wasm);
export * from "./v8_heap_parser_bg.js";
