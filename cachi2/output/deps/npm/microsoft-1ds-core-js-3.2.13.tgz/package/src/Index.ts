/**
 * Index.ts
 * @author Abhilash Panwar (abpanwar)
 * @copyright Microsoft 2018
 * File to export public classes, interfaces and enums.
 */
import {
    ValueKind, EventLatency, EventPersistence, TraceLevel, EventPropertyType, _ExtendedInternalMessageId, _eExtendedInternalMessageId, GuidStyle, FieldValueSanitizerType,
    TransportType, EventLatencyValue, EventPersistenceValue, EventSendType
} from "./Enums";
import {
    IExtendedConfiguration, IPropertyStorageOverride,
    IEventProperty, IExtendedTelemetryItem, IExtendedAppInsightsCore, IEventTiming,
    IValueSanitizer, FieldValueSanitizerFunc, IFieldSanitizerDetails, IFieldValueSanitizerProvider,
    FieldValueSanitizerTypes
} from "./DataModels";
import AppInsightsCore from "./AppInsightsCore";
import BaseCore from "./BaseCore";
import ESPromise, { ESPromiseOnResolvedFunc, ESPromiseOnRejectedFunc, ResolverResolveFunc, ResolverRejectFunc } from "./ESPromise";
import ESPromiseScheduler, { ESPromiseSchedulerEvent } from "./ESPromiseScheduler";
import { ValueSanitizer } from "./ValueSanitizer";

export {
    ValueKind, IExtendedConfiguration, IPropertyStorageOverride,
    EventLatency, EventPersistence, TraceLevel, IEventProperty, IExtendedTelemetryItem, TransportType,
    AppInsightsCore, BaseCore, _ExtendedInternalMessageId, _eExtendedInternalMessageId, IExtendedAppInsightsCore, EventPropertyType,
    IEventTiming, ESPromise, ESPromiseOnResolvedFunc, ESPromiseOnRejectedFunc, ResolverResolveFunc,
    ResolverRejectFunc, ESPromiseScheduler, ESPromiseSchedulerEvent, GuidStyle,
    FieldValueSanitizerFunc, FieldValueSanitizerType, FieldValueSanitizerTypes, IFieldSanitizerDetails,
    IFieldValueSanitizerProvider, IValueSanitizer, ValueSanitizer,
    EventLatencyValue, EventPersistenceValue, EventSendType
};

export {
    IAppInsightsCore, IChannelControls, IPlugin, INotificationManager, NotificationManager, INotificationListener,
    IConfiguration, ITelemetryItem, ITelemetryPlugin, BaseTelemetryPlugin, IProcessTelemetryContext, ProcessTelemetryContext, ITelemetryPluginChain,
    MinChannelPriorty, EventsDiscardedReason, ICoreUtils, IDiagnosticLogger, DiagnosticLogger, LoggingSeverity, SendRequestReason,
    IPerfEvent, IPerfManager, IPerfManagerProvider, PerfEvent, PerfManager, doPerf, ICustomProperties, Tags,
    EventHelper, AppInsightsCore as InternalAppInsightsCore, BaseCore as InternalBaseCore, _InternalLogMessage, _InternalMessageId,
    createEnumStyle, eLoggingSeverity, _eInternalMessageId, _throwInternal, _warnToConsole, _logInternalMessage,
    // The HelperFuncs functions
    isTypeof, isUndefined, isNullOrUndefined, hasOwnProperty, isObject, isFunction, attachEvent, detachEvent, normalizeJsName,
    objForEachKey, strStartsWith, strEndsWith, strContains, strTrim, isDate, isArray, isError, isString, isNumber, isBoolean,
    toISOString, arrForEach, arrIndexOf, arrMap, arrReduce, objKeys, objDefineAccessors, dateNow, getExceptionName, throwError,
    setValue, getSetValue, isNotTruthy, isTruthy, proxyAssign, proxyFunctions, proxyFunctionAs, optimizeObject,
    objCreate, addEventHandler, newGuid, perfNow, newId, generateW3CId, safeGetLogger, objFreeze, objSeal,
    // EnvUtils
    getGlobal, getGlobalInst, hasWindow, getWindow, hasDocument, getDocument, getCrypto, getMsCrypto,
    hasNavigator, getNavigator, hasHistory, getHistory, getLocation, getPerformance, hasJSON, getJSON,
    isReactNative, getConsole, dumpObj, isIE, getIEVersion, strUndefined, strObject, strPrototype, strFunction,
    setEnableEnvMocks, strUndefined as Undefined,
    // Random
    randomValue, random32,
    // Cookie Handling
    ICookieMgr, ICookieMgrConfig, uaDisallowsSameSiteNone as disallowsSameSiteNone,
    areCookiesSupported, areCookiesSupported as cookieAvailable, createCookieMgr, safeGetCookieMgr,
    // Aliases
    toISOString as getISOString,
    isBeaconsSupported, isFetchSupported, isXhrSupported, useXDomainRequest,
    addPageHideEventListener, addPageShowEventListener, addEventListeners, addPageUnloadEventListener,
    removeEventHandler, removeEventListeners, removePageUnloadEventListener, removePageHideEventListener, removePageShowEventListener, eventOn, eventOff, mergeEvtNamespace,
    createUniqueNamespace, 
    _IRegisteredEvents, __getRegisteredEvents,
    TelemetryInitializerFunction, ITelemetryInitializerHandler, ITelemetryInitializerContainer,
    createProcessTelemetryContext,
    IProcessTelemetryUnloadContext, UnloadHandler, IUnloadHandlerContainer, ITelemetryUnloadState, createUnloadHandlerContainer, TelemetryUnloadReason,
    ITelemetryUpdateState, IUnloadableComponent,
    IDistributedTraceContext, createTraceParent, parseTraceParent, isValidTraceId, isValidSpanId, isValidTraceParent, isSampledFlag, formatTraceParent, findW3cTraceParent
} from "@microsoft/applicationinsights-core-js";

export {
    isValueAssigned, isLatency, isUint8ArrayAvailable, getTenantId, sanitizeProperty,
    Version, FullVersionString, getCommonSchemaMetaData, getCookie, setCookie, deleteCookie, getCookieValue,
    extend, createGuid, isDocumentObjectAvailable, isWindowObjectAvailable,
    setProcessTelemetryTimings, getTime,
    isArrayValid, isValueKind, getFieldValueType,
    CoreUtils, disableCookies,     // exporting the overridden version for tree-shaking
    Utils,  // Replacement for import * as Utils from "./Utils";
    isChromium,     // Replace with ai-core version once published in ai-core
    openXhr
} from "./Utils";
