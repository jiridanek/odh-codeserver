export declare const STR_EMPTY = "";
export declare const STR_DEFAULT_ENDPOINT_URL = "https://browser.events.data.microsoft.com/OneCollector/1.0/";
export declare const STR_PLUGIN_VERSION_STRING = "pluginVersionString";
export declare const STR_PLUGIN_VERSION_STRING_ARR: "pluginVersionStringArr";
export declare const STR_VERSION = "version";
export declare const STR_PROPERTIES = "properties";
