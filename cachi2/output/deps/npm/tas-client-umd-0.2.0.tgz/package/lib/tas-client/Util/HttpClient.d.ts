export interface RequestConfig {
    headers?: Record<string, string>;
}
export interface FetchResult {
    data: any;
}
export declare class FetchError extends Error {
    readonly responseReceived?: boolean | undefined;
    readonly responseOk?: boolean | undefined;
    constructor(message: string, responseReceived?: boolean | undefined, responseOk?: boolean | undefined);
}
export declare class HttpClient {
    private endpoint;
    constructor(endpoint: string);
    get(config?: RequestConfig | undefined): Promise<FetchResult>;
}
