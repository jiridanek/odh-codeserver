import { IKeyValueStorage } from '../../contracts/IKeyValueStorage';
export declare class MemoryKeyValueStorage implements IKeyValueStorage {
    private storage;
    getValue<T>(key: string, defaultValue?: T): Promise<T | undefined>;
    setValue<T>(key: string, value: T): void;
}
