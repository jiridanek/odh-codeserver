import { IFeatureProvider } from './FeatureProvider/IFeatureProvider';
import { ExperimentationServiceConfig } from '../contracts/ExperimentationServiceConfig';
import { ExperimentationServiceAutoPolling } from './ExperimentationServiceAutoPolling';
/**
 * Experimentation service to provide functionality of A/B experiments:
 * - reading flights;
 * - caching current set of flights;
 * - get answer on if flights are enabled.
 */
export declare class ExperimentationService extends ExperimentationServiceAutoPolling {
    private options;
    static REFRESH_RATE_IN_MINUTES: number;
    protected featureProviders?: IFeatureProvider[];
    constructor(options: ExperimentationServiceConfig);
    protected init(): void;
}
