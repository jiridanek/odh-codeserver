import { IExperimentationFilterProvider } from '../../contracts/IExperimentationFilterProvider';
import { BaseFeatureProvider } from './BaseFeatureProvider';
import { IExperimentationTelemetry } from '../../contracts/IExperimentationTelemetry';
/**
 * Feature provider implementation that handles filters.
 */
export declare abstract class FilteredFeatureProvider extends BaseFeatureProvider {
    protected telemetry: IExperimentationTelemetry;
    protected filterProviders: IExperimentationFilterProvider[];
    constructor(telemetry: IExperimentationTelemetry, filterProviders: IExperimentationFilterProvider[]);
    private cachedTelemetryEvents;
    protected getFilters(): Map<string, any>;
    protected PostEventToTelemetry(headers: any): void;
}
