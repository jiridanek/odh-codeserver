export declare class PollingService {
    private fetchInterval;
    private intervalHandle?;
    onTick: (() => Promise<void>) | undefined;
    constructor(fetchInterval: number);
    StopPolling(): void;
    OnPollTick(callback: () => Promise<void>): void;
    StartPolling(pollImmediately?: boolean): void;
}
