# Installation
> `npm install --save @types/workerpool`

# Summary
This package contains type definitions for workerpool (https://github.com/josdejong/workerpool).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/workerpool.

### Additional Details
 * Last updated: Tue, 07 Mar 2023 22:32:37 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node), [@types/worker_threads](https://npmjs.com/package/@types/worker_threads)
 * Global values: none

# Credits
These definitions were written by [Alorel](https://github.com/Alorel), [Seulgi Kim](https://github.com/sgkim126), and [Emily M Klassen](https://github.com/forivall).
