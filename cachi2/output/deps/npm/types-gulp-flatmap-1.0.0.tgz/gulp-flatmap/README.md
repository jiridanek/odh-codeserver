# Installation
> `npm install --save @types/gulp-flatmap`

# Summary
This package contains type definitions for gulp-flatmap (https://github.com/mariusGundersen/gulp-flatmap#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-flatmap.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-flatmap/index.d.ts)
````ts
import * as File from "vinyl";

export = gulp_flatmap;

/**
 * @param func
 *
 * The flatmap method takes one argument, a function. This function is called once for each file
 * piped to flatmap and is passed a stream as its first argument and the vinyl file as its second
 * argument. The stream contains only one file.
 *
 * You can now pipe this stream through as many steps as you want, before returning it from the
 * function. All the streams returned from flatmap will be combined and their contents will be
 * emited by flatmap.
 *
 * @todo Generify if <https://github.com/DefinitelyTyped/DefinitelyTyped/issues/2134> is ever solved
 */
declare function gulp_flatmap(
    func: (stream: NodeJS.ReadableStream, file: File) => NodeJS.ReadableStream,
): NodeJS.ReadWriteStream;

````

### Additional Details
 * Last updated: Sat, 10 May 2025 22:02:12 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node), [@types/vinyl](https://npmjs.com/package/@types/vinyl)

# Credits
These definitions were written by [Samuel Bronson](https://github.com/SamB).
