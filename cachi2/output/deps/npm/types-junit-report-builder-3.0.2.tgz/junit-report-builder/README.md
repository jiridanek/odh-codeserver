# Installation
> `npm install --save @types/junit-report-builder`

# Summary
This package contains type definitions for junit-report-builder (https://github.com/davidparsson/junit-report-builder).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/junit-report-builder.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [Daniel König](https://github.com/dakoenig).
