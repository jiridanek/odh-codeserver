# Installation
> `npm install --save @types/gulp-gzip`

# Summary
This package contains type definitions for gulp-gzip (https://github.com/jstuckey/gulp-gzip).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-gzip

Additional Details
 * Last updated: Wed, 08 Nov 2017 22:42:25 GMT
 * Dependencies: zlib, node
 * Global values: none

# Credits
These definitions were written by Qubo <https://github.com/tkQubo>.
