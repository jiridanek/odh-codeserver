// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __read, __spread, __values } from "tslib";
/* eslint-disable no-invalid-this */
import { log } from "./log";
var debugEnvVariable = (typeof process !== "undefined" && process.env && process.env.DEBUG) || undefined;
var enabledString;
var enabledNamespaces = [];
var skippedNamespaces = [];
var debuggers = [];
if (debugEnvVariable) {
    enable(debugEnvVariable);
}
var debugObj = Object.assign(function (namespace) {
    return createDebugger(namespace);
}, {
    enable: enable,
    enabled: enabled,
    disable: disable,
    log: log
});
function enable(namespaces) {
    var e_1, _a, e_2, _b;
    enabledString = namespaces;
    enabledNamespaces = [];
    skippedNamespaces = [];
    var wildcard = /\*/g;
    var namespaceList = namespaces.split(",").map(function (ns) { return ns.trim().replace(wildcard, ".*?"); });
    try {
        for (var namespaceList_1 = __values(namespaceList), namespaceList_1_1 = namespaceList_1.next(); !namespaceList_1_1.done; namespaceList_1_1 = namespaceList_1.next()) {
            var ns = namespaceList_1_1.value;
            if (ns.startsWith("-")) {
                skippedNamespaces.push(new RegExp("^" + ns.substr(1) + "$"));
            }
            else {
                enabledNamespaces.push(new RegExp("^" + ns + "$"));
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (namespaceList_1_1 && !namespaceList_1_1.done && (_a = namespaceList_1.return)) _a.call(namespaceList_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
    try {
        for (var debuggers_1 = __values(debuggers), debuggers_1_1 = debuggers_1.next(); !debuggers_1_1.done; debuggers_1_1 = debuggers_1.next()) {
            var instance = debuggers_1_1.value;
            instance.enabled = enabled(instance.namespace);
        }
    }
    catch (e_2_1) { e_2 = { error: e_2_1 }; }
    finally {
        try {
            if (debuggers_1_1 && !debuggers_1_1.done && (_b = debuggers_1.return)) _b.call(debuggers_1);
        }
        finally { if (e_2) throw e_2.error; }
    }
}
function enabled(namespace) {
    var e_3, _a, e_4, _b;
    if (namespace.endsWith("*")) {
        return true;
    }
    try {
        for (var skippedNamespaces_1 = __values(skippedNamespaces), skippedNamespaces_1_1 = skippedNamespaces_1.next(); !skippedNamespaces_1_1.done; skippedNamespaces_1_1 = skippedNamespaces_1.next()) {
            var skipped = skippedNamespaces_1_1.value;
            if (skipped.test(namespace)) {
                return false;
            }
        }
    }
    catch (e_3_1) { e_3 = { error: e_3_1 }; }
    finally {
        try {
            if (skippedNamespaces_1_1 && !skippedNamespaces_1_1.done && (_a = skippedNamespaces_1.return)) _a.call(skippedNamespaces_1);
        }
        finally { if (e_3) throw e_3.error; }
    }
    try {
        for (var enabledNamespaces_1 = __values(enabledNamespaces), enabledNamespaces_1_1 = enabledNamespaces_1.next(); !enabledNamespaces_1_1.done; enabledNamespaces_1_1 = enabledNamespaces_1.next()) {
            var enabledNamespace = enabledNamespaces_1_1.value;
            if (enabledNamespace.test(namespace)) {
                return true;
            }
        }
    }
    catch (e_4_1) { e_4 = { error: e_4_1 }; }
    finally {
        try {
            if (enabledNamespaces_1_1 && !enabledNamespaces_1_1.done && (_b = enabledNamespaces_1.return)) _b.call(enabledNamespaces_1);
        }
        finally { if (e_4) throw e_4.error; }
    }
    return false;
}
function disable() {
    var result = enabledString || "";
    enable("");
    return result;
}
function createDebugger(namespace) {
    var newDebugger = Object.assign(debug, {
        enabled: enabled(namespace),
        destroy: destroy,
        log: debugObj.log,
        namespace: namespace,
        extend: extend
    });
    function debug() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (!newDebugger.enabled) {
            return;
        }
        if (args.length > 0) {
            args[0] = namespace + " " + args[0];
        }
        newDebugger.log.apply(newDebugger, __spread(args));
    }
    debuggers.push(newDebugger);
    return newDebugger;
}
function destroy() {
    var index = debuggers.indexOf(this);
    if (index >= 0) {
        debuggers.splice(index, 1);
        return true;
    }
    return false;
}
function extend(namespace) {
    var newDebugger = createDebugger(this.namespace + ":" + namespace);
    newDebugger.log = this.log;
    return newDebugger;
}
export default debugObj;
//# sourceMappingURL=debug.js.map