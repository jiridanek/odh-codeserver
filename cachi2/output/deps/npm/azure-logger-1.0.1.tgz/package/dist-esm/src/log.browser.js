// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { __read, __spread } from "tslib";
var logFunction = console.debug || console.log;
export function log() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    logFunction.apply(void 0, __spread(args));
}
//# sourceMappingURL=log.browser.js.map