# Installation
> `npm install --save @types/ansi-colors`

# Summary
This package contains type definitions for ansi-colors (https://github.com/doowb/ansi-colors).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/ansi-colors

Additional Details
 * Last updated: Mon, 31 Dec 2018 16:11:57 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Rogier Schouten <https://github.com/rogierschouten>, BendingBender <https://github.com/BendingBender>.
