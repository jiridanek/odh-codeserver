import { BaseLanguageClient, LanguageClientOptions, MessageTransports } from '../common/api';
export * from 'vscode-languageserver-protocol/browser';
export * from '../common/api';
export type ServerOptions = Worker | (() => Promise<Worker | MessageTransports>);
export declare class LanguageClient extends BaseLanguageClient {
    private readonly serverOptions;
    constructor(id: string, name: string, serverOptions: ServerOptions, clientOptions: LanguageClientOptions);
    protected createMessageTransports(_encoding: string): Promise<MessageTransports>;
    private createMessageTransportsFromWorker;
}
