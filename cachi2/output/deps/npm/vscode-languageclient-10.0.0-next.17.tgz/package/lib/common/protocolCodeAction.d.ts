import * as vscode from 'vscode';
import { LSPAny } from 'vscode-languageserver-protocol';
export default class ProtocolCodeAction extends vscode.CodeAction {
    readonly data: LSPAny | undefined;
    constructor(title: string, data: LSPAny | undefined);
}
