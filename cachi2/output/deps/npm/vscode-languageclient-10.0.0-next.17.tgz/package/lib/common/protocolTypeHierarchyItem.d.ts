import * as code from 'vscode';
import { LSPAny } from 'vscode-languageserver-protocol';
export default class ProtocolTypeHierarchyItem extends code.TypeHierarchyItem {
    data?: LSPAny;
    constructor(kind: code.SymbolKind, name: string, detail: string, uri: code.Uri, range: code.Range, selectionRange: code.Range, data?: LSPAny);
}
