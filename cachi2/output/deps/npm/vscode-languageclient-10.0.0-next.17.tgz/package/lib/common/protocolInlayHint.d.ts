import * as code from 'vscode';
export default class ProtocolInlayHint extends code.InlayHint {
    data: any;
    constructor(position: code.Position, label: string | code.InlayHintLabelPart[], kind?: code.InlayHintKind);
}
