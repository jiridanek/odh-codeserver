import { Uri } from 'vscode';
import type { GlobPattern } from 'vscode-languageserver-protocol';
export declare function matchGlobPattern(pattern: GlobPattern, resource: Uri): boolean;
