import * as code from 'vscode';
import { LSPAny } from 'vscode-languageserver-protocol';
export default class WorkspaceSymbol extends code.SymbolInformation {
    data?: LSPAny;
    readonly hasRange: boolean;
    constructor(name: string, kind: code.SymbolKind, containerName: string, locationOrUri: code.Location | code.Uri, data: LSPAny | undefined);
}
