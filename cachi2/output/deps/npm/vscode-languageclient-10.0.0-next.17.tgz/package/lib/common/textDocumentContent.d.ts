import * as vscode from 'vscode';
import { type ClientCapabilities, type RegistrationType, type ServerCapabilities, type TextDocumentContentRegistrationOptions } from 'vscode-languageserver-protocol';
import { type DynamicFeature, type FeatureClient, type FeatureState, type RegistrationData } from './features';
export interface ProvideTextDocumentContentSignature {
    (this: void, uri: vscode.Uri, token: vscode.CancellationToken): vscode.ProviderResult<string>;
}
export interface TextDocumentContentMiddleware {
    provideTextDocumentContent?: (this: void, uri: vscode.Uri, token: vscode.CancellationToken, next: ProvideTextDocumentContentSignature) => vscode.ProviderResult<string>;
}
export interface TextDocumentContentProviderShape {
    scheme: string;
    onDidChangeEmitter: vscode.EventEmitter<vscode.Uri>;
    provider: vscode.TextDocumentContentProvider;
}
export declare class TextDocumentContentFeature implements DynamicFeature<TextDocumentContentRegistrationOptions> {
    private readonly _client;
    private readonly _registrations;
    constructor(client: FeatureClient<TextDocumentContentMiddleware>);
    getState(): FeatureState;
    get registrationType(): RegistrationType<TextDocumentContentRegistrationOptions>;
    getProviders(): TextDocumentContentProviderShape[];
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities): void;
    register(data: RegistrationData<TextDocumentContentRegistrationOptions>): void;
    private registerTextDocumentContentProvider;
    unregister(id: string): void;
    clear(): void;
}
