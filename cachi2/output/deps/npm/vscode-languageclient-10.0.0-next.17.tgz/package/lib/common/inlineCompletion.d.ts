import { TextDocument, Disposable, Position as VPosition, InlineCompletionContext as VInlineCompletionContext, CancellationToken, ProviderResult, InlineCompletionItem as VInlineCompletionItem, InlineCompletionList as VInlineCompletionList, InlineCompletionItemProvider } from 'vscode';
import { ClientCapabilities, InlineCompletionOptions, InlineCompletionRegistrationOptions, DocumentSelector, ServerCapabilities } from 'vscode-languageserver-protocol';
import { FeatureClient, TextDocumentLanguageFeature } from './features';
export interface ProvideInlineCompletionItemsSignature {
    (this: void, document: TextDocument, position: VPosition, context: VInlineCompletionContext, token: CancellationToken): ProviderResult<VInlineCompletionItem[] | VInlineCompletionList>;
}
export interface InlineCompletionMiddleware {
    provideInlineCompletionItems?: (this: void, document: TextDocument, position: VPosition, context: VInlineCompletionContext, token: CancellationToken, next: ProvideInlineCompletionItemsSignature) => ProviderResult<VInlineCompletionItem[] | VInlineCompletionList>;
}
export type InlineCompletionProviderShape = {
    provider: InlineCompletionItemProvider;
};
export declare class InlineCompletionItemFeature extends TextDocumentLanguageFeature<boolean | InlineCompletionOptions, InlineCompletionRegistrationOptions, InlineCompletionItemProvider, InlineCompletionMiddleware> {
    constructor(client: FeatureClient<InlineCompletionMiddleware>);
    fillClientCapabilities(capabilities: ClientCapabilities): void;
    initialize(capabilities: ServerCapabilities, documentSelector: DocumentSelector): void;
    protected registerLanguageProvider(options: InlineCompletionRegistrationOptions): [Disposable, InlineCompletionItemProvider];
}
