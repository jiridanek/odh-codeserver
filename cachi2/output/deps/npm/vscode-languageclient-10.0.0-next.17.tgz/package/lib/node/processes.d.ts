import * as cp from 'child_process';
import ChildProcess = cp.ChildProcess;
export declare function terminate(process: ChildProcess & {
    pid: number;
}, cwd?: string): boolean;
