# Installation
> `npm install --save @types/kerberos`

# Summary
This package contains type definitions for kerberos (https://github.com/mongodb-js/kerberos#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/kerberos.

### Additional Details
 * Last updated: Mon, 08 May 2023 19:02:56 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [DefinitelyTyped](https://github.com/DefinitelyTyped).
