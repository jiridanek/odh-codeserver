# Installation
> `npm install --save @types/lazy.js`

# Summary
This package contains type definitions for lazy.js (https://github.com/dtao/lazy.js/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lazy.js.

### Additional Details
 * Last updated: Mon, 22 Jul 2024 23:36:02 GMT
 * Dependencies: none

# Credits
These definitions were written by [Bart van der Schoor](https://github.com/Bartvds), [Gabriel Lorquet](https://github.com/gablorquet), and [Alexey Gerasimov](https://github.com/fan-tom).
