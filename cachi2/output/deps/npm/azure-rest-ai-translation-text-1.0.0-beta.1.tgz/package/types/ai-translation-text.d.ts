import { Client } from '@azure-rest/core-client';
import { ClientOptions } from '@azure-rest/core-client';
import { HttpResponse } from '@azure-rest/core-client';
import { KeyCredential } from '@azure/core-auth';
import { RawHttpHeaders } from '@azure/core-rest-pipeline';
import { RawHttpHeadersInput } from '@azure/core-rest-pipeline';
import { RequestParameters } from '@azure-rest/core-client';
import { StreamableMethod } from '@azure-rest/core-client';
import { TokenCredential } from '@azure/core-auth';

/** Back Translation */
export declare interface BackTranslationOutput {
    /**
     * A string giving the normalized form of the source term that is a back-translation of the target.
     * This value should be used as input to lookup examples.
     */
    normalizedText: string;
    /**
     * A string giving the source term that is a back-translation of the target in a form best
     * suited for end-user display.
     */
    displayText: string;
    /**
     * An integer representing the number of examples that are available for this translation pair.
     * Actual examples must be retrieved with a separate call to lookup examples. The number is mostly
     * intended to facilitate display in a UX. For example, a user interface may add a hyperlink
     * to the back-translation if the number of examples is greater than zero and show the back-translation
     * as plain text if there are no examples. Note that the actual number of examples returned
     * by a call to lookup examples may be less than numExamples, because additional filtering may be
     * applied on the fly to remove "bad" examples.
     */
    numExamples: number;
    /**
     * An integer representing the frequency of this translation pair in the data. The main purpose of this
     * field is to provide a user interface with a means to sort back-translations so the most frequent terms are first.
     */
    frequencyCount: number;
}

/** Elemented containing break sentence result. */
export declare interface BreakSentenceItemOutput {
    /** The detectedLanguage property is only present in the result object when language auto-detection is requested. */
    detectedLanguage?: DetectedLanguageOutput;
    /**
     * An integer array representing the lengths of the sentences in the input text.
     * The length of the array is the number of sentences, and the values are the length of each sentence.
     */
    sentLen: number[];
}

export declare function buildMultiCollection(queryParameters: string[], parameterName: string): string;

/** Common properties of language script */
export declare interface CommonScriptModelOutput {
    /** Code identifying the script. */
    code: string;
    /** Display name of the script in the locale requested via Accept-Language header. */
    name: string;
    /** Display name of the language in the locale native for the language. */
    nativeName: string;
    /** Directionality, which is rtl for right-to-left languages or ltr for left-to-right languages. */
    dir: string;
}

/**
 * Initialize a new instance of `TextTranslationClient`
 * @param endpoint type: string, Supported Text Translation endpoints (protocol and hostname, for example:
 *     https://api.cognitive.microsofttranslator.com).
 * @param options type: ClientOptions, the parameter for all optional parameters
 */
declare function createClient(endpoint: undefined | string, credential?: undefined | TranslatorCredential | KeyCredential | TokenCredential, options?: ClientOptions): TextTranslationClient;
export default createClient;

/** An object describing the detected language. */
export declare interface DetectedLanguageOutput {
    /** A string representing the code of the detected language. */
    language: string;
    /**
     * A float value indicating the confidence in the result.
     * The score is between zero and one and a low score indicates a low confidence.
     */
    score: number;
}

/** Dictionary Example element */
export declare interface DictionaryExampleItemOutput {
    /**
     * A string giving the normalized form of the source term. Generally, this should be identical
     * to the value of the Text field at the matching list index in the body of the request.
     */
    normalizedSource: string;
    /**
     * A string giving the normalized form of the target term. Generally, this should be identical
     * to the value of the Translation field at the matching list index in the body of the request.
     */
    normalizedTarget: string;
    /** A list of examples for the (source term, target term) pair. */
    examples: Array<DictionaryExampleOutput>;
}

/** Dictionary Example */
export declare interface DictionaryExampleOutput {
    /**
     * The string to concatenate before the value of sourceTerm to form a complete example.
     * Do not add a space character, since it is already there when it should be.
     * This value may be an empty string.
     */
    sourcePrefix: string;
    /**
     * A string equal to the actual term looked up. The string is added with sourcePrefix
     * and sourceSuffix to form the complete example. Its value is separated so it can be
     * marked in a user interface, e.g., by bolding it.
     */
    sourceTerm: string;
    /**
     * The string to concatenate after the value of sourceTerm to form a complete example.
     * Do not add a space character, since it is already there when it should be.
     * This value may be an empty string.
     */
    sourceSuffix: string;
    /** A string similar to sourcePrefix but for the target. */
    targetPrefix: string;
    /** A string similar to sourceTerm but for the target. */
    targetTerm: string;
    /** A string similar to sourceSuffix but for the target. */
    targetSuffix: string;
}

/** Element containing the text with translation. */
export declare interface DictionaryExampleTextItem extends InputTextItem {
    /**
     * A string specifying the translated text previously returned by the Dictionary lookup operation.
     * This should be the value from the normalizedTarget field in the translations list of the Dictionary
     * lookup response. The service will return examples for the specific source-target word-pair.
     */
    translation: string;
}

/** Dictionary Lookup Element */
export declare interface DictionaryLookupItemOutput {
    /**
     * A string giving the normalized form of the source term.
     * For example, if the request is "JOHN", the normalized form will be "john".
     * The content of this field becomes the input to lookup examples.
     */
    normalizedSource: string;
    /**
     * A string giving the source term in a form best suited for end-user display.
     * For example, if the input is "JOHN", the display form will reflect the usual
     * spelling of the name: "John".
     */
    displaySource: string;
    /** A list of translations for the source term. */
    translations: Array<DictionaryTranslationOutput>;
}

/** Translation source term. */
export declare interface DictionaryTranslationOutput {
    /**
     * A string giving the normalized form of this term in the target language.
     * This value should be used as input to lookup examples.
     */
    normalizedTarget: string;
    /**
     * A string giving the term in the target language and in a form best suited
     * for end-user display. Generally, this will only differ from the normalizedTarget
     * in terms of capitalization. For example, a proper noun like "Juan" will have
     * normalizedTarget = "juan" and displayTarget = "Juan".
     */
    displayTarget: string;
    /** A string associating this term with a part-of-speech tag. */
    posTag: string;
    /**
     * A value between 0.0 and 1.0 which represents the "confidence"
     * (or perhaps more accurately, "probability in the training data") of that translation pair.
     * The sum of confidence scores for one source word may or may not sum to 1.0.
     */
    confidence: number;
    /**
     * A string giving the word to display as a prefix of the translation. Currently,
     * this is the gendered determiner of nouns, in languages that have gendered determiners.
     * For example, the prefix of the Spanish word "mosca" is "la", since "mosca" is a feminine noun in Spanish.
     * This is only dependent on the translation, and not on the source.
     * If there is no prefix, it will be the empty string.
     */
    prefixWord: string;
    /**
     * A list of "back translations" of the target. For example, source words that the target can translate to.
     * The list is guaranteed to contain the source word that was requested (e.g., if the source word being
     * looked up is "fly", then it is guaranteed that "fly" will be in the backTranslations list).
     * However, it is not guaranteed to be in the first position, and often will not be.
     */
    backTranslations: Array<BackTranslationOutput>;
}

/** Error details as returned by Translator Service. */
export declare interface ErrorDetailsOutput {
    /** Number indetifier of the error. */
    code: number;
    /** Human readable error description. */
    message: string;
}

/** Representation of the Error Response from Translator Service. */
export declare interface ErrorResponseOutput {
    /** Error details. */
    error: ErrorDetailsOutput;
}

export declare interface FindSentenceBoundaries {
    /** Find Sentence Boundaries */
    post(options: FindSentenceBoundariesParameters): StreamableMethod<FindSentenceBoundaries200Response | FindSentenceBoundariesDefaultResponse>;
}

export declare interface FindSentenceBoundaries200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

/** Response for the Break SEntence API. */
export declare interface FindSentenceBoundaries200Response extends HttpResponse {
    status: "200";
    body: Array<BreakSentenceItemOutput>;
    headers: RawHttpHeaders & FindSentenceBoundaries200Headers;
}

export declare interface FindSentenceBoundariesBodyParam {
    /** Array of the text for which values the sentence boundaries will be calculated. */
    body: Array<InputTextItem>;
}

export declare interface FindSentenceBoundariesDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface FindSentenceBoundariesDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & FindSentenceBoundariesDefaultHeaders;
}

export declare interface FindSentenceBoundariesHeaderParam {
    headers?: RawHttpHeadersInput & FindSentenceBoundariesHeaders;
}

export declare interface FindSentenceBoundariesHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
}

export declare type FindSentenceBoundariesParameters = FindSentenceBoundariesQueryParam & FindSentenceBoundariesHeaderParam & FindSentenceBoundariesBodyParam & RequestParameters;

export declare interface FindSentenceBoundariesQueryParam {
    queryParameters?: FindSentenceBoundariesQueryParamProperties;
}

export declare interface FindSentenceBoundariesQueryParamProperties {
    /**
     * Language tag identifying the language of the input text.
     * If a code isn't specified, automatic language detection will be applied.
     */
    language?: string;
    /**
     * Script tag identifying the script used by the input text.
     * If a script isn't specified, the default script of the language will be assumed.
     */
    script?: string;
}

export declare interface GetLanguages {
    /** Gets the set of languages currently supported by other operations of the Translator. */
    get(options?: GetLanguagesParameters): StreamableMethod<GetLanguages200Response | GetLanguagesDefaultResponse>;
}

export declare interface GetLanguages200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
    /**
     * Current value of the entity tag for the requested groups of supported languages.
     * To make subsequent requests more efficient, the client may send the `ETag` value in an
     * `If-None-Match` header field.
     */
    etag: string;
}

/** The request has succeeded. */
export declare interface GetLanguages200Response extends HttpResponse {
    status: "200";
    body: GetLanguagesResultOutput;
    headers: RawHttpHeaders & GetLanguages200Headers;
}

export declare interface GetLanguagesDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface GetLanguagesDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & GetLanguagesDefaultHeaders;
}

export declare interface GetLanguagesHeaderParam {
    headers?: RawHttpHeadersInput & GetLanguagesHeaders;
}

export declare interface GetLanguagesHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
    /**
     * The language to use for user interface strings. Some of the fields in the response are names of languages or
     * names of regions. Use this parameter to define the language in which these names are returned.
     * The language is specified by providing a well-formed BCP 47 language tag. For instance, use the value `fr`
     * to request names in French or use the value `zh-Hant` to request names in Chinese Traditional.
     * Names are provided in the English language when a target language is not specified or when localization
     * is not available.
     */
    "Accept-Language"?: string;
    /**
     * Passing the value of the ETag response header in an If-None-Match field will allow the service to optimize the response.
     * If the resource has not been modified, the service will return status code 304 and an empty response body.
     */
    "If-None-Match"?: string;
}

export declare type GetLanguagesParameters = GetLanguagesQueryParam & GetLanguagesHeaderParam & RequestParameters;

export declare interface GetLanguagesQueryParam {
    queryParameters?: GetLanguagesQueryParamProperties;
}

export declare interface GetLanguagesQueryParamProperties {
    /**
     * A comma-separated list of names defining the group of languages to return.
     * Allowed group names are: `translation`, `transliteration` and `dictionary`.
     * If no scope is given, then all groups are returned, which is equivalent to passing
     * `scope=translation,transliteration,dictionary`. To decide which set of supported languages
     * is appropriate for your scenario, see the description of the [response object](#response-body).
     */
    scope?: string;
}

/** Response for the languages API. */
export declare interface GetLanguagesResultOutput {
    /** Languages that support translate API. */
    translation?: Record<string, TranslationLanguageOutput>;
    /** Languages that support transliteration API. */
    transliteration?: Record<string, TransliterationLanguageOutput>;
    /** Languages that support dictionary API. */
    dictionary?: Record<string, SourceDictionaryLanguageOutput>;
}

/** Element containing the text for translation. */
export declare interface InputTextItem {
    /** Text to translate. */
    text: string;
}

export declare function isUnexpected(response: GetLanguages200Response | GetLanguagesDefaultResponse): response is GetLanguagesDefaultResponse;

export declare function isUnexpected(response: Translate200Response | TranslateDefaultResponse): response is TranslateDefaultResponse;

export declare function isUnexpected(response: Transliterate200Response | TransliterateDefaultResponse): response is TransliterateDefaultResponse;

export declare function isUnexpected(response: FindSentenceBoundaries200Response | FindSentenceBoundariesDefaultResponse): response is FindSentenceBoundariesDefaultResponse;

export declare function isUnexpected(response: LookupDictionaryEntries200Response | LookupDictionaryEntriesDefaultResponse): response is LookupDictionaryEntriesDefaultResponse;

export declare function isUnexpected(response: LookupDictionaryExamples200Response | LookupDictionaryExamplesDefaultResponse): response is LookupDictionaryExamplesDefaultResponse;

export declare interface LookupDictionaryEntries {
    /** Lookup Dictionary Entries */
    post(options: LookupDictionaryEntriesParameters): StreamableMethod<LookupDictionaryEntries200Response | LookupDictionaryEntriesDefaultResponse>;
}

export declare interface LookupDictionaryEntries200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

/** Response for the dictionary lookup API. */
export declare interface LookupDictionaryEntries200Response extends HttpResponse {
    status: "200";
    body: Array<DictionaryLookupItemOutput>;
    headers: RawHttpHeaders & LookupDictionaryEntries200Headers;
}

export declare interface LookupDictionaryEntriesBodyParam {
    /** Array of the text to be sent to dictionary. */
    body: Array<InputTextItem>;
}

export declare interface LookupDictionaryEntriesDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface LookupDictionaryEntriesDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & LookupDictionaryEntriesDefaultHeaders;
}

export declare interface LookupDictionaryEntriesHeaderParam {
    headers?: RawHttpHeadersInput & LookupDictionaryEntriesHeaders;
}

export declare interface LookupDictionaryEntriesHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
}

export declare type LookupDictionaryEntriesParameters = LookupDictionaryEntriesQueryParam & LookupDictionaryEntriesHeaderParam & LookupDictionaryEntriesBodyParam & RequestParameters;

export declare interface LookupDictionaryEntriesQueryParam {
    queryParameters: LookupDictionaryEntriesQueryParamProperties;
}

export declare interface LookupDictionaryEntriesQueryParamProperties {
    /**
     * Specifies the language of the input text.
     * The source language must be one of the supported languages included in the dictionary scope.
     */
    from: string;
    /**
     * Specifies the language of the output text.
     * The target language must be one of the supported languages included in the dictionary scope.
     */
    to: string;
}

export declare interface LookupDictionaryExamples {
    /** Lookup Dictionary Examples */
    post(options: LookupDictionaryExamplesParameters): StreamableMethod<LookupDictionaryExamples200Response | LookupDictionaryExamplesDefaultResponse>;
}

export declare interface LookupDictionaryExamples200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

/** Response for the dictionary examples API. */
export declare interface LookupDictionaryExamples200Response extends HttpResponse {
    status: "200";
    body: Array<DictionaryExampleItemOutput>;
    headers: RawHttpHeaders & LookupDictionaryExamples200Headers;
}

export declare interface LookupDictionaryExamplesBodyParam {
    /** Array of the text to be sent to dictionary. */
    body: Array<DictionaryExampleTextItem>;
}

export declare interface LookupDictionaryExamplesDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface LookupDictionaryExamplesDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & LookupDictionaryExamplesDefaultHeaders;
}

export declare interface LookupDictionaryExamplesHeaderParam {
    headers?: RawHttpHeadersInput & LookupDictionaryExamplesHeaders;
}

export declare interface LookupDictionaryExamplesHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
}

export declare type LookupDictionaryExamplesParameters = LookupDictionaryExamplesQueryParam & LookupDictionaryExamplesHeaderParam & LookupDictionaryExamplesBodyParam & RequestParameters;

export declare interface LookupDictionaryExamplesQueryParam {
    queryParameters: LookupDictionaryExamplesQueryParamProperties;
}

export declare interface LookupDictionaryExamplesQueryParamProperties {
    /**
     * Specifies the language of the input text.
     * The source language must be one of the supported languages included in the dictionary scope.
     */
    from: string;
    /**
     * Specifies the language of the output text.
     * The target language must be one of the supported languages included in the dictionary scope.
     */
    to: string;
}

export declare interface Routes {
    /** Resource for '/languages' has methods for the following verbs: get */
    (path: "/languages"): GetLanguages;
    /** Resource for '/translate' has methods for the following verbs: post */
    (path: "/translate"): Translate;
    /** Resource for '/transliterate' has methods for the following verbs: post */
    (path: "/transliterate"): Transliterate;
    /** Resource for '/breaksentence' has methods for the following verbs: post */
    (path: "/breaksentence"): FindSentenceBoundaries;
    /** Resource for '/dictionary/lookup' has methods for the following verbs: post */
    (path: "/dictionary/lookup"): LookupDictionaryEntries;
    /** Resource for '/dictionary/examples' has methods for the following verbs: post */
    (path: "/dictionary/examples"): LookupDictionaryExamples;
}

/** An object returning sentence boundaries in the input and output texts. */
export declare interface SentenceLengthOutput {
    /**
     * An integer array representing the lengths of the sentences in the input text.
     * The length of the array is the number of sentences, and the values are the length of each sentence.
     */
    srcSentLen: number[];
    /**
     * An integer array representing the lengths of the sentences in the translated text.
     * The length of the array is the number of sentences, and the values are the length of each sentence.
     */
    transSentLen: number[];
}

/** Properties ot the source dictionary language */
export declare interface SourceDictionaryLanguageOutput {
    /** Display name of the language in the locale requested via Accept-Language header. */
    name: string;
    /** Display name of the language in the locale native for this language. */
    nativeName: string;
    /** Directionality, which is rtl for right-to-left languages or ltr for left-to-right languages. */
    dir: string;
    /** List of languages with alterative translations and examples for the query expressed in the source language. */
    translations: Array<TargetDictionaryLanguageOutput>;
}

/** Input text in the default script of the source language. */
export declare interface SourceTextOutput {
    /** Input text in the default script of the source language. */
    text: string;
}

/** Properties of the target dictionary language */
export declare interface TargetDictionaryLanguageOutput {
    /** Display name of the language in the locale requested via Accept-Language header. */
    name: string;
    /** Display name of the language in the locale native for this language. */
    nativeName: string;
    /** Directionality, which is rtl for right-to-left languages or ltr for left-to-right languages. */
    dir: string;
    /** Language code identifying the target language. */
    code: string;
}

export declare type TextTranslationClient = Client & {
    path: Routes;
};

export declare interface Translate {
    /** Translate Text */
    post(options: TranslateParameters): StreamableMethod<Translate200Response | TranslateDefaultResponse>;
}

export declare interface Translate200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
    /**
     * Specifies the system type that was used for translation for each 'to' language requested for translation.
     * The value is a comma-separated list of strings. Each string indicates a type:
     *
     * * Custom - Request includes a custom system and at least one custom system was used during translation.
     * * Team - All other requests
     */
    "x-mt-system": string;
    /**
     * Specifies consumption (the number of characters for which the user will be charged) for the translation
     * job request. For example, if the word "Hello" is translated from English (en) to French (fr),
     * this field will return the value '5'.
     */
    "x-metered-usage": number;
}

/** Response for the translation API. */
export declare interface Translate200Response extends HttpResponse {
    status: "200";
    body: Array<TranslatedTextItemOutput>;
    headers: RawHttpHeaders & Translate200Headers;
}

export declare interface TranslateBodyParam {
    /** Array of the text to be translated. */
    body: Array<InputTextItem>;
}

export declare interface TranslateDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface TranslateDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & TranslateDefaultHeaders;
}

/** Alignment information object. */
export declare interface TranslatedTextAlignmentOutput {
    /**
     * Maps input text to translated text. The alignment information is only provided when the request
     * parameter includeAlignment is true. Alignment is returned as a string value of the following
     * format: [[SourceTextStartIndex]:[SourceTextEndIndex]–[TgtTextStartIndex]:[TgtTextEndIndex]].
     * The colon separates start and end index, the dash separates the languages, and space separates the words.
     * One word may align with zero, one, or multiple words in the other language, and the aligned words may
     * be non-contiguous. When no alignment information is available, the alignment element will be empty.
     */
    proj: string;
}

/** Element containing the translated text */
export declare interface TranslatedTextItemOutput {
    /** The detectedLanguage property is only present in the result object when language auto-detection is requested. */
    detectedLanguage?: DetectedLanguageOutput;
    /**
     * An array of translation results. The size of the array matches the number of target
     * languages specified through the to query parameter.
     */
    translations: Array<TranslationOutput>;
    /**
     * Input text in the default script of the source language. sourceText property is present only when
     * the input is expressed in a script that's not the usual script for the language. For example,
     * if the input were Arabic written in Latin script, then sourceText.text would be the same Arabic text
     * converted into Arab script.
     */
    sourceText?: SourceTextOutput;
}

export declare interface TranslateHeaderParam {
    headers?: RawHttpHeadersInput & TranslateHeaders;
}

export declare interface TranslateHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
}

export declare type TranslateParameters = TranslateQueryParam & TranslateHeaderParam & TranslateBodyParam & RequestParameters;

export declare interface TranslateQueryParam {
    queryParameters: TranslateQueryParamProperties;
}

export declare interface TranslateQueryParamProperties {
    /**
     * Specifies the language of the output text. The target language must be one of the supported languages included
     * in the translation scope. For example, use to=de to translate to German.
     * It's possible to translate to multiple languages simultaneously by repeating the parameter in the query string.
     * For example, use to=de&to=it to translate to German and Italian. This parameter needs to be formatted as multi collection, we provide buildMultiCollection from serializeHelper.ts to help, you will probably need to set skipUrlEncoding as true when sending the request
     */
    to: string;
    /**
     * Specifies the language of the input text. Find which languages are available to translate from by
     * looking up supported languages using the translation scope. If the from parameter isn't specified,
     * automatic language detection is applied to determine the source language.
     *
     * You must use the from parameter rather than autodetection when using the dynamic dictionary feature.
     * Note: the dynamic dictionary feature is case-sensitive.
     */
    from?: string;
    /**
     * Defines whether the text being translated is plain text or HTML text. Any HTML needs to be a well-formed,
     * complete element. Possible values are: plain (default) or html.
     */
    textType?: "plain" | "html";
    /**
     * A string specifying the category (domain) of the translation. This parameter is used to get translations
     * from a customized system built with Custom Translator. Add the Category ID from your Custom Translator
     * project details to this parameter to use your deployed customized system. Default value is: general.
     */
    category?: string;
    /**
     * Specifies how profanities should be treated in translations.
     * Possible values are: NoAction (default), Marked or Deleted.
     */
    profanityAction?: "NoAction" | "Marked" | "Deleted";
    /**
     * Specifies how profanities should be marked in translations.
     * Possible values are: Asterisk (default) or Tag.
     */
    profanityMarker?: "Asterisk" | "Tag";
    /**
     * Specifies whether to include alignment projection from source text to translated text.
     * Possible values are: true or false (default).
     */
    includeAlignment?: boolean;
    /**
     * Specifies whether to include sentence boundaries for the input text and the translated text.
     * Possible values are: true or false (default).
     */
    includeSentenceLength?: boolean;
    /**
     * Specifies a fallback language if the language of the input text can't be identified.
     * Language autodetection is applied when the from parameter is omitted. If detection fails,
     * the suggestedFrom language will be assumed.
     */
    suggestedFrom?: string;
    /** Specifies the script of the input text. */
    fromScript?: string;
    /** Specifies the script of the translated text. */
    toScript?: string;
    /**
     * Specifies that the service is allowed to fall back to a general system when a custom system doesn't exist.
     * Possible values are: true (default) or false.
     *
     * allowFallback=false specifies that the translation should only use systems trained for the category specified
     * by the request. If a translation for language X to language Y requires chaining through a pivot language E,
     * then all the systems in the chain (X → E and E → Y) will need to be custom and have the same category.
     * If no system is found with the specific category, the request will return a 400 status code. allowFallback=true
     * specifies that the service is allowed to fall back to a general system when a custom system doesn't exist.
     */
    allowFallback?: boolean;
}

/**
 * The value of the translation property is a dictionary of (key, value) pairs. Each key is a BCP 47 language tag.
 * A key identifies a language for which text can be translated to or translated from.
 */
export declare interface TranslationLanguageOutput {
    /** Display name of the language in the locale requested via Accept-Language header. */
    name: string;
    /** Display name of the language in the locale native for this language. */
    nativeName: string;
    /** Directionality, which is rtl for right-to-left languages or ltr for left-to-right languages. */
    dir: string;
}

/** Translation result */
export declare interface TranslationOutput {
    /** A string representing the language code of the target language. */
    to: string;
    /** A string giving the translated text. */
    text: string;
    /** An object giving the translated text in the script specified by the toScript parameter. */
    transliteration?: TransliterationOutput;
    /** Alignment information. */
    alignment?: TranslatedTextAlignmentOutput;
    /** Sentence boundaries in the input and output texts. */
    sentLen?: SentenceLengthOutput;
}

export declare interface TranslatorCredential {
    key: string;
    region: string;
}

/** Script definition with list of script into which given script can be translitered. */
export declare interface TransliterableScriptOutput extends CommonScriptModelOutput {
    /** List of scripts available to convert text to. */
    toScripts: Array<CommonScriptModelOutput>;
}

export declare interface Transliterate {
    /** Transliterate Text */
    post(options: TransliterateParameters): StreamableMethod<Transliterate200Response | TransliterateDefaultResponse>;
}

export declare interface Transliterate200Headers {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

/** Response for the transliteration API. */
export declare interface Transliterate200Response extends HttpResponse {
    status: "200";
    body: Array<TransliteratedTextOutput>;
    headers: RawHttpHeaders & Transliterate200Headers;
}

export declare interface TransliterateBodyParam {
    /** Array of the text to be transliterated. */
    body: Array<InputTextItem>;
}

export declare interface TransliterateDefaultHeaders {
    /** Value generated by the service to identify the request. It is used for troubleshooting purposes. */
    "x-requestid": string;
}

export declare interface TransliterateDefaultResponse extends HttpResponse {
    status: string;
    body: ErrorResponseOutput;
    headers: RawHttpHeaders & TransliterateDefaultHeaders;
}

/** Transliterated text element. */
export declare interface TransliteratedTextOutput {
    /** A string which is the result of converting the input string to the output script. */
    text: string;
    /** A string specifying the script used in the output. */
    script: string;
}

export declare interface TransliterateHeaderParam {
    headers?: RawHttpHeadersInput & TransliterateHeaders;
}

export declare interface TransliterateHeaders {
    /** A client-generated GUID to uniquely identify the request. */
    "X-ClientTraceId"?: string;
}

export declare type TransliterateParameters = TransliterateQueryParam & TransliterateHeaderParam & TransliterateBodyParam & RequestParameters;

export declare interface TransliterateQueryParam {
    queryParameters: TransliterateQueryParamProperties;
}

export declare interface TransliterateQueryParamProperties {
    /**
     * Specifies the language of the text to convert from one script to another.
     * Possible languages are listed in the transliteration scope obtained by querying the service
     * for its supported languages.
     */
    language: string;
    /**
     * Specifies the script used by the input text. Look up supported languages using the transliteration scope,
     * to find input scripts available for the selected language.
     */
    fromScript: string;
    /**
     * Specifies the output script. Look up supported languages using the transliteration scope, to find output
     * scripts available for the selected combination of input language and input script.
     */
    toScript: string;
}

/**
 * The value of the transliteration property is a dictionary of (key, value) pairs.
 * Each key is a BCP 47 language tag. A key identifies a language for which text can be converted from one script
 * to another script.
 */
export declare interface TransliterationLanguageOutput {
    /** Display name of the language in the locale requested via Accept-Language header. */
    name: string;
    /** Display name of the language in the locale native for this language. */
    nativeName: string;
    /** List of scripts to convert from. */
    scripts: Array<TransliterableScriptOutput>;
}

/** An object giving the translated text in the script specified by the toScript parameter. */
export declare interface TransliterationOutput {
    /** A string specifying the target script. */
    script: string;
    /** A string giving the translated text in the target script. */
    text: string;
}

export { }
