// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const APIM_KEY_HEADER_NAME = "Ocp-Apim-Subscription-Key";
const APIM_REGION_HEADER_NAME = "Ocp-Apim-Subscription-Region";
export class TranslatorAuthenticationPolicy {
    constructor(credential) {
        this.name = "TranslatorAuthenticationPolicy";
        this.credential = credential;
    }
    sendRequest(request, next) {
        request.headers.set(APIM_KEY_HEADER_NAME, this.credential.key);
        request.headers.set(APIM_REGION_HEADER_NAME, this.credential.region);
        return next(request);
    }
}
export class TranslatorAzureKeyAuthenticationPolicy {
    constructor(credential) {
        this.name = "TranslatorAzureKeyAuthenticationPolicy";
        this.credential = credential;
    }
    sendRequest(request, next) {
        request.headers.set(APIM_KEY_HEADER_NAME, this.credential.key);
        return next(request);
    }
}
//# sourceMappingURL=authentication.js.map