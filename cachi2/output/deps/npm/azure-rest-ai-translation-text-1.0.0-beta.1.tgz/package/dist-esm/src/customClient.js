// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { getClient } from "@azure-rest/core-client";
import * as coreRestPipeline from "@azure/core-rest-pipeline";
import { TranslatorAuthenticationPolicy, TranslatorAzureKeyAuthenticationPolicy, } from "./authentication";
const DEFAULT_SCOPE = "https://cognitiveservices.azure.com/.default";
const DEFAULT_ENPOINT = "https://api.cognitive.microsofttranslator.com";
const PLATFORM_HOST = "cognitiveservices";
const PLATFORM_PATH = "/translator/text/v3.0";
function isKeyCredential(credential) {
    return (credential === null || credential === void 0 ? void 0 : credential.key) !== undefined;
}
function isTranslatorKeyCredential(credential) {
    return (credential === null || credential === void 0 ? void 0 : credential.key) !== undefined;
}
/** Policy that sets the api-version (or equivalent) to reflect the library version. */
const apiVersionPolicy = {
    name: "MTApiVersionPolicy",
    async sendRequest(request, next) {
        const param = request.url.split("?");
        if (param.length > 1) {
            const newParams = param[1].split("&");
            newParams.push("api-version=3.0");
            request.url = param[0] + "?" + newParams.join("&");
        }
        else {
            // no query parameters in request url
            request.url = param[0] + "?api-version=3.0";
        }
        return next(request);
    },
};
/**
 * Initialize a new instance of `TextTranslationClient`
 * @param endpoint type: string, Supported Text Translation endpoints (protocol and hostname, for example:
 *     https://api.cognitive.microsofttranslator.com).
 * @param options type: ClientOptions, the parameter for all optional parameters
 */
export default function createClient(endpoint, credential = undefined, options = {}) {
    var _a;
    let serviceEndpoint;
    if (!endpoint) {
        serviceEndpoint = DEFAULT_ENPOINT;
    }
    else if (endpoint.toLowerCase().indexOf(PLATFORM_HOST) !== -1) {
        serviceEndpoint = `${endpoint}${PLATFORM_PATH}`;
    }
    else {
        serviceEndpoint = endpoint;
    }
    const baseUrl = (_a = options.baseUrl) !== null && _a !== void 0 ? _a : `${serviceEndpoint}`;
    const userAgentInfo = `azsdk-js-ai-translation-text-rest/1.0.0-beta.1`;
    const userAgentPrefix = options.userAgentOptions && options.userAgentOptions.userAgentPrefix
        ? `${options.userAgentOptions.userAgentPrefix} ${userAgentInfo}`
        : `${userAgentInfo}`;
    options = Object.assign(Object.assign({}, options), { userAgentOptions: {
            userAgentPrefix,
        } });
    const client = getClient(baseUrl, options);
    client.pipeline.addPolicy(apiVersionPolicy);
    if (isTranslatorKeyCredential(credential)) {
        const mtAuthneticationPolicy = new TranslatorAuthenticationPolicy(credential);
        client.pipeline.addPolicy(mtAuthneticationPolicy);
    }
    else if (isKeyCredential(credential)) {
        const mtKeyAuthenticationPolicy = new TranslatorAzureKeyAuthenticationPolicy(credential);
        client.pipeline.addPolicy(mtKeyAuthenticationPolicy);
    }
    else if (credential) {
        client.pipeline.addPolicy(coreRestPipeline.bearerTokenAuthenticationPolicy({
            credential: credential,
            scopes: DEFAULT_SCOPE,
        }));
    }
    return client;
}
//# sourceMappingURL=customClient.js.map