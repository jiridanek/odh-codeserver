// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
const responseMap = {
    "GET /languages": ["200"],
    "POST /translate": ["200"],
    "POST /transliterate": ["200"],
    "POST /breaksentence": ["200"],
    "POST /dictionary/lookup": ["200"],
    "POST /dictionary/examples": ["200"],
};
export function isUnexpected(response) {
    const lroOriginal = response.headers["x-ms-original-url"];
    const url = new URL(lroOriginal !== null && lroOriginal !== void 0 ? lroOriginal : response.request.url);
    const method = response.request.method;
    const pathDetails = responseMap[`${method} ${url.pathname}`];
    if (!pathDetails) {
        return true;
    }
    return !pathDetails.includes(response.status);
}
//# sourceMappingURL=isUnexpected.js.map