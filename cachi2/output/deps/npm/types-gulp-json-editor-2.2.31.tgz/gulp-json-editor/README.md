# Installation
> `npm install --save @types/gulp-json-editor`

# Summary
This package contains type definitions for gulp-json-editor (https://www.npmjs.com/package/gulp-json-editor).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-json-editor

Additional Details
 * Last updated: Wed, 08 Nov 2017 22:42:25 GMT
 * Dependencies: node, js-beautify
 * Global values: none

# Credits
These definitions were written by Peter Juras <https://github.com/peterjuras>.
