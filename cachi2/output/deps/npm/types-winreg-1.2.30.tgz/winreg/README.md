# Installation
> `npm install --save @types/winreg`

# Summary
This package contains type definitions for Winreg v1.2.0 (http://fresc81.github.io/node-winreg/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/winreg

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Winreg

# Credits
These definitions were written by RX14 <https://github.com/RX14>, BobBuehler <https://github.com/BobBuehler>.
