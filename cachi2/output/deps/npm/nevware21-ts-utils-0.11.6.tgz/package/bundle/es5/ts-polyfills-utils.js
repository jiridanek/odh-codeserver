/*
 * NevWare21 Solutions LLC - ts-utils Polyfills, v0.11.6
 * https://github.com/nevware21/ts-utils
 * Copyright (c) NevWare21 Solutions LLC and contributors. All rights reserved.
 * Licensed under the MIT license.
 */
(function () {
    'use strict';

    /*#__NO_SIDE_EFFECTS__*/
    function _pureAssign(func1, func2) {
        return func1 || func2;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _pureRef(value, name) {
        return value[name];
    }

    var UNDEF_VALUE = undefined;
    var NULL_VALUE = null;
    var EMPTY = "";
    var FUNCTION = "function";
    var OBJECT = "object";
    var PROTOTYPE = "prototype";
    var UNDEFINED = "undefined";
    var SYMBOL = "Symbol";
    var POLYFILL_TAG = "_polyfill";
    var LENGTH = "length";
    var CALL = "call";
    var TO_STRING = "toString";
    var ObjClass = ( /*#__PURE__*/_pureAssign(Object));
    var ObjProto = ( /*#__PURE__*/_pureRef(ObjClass, PROTOTYPE));
    var StrCls = ( /*#__PURE__*/_pureAssign(String));
    var StrProto = ( /*#__PURE__*/_pureRef(StrCls, PROTOTYPE));
    var MathCls = ( /*#__PURE__*/_pureAssign(Math));
    var ArrCls = ( /*#__PURE__*/_pureAssign(Array));
    var ArrProto = ( /*#__PURE__*/_pureRef(ArrCls, PROTOTYPE));
    var ArrSlice = ( /*#__PURE__*/_pureRef(ArrProto, "slice"));

    function arrForEach(theArray, callbackfn, thisArg) {
        if (theArray) {
            var len = theArray[LENGTH] >>> 0;
            for (var idx = 0; idx < len; idx++) {
                if (idx in theArray) {
                    if (callbackfn[CALL](theArray, theArray[idx], idx, theArray) === -1) {
                        break;
                    }
                }
            }
        }
    }

    var asString = ( /* #__PURE__ */_pureAssign(StrCls));

    var ERROR_TYPE = "[object Error]";
    /*#__NO_SIDE_EFFECTS__*/
    function dumpObj(object, format) {
        var propertyValueDump = EMPTY;
        var objType = ObjProto[TO_STRING][CALL](object);
        if (objType === ERROR_TYPE) {
            object = { stack: asString(object.stack), message: asString(object.message), name: asString(object.name) };
        }
        try {
            propertyValueDump = JSON.stringify(object, NULL_VALUE, format ? ((typeof format === "number") ? format : 4) : UNDEF_VALUE);
            propertyValueDump = (propertyValueDump ? propertyValueDump.replace(/"(\w+)"\s*:\s{0,1}/g, "$1: ") : NULL_VALUE) || asString(object);
        }
        catch (e) {
            propertyValueDump = " - " + dumpObj(e, format);
        }
        return objType + ": " + propertyValueDump;
    }

    function throwTypeError(message) {
        throw new TypeError(message);
    }
    function throwRangeError(message) {
        throw new RangeError(message);
    }

    var _unwrapFunction = ( _unwrapFunctionWithPoly);
    /*#__NO_SIDE_EFFECTS__*/
    function _unwrapFunctionWithPoly(funcName, clsProto, polyFunc) {
        var clsFn = clsProto ? clsProto[funcName] : NULL_VALUE;
        return function (thisArg) {
            var theFunc = (thisArg ? thisArg[funcName] : NULL_VALUE) || clsFn;
            if (theFunc || polyFunc) {
                var theArgs = arguments;
                return (theFunc || polyFunc).apply(thisArg, theFunc ? ArrSlice[CALL](theArgs, 1) : theArgs);
            }
            throwTypeError("\"" + asString(funcName) + "\" not defined for " + dumpObj(thisArg));
        };
    }

    var arrIndexOf = ( /*#__PURE__*/_unwrapFunction("indexOf", ArrProto));

    var arrMap = ( /*#__PURE__*/_unwrapFunction("map", ArrProto));

    function arrSlice(theArray, start, end) {
        return ((theArray ? theArray["slice"] : NULL_VALUE) || ArrSlice).apply(theArray, ArrSlice[CALL](arguments, 1));
    }

    function safe(func, argArray) {
        try {
            return {
                v: func.apply(this, argArray)
            };
        }
        catch (e) {
            return { e: e };
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createIs(theType) {
        return function (value) {
            return typeof value === theType;
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _createObjIs(theName) {
        var theType = "[object " + theName + "]";
        return function (value) {
            return !!(value && objToString(value) === theType);
        };
    }
    /*#__NO_SIDE_EFFECTS__*/
    function objToString(value) {
        return ObjProto[TO_STRING].call(value);
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isUndefined(value) {
        return typeof value === UNDEFINED || value === UNDEFINED;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function isNullOrUndefined(value) {
        return value === NULL_VALUE || isUndefined(value);
    }
    var isString = ( /*#__PURE__*/_createIs("string"));
    var isFunction = ( /*#__PURE__*/_createIs(FUNCTION));
    /*#__NO_SIDE_EFFECTS__*/
    function isObject(value) {
        if (!value && isNullOrUndefined(value)) {
            return false;
        }
        return !!value && typeof value === OBJECT;
    }
    var isArray = ( /* #__PURE__*/_pureRef(ArrCls, "isArray"));
    var isRegExp = ( /*#__PURE__*/_createObjIs("RegExp"));

    var objGetOwnPropertyDescriptor = ( /* #__PURE__ */_pureRef(ObjClass, "getOwnPropertyDescriptor"));

    /*#__NO_SIDE_EFFECTS__*/
    function objHasOwnProperty(obj, prop) {
        return !!obj && ObjProto.hasOwnProperty[CALL](obj, prop);
    }

    var objHasOwn = ( /*#__PURE__*/_pureAssign(( /* #__PURE__ */_pureRef(ObjClass, "hasOwn")), polyObjHasOwn));
    /*#__NO_SIDE_EFFECTS__*/
    function polyObjHasOwn(obj, prop) {
        return objHasOwnProperty(obj, prop) || !!objGetOwnPropertyDescriptor(obj, prop);
    }

    function objForEachKey(theObject, callbackfn, thisArg) {
        if (theObject && isObject(theObject)) {
            for (var prop in theObject) {
                if (objHasOwn(theObject, prop)) {
                    if (callbackfn[CALL](theObject, prop, theObject[prop]) === -1) {
                        break;
                    }
                }
            }
        }
    }

    var objDefineProp = ( /*#__PURE__*/_pureRef(ObjClass, "defineProperty"));

    /*#__NO_SIDE_EFFECTS__*/
    function createCachedValue(value) {
        return objDefineProp({
            toJSON: function () { return value; }
        }, "v", { value: value });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createKeyValueMap(values, keyType, valueType, completeFn, writable) {
        var theMap = {};
        objForEachKey(values, function (key, value) {
            _assignMapValue(theMap, key, key, writable);
            _assignMapValue(theMap, value, key, writable);
        });
        return completeFn ? completeFn(theMap) : theMap;
    }
    function _assignMapValue(theMap, key, value, writable) {
        objDefineProp(theMap, key, {
            value: value,
            enumerable: true,
            writable: !!writable
        });
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyObjKeys(obj) {
        if (!isObject(obj) || obj === NULL_VALUE) {
            throwTypeError("non-object " + dumpObj(obj));
        }
        var result = [];
        for (var prop in obj) {
            if (objHasOwn(obj, prop)) {
                result.push(prop);
            }
        }
        return result;
    }

    var _objFreeze = ( /* #__PURE__ */_pureRef(ObjClass, "freeze"));
    function _doNothing(value) {
        return value;
    }
    var objFreeze = ( /* #__PURE__*/_pureAssign(_objFreeze, _doNothing));

    /*#__NO_SIDE_EFFECTS__*/
    function createEnumKeyMap(values) {
        return _createKeyValueMap(values, 0 , 0 , objFreeze);
    }

    var _wellKnownSymbolMap = /*#__PURE__*/ createEnumKeyMap({
        asyncIterator: 0 ,
        hasInstance: 1 ,
        isConcatSpreadable: 2 ,
        iterator: 3 ,
        match: 4 ,
        matchAll: 5 ,
        replace: 6 ,
        search: 7 ,
        species: 8 ,
        split: 9 ,
        toPrimitive: 10 ,
        toStringTag: 11 ,
        unscopables: 12
    });

    var GLOBAL_CONFIG_KEY = "__tsUtils$gblCfg";
    var _globalCfg;
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalValue() {
        var result;
        if (typeof globalThis !== UNDEFINED) {
            result = globalThis;
        }
        if (!result && typeof self !== UNDEFINED) {
            result = self;
        }
        if (!result && typeof window !== UNDEFINED) {
            result = window;
        }
        if (!result && typeof global !== UNDEFINED) {
            result = global;
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function _getGlobalConfig() {
        if (!_globalCfg) {
            var gbl = safe(_getGlobalValue).v || {};
            _globalCfg = gbl[GLOBAL_CONFIG_KEY] = gbl[GLOBAL_CONFIG_KEY] || {};
        }
        return _globalCfg;
    }

    var mathMax = ( /*#__PURE__*/_pureRef(MathCls, "max"));

    var strSlice = ( /*#__PURE__*/_unwrapFunction("slice", StrProto));

    var strSubstring = ( /*#__PURE__*/_unwrapFunction("substring", StrProto));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrSubstr(value, start, length) {
        if (isNullOrUndefined(value)) {
            throwTypeError("Invalid " + dumpObj(value));
        }
        if (length < 0) {
            return EMPTY;
        }
        start = start || 0;
        if (start < 0) {
            start = mathMax(start + value[LENGTH], 0);
        }
        if (isUndefined(length)) {
            return strSlice(value, start);
        }
        return strSlice(value, start, start + length);
    }

    var _wellKnownSymbolCache;
    /*#__NO_SIDE_EFFECTS__*/
    function polyNewSymbol(description) {
        var theSymbol = {
            description: asString(description),
            toString: function () { return SYMBOL + "(" + description + ")"; }
        };
        theSymbol[POLYFILL_TAG] = true;
        return theSymbol;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyGetKnownSymbol(name) {
        !_wellKnownSymbolCache && (_wellKnownSymbolCache = {});
        var result;
        var knownName = _wellKnownSymbolMap[name];
        if (knownName) {
            result = _wellKnownSymbolCache[knownName] = _wellKnownSymbolCache[knownName] || polyNewSymbol(SYMBOL + "." + knownName);
        }
        return result;
    }

    var _globalLazyTestHooks;
    function _initTestHooks() {
        _globalLazyTestHooks = _getGlobalConfig();
    }

    var WINDOW = "window";
    var _cachedGlobal;
    function getGlobal(useCached) {
        !_globalLazyTestHooks && _initTestHooks();
        if (!_cachedGlobal || useCached === false || _globalLazyTestHooks.lzy) {
            _cachedGlobal = createCachedValue(safe(_getGlobalValue).v || NULL_VALUE);
        }
        return _cachedGlobal.v;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getInst(name, useCached) {
        var gbl;
        if (!_cachedGlobal || useCached === false) {
            gbl = getGlobal(useCached);
        }
        else {
            gbl = _cachedGlobal.v;
        }
        if (gbl && gbl[name]) {
            return gbl[name];
        }
        if (name === WINDOW) {
            try {
                return window;
            }
            catch (e) {
            }
        }
        return NULL_VALUE;
    }

    var _symbol;
    /*#__NO_SIDE_EFFECTS__*/
    function _initSymbol() {
        _symbol = ( /*#__PURE__*/createCachedValue(safe((getInst), [SYMBOL]).v));
        return _symbol;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function getKnownSymbol(name, noPoly) {
        var knownName = _wellKnownSymbolMap[name];
        !_globalLazyTestHooks && _initTestHooks();
        var sym = ((!_globalLazyTestHooks.lzy ? _symbol : 0) || _initSymbol());
        return sym.v ? sym.v[knownName || name] : (polyGetKnownSymbol(name) );
    }

    /*#__NO_SIDE_EFFECTS__*/
    function isIterator(value) {
        return !!value && isFunction(value.next);
    }

    var _iterSymbol;
    function iterForOf(iter, callbackfn, thisArg) {
        if (iter) {
            if (!isIterator(iter)) {
                !_iterSymbol && (_iterSymbol = createCachedValue(getKnownSymbol(3 )));
                iter = iter[_iterSymbol.v] ? iter[_iterSymbol.v]() : NULL_VALUE;
            }
            if (isIterator(iter)) {
                var err = UNDEF_VALUE;
                var iterResult = UNDEF_VALUE;
                try {
                    var count = 0;
                    while (!(iterResult = iter.next()).done) {
                        if (callbackfn[CALL](thisArg || iter, iterResult.value, count, iter) === -1) {
                            break;
                        }
                        count++;
                    }
                }
                catch (failed) {
                    err = { e: failed };
                    if (iter.throw) {
                        iterResult = NULL_VALUE;
                        iter.throw(err);
                    }
                }
                finally {
                    try {
                        if (iterResult && !iterResult.done) {
                            iter.return && iter.return(iterResult);
                        }
                    }
                    finally {
                        if (err) {
                            throw err.e;
                        }
                    }
                }
            }
        }
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyIsArray(value) {
        if (isNullOrUndefined(value)) {
            return false;
        }
        return objToString(value) === "[object Array]";
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyArrIncludes(theArray, searchElement, fromIndex) {
        return arrIndexOf(theArray, searchElement, fromIndex) !== -1;
    }
    function polyArrFind(theArray, callbackFn, thisArg) {
        var result;
        var idx = polyArrFindIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindIndex(theArray, callbackFn, thisArg) {
        var result = -1;
        arrForEach(theArray, function (value, index) {
            if (callbackFn[CALL](thisArg | theArray, value, index, theArray)) {
                result = index;
                return -1;
            }
        });
        return result;
    }
    function polyArrFindLast(theArray, callbackFn, thisArg) {
        var result;
        var idx = polyArrFindLastIndex(theArray, callbackFn, thisArg);
        return idx !== -1 ? theArray[idx] : result;
    }
    function polyArrFindLastIndex(theArray, callbackFn, thisArg) {
        var result = -1;
        var len = theArray[LENGTH] >>> 0;
        for (var idx = len - 1; idx >= 0; idx--) {
            if (idx in theArray && callbackFn[CALL](thisArg | theArray, theArray[idx], idx, theArray)) {
                result = idx;
                break;
            }
        }
        return result;
    }
    function polyArrFrom(theValue, mapFn, thisArg) {
        if (isArray(theValue)) {
            var result_1 = arrSlice(theValue);
            return mapFn ? arrMap(result_1, mapFn, thisArg) : result_1;
        }
        var result = [];
        iterForOf(theValue, function (value, cnt) {
            return result.push(mapFn ? mapFn[CALL](thisArg, value, cnt) : value);
        });
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrStartsWith(value, searchString, position) {
        if (!isString(value)) {
            throwTypeError("'" + dumpObj(value) + "' is not a string");
        }
        var searchValue = isString(searchString) ? searchString : asString(searchString);
        var pos = position > 0 ? position : 0;
        return strSubstring(value, pos, pos + searchValue[LENGTH]) === searchValue;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrEndsWith(value, searchString, length) {
        if (!isString(value)) {
            throwTypeError("'" + dumpObj(value) + "' is not a string");
        }
        var searchValue = isString(searchString) ? searchString : asString(searchString);
        var end = (!isUndefined(length) && length < value[LENGTH]) ? length : value[LENGTH];
        return strSubstring(value, end - searchValue[LENGTH], end) === searchValue;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _createTrimFn(exp) {
        return function _doTrim(value) {
            if (isNullOrUndefined(value)) {
                throwTypeError("strTrim called [" + dumpObj(value) + "]");
            }
            if (value && value.replace) {
                value = value.replace(exp, EMPTY);
            }
            return value;
        };
    }
    var polyStrTrim = ( /*#__PURE__*/_createTrimFn(/^\s+|(?=\s)\s+$/g));
    var polyStrTrimStart = ( /*#__PURE__*/_createTrimFn(/^\s+/g));
    var polyStrTrimEnd = ( /*#__PURE__*/_createTrimFn(/(?=\s)\s+$/g));

    var mathFloor = ( /*#__PURE__*/_pureRef(MathCls, "floor"));
    var mathCeil = ( /*#__PURE__*/_pureRef(MathCls, "ceil"));

    var mathTrunc = ( /* #__PURE__*/_pureAssign(( /* #__PURE__*/_pureRef(MathCls, "trunc")), polyMathTrunc));
    /*#__NO_SIDE_EFFECTS__*/
    function polyMathTrunc(value) {
        var theValue = +value;
        return (theValue > 0 ? mathFloor : mathCeil)(theValue);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function mathToInt(value, throwInfinity) {
        var result = +value;
        if (result == Infinity && throwInfinity) {
            throwRangeError("invalid value [" + dumpObj(value) + "]");
        }
        return result !== result || result === 0 ? 0 : mathTrunc(result);
    }

    var strRepeat = ( /*#__PURE__*/_unwrapFunctionWithPoly("repeat", StrProto, polyStrRepeat));
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrRepeat(value, count) {
        if (isNullOrUndefined(value)) {
            throwTypeError("can't convert [" + dumpObj(value) + "]");
        }
        count = mathToInt(count, true);
        if (count < 0) {
            throwRangeError("invalid count must be >= 0 && < Infinity");
        }
        var pad = isString(value) ? value : asString(value);
        var result = EMPTY;
        for (; count > 0; (count >>>= 1) && (pad += pad)) {
            if (count & 1) {
                result += pad;
            }
        }
        return result;
    }

    /*#__NO_SIDE_EFFECTS__*/
    function _padValue(value, targetLength, padString) {
        var result = EMPTY;
        targetLength = mathToInt(targetLength, true);
        targetLength >>= 0;
        var len = value[LENGTH];
        if (len < targetLength) {
            result = isNullOrUndefined(padString) ? " " : asString(padString);
            targetLength = targetLength - len;
            if (targetLength > result[LENGTH]) {
                result = strRepeat(result, mathCeil(targetLength / result[LENGTH]));
            }
            if (result[LENGTH] > targetLength) {
                result = strSubstring(result, 0, targetLength);
            }
        }
        return result;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadStart(value, targetLength, padString) {
        return _padValue(value, targetLength, padString) + value;
    }
    /*#__NO_SIDE_EFFECTS__*/
    function polyStrPadEnd(value, targetLength, padString) {
        return value + _padValue(value, targetLength, padString);
    }

    /*#__NO_SIDE_EFFECTS__*/
    function makePolyFn(poly) {
        return function () {
            var theArgs = [this];
            for (var lp = 0; lp < arguments[LENGTH]; lp++) {
                theArgs[lp + 1] = arguments[lp];
            }
            return poly.apply(this, theArgs);
        };
    }

    var strIndexOf = ( /*#__PURE__*/_unwrapFunction("indexOf", StrProto));

    /*#__NO_SIDE_EFFECTS__*/
    function polyStrIncludes(value, searchString, position) {
        if (isRegExp(searchString)) {
            throwTypeError("'searchString' must not be a regular expression" + dumpObj(searchString));
        }
        return strIndexOf(value, asString(searchString), position) !== -1;
    }

    (function () {
        var objectPolyfills = {
            "keys": polyObjKeys,
            "hasOwn": polyObjHasOwn
        };
        var stringPolyfills = {
            "startsWith": polyStrStartsWith,
            "endsWith": polyStrEndsWith,
            "padStart": polyStrPadStart,
            "padEnd": polyStrPadEnd,
            "trim": polyStrTrim,
            "trimStart": polyStrTrimStart,
            "trimLeft": polyStrTrimStart,
            "trimEnd": polyStrTrimEnd,
            "trimRight": polyStrTrimEnd,
            "substr": polyStrSubstr,
            "includes": polyStrIncludes
        };
        var arrayClsPolyfills = {
            "isArray": polyIsArray,
            "from": polyArrFrom
        };
        var arrayPolyfills = {
            "includes": polyArrIncludes,
            "find": polyArrFind,
            "findIndex": polyArrFindIndex,
            "findLast": polyArrFindLast,
            "findLastIndex": polyArrFindLastIndex
        };
        arrForEach(polyObjKeys(objectPolyfills), function (key) {
            if (!ObjClass[key]) {
                ObjClass[key] = makePolyFn(objectPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(arrayClsPolyfills), function (key) {
            if (!ArrCls[key]) {
                ArrCls[key] = makePolyFn(arrayClsPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(arrayPolyfills), function (key) {
            if (!ArrProto[key]) {
                ArrProto[key] = makePolyFn(arrayPolyfills[key]);
            }
        });
        arrForEach(polyObjKeys(stringPolyfills), function (key) {
            if (!StrProto[key]) {
                StrProto[key] = makePolyFn(stringPolyfills[key]);
            }
        });
    })();

})();
//# sourceMappingURL=ts-polyfills-utils.js.map
