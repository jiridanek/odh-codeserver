# Installation
> `npm install --save @types/sinon-test`

# Summary
This package contains type definitions for sinon-test (https://github.com/sinonjs/sinon-test).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinon-test.

### Additional Details
 * Last updated: Fri, 25 Sep 2020 23:56:35 GMT
 * Dependencies: [@types/sinon](https://npmjs.com/package/@types/sinon)
 * Global values: none

# Credits
These definitions were written by [Francis Saul](https://github.com/mummybot).
