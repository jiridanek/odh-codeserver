export declare function fallbackRandomValues(buffer: Uint8Array): void;
//# sourceMappingURL=random.d.ts.map