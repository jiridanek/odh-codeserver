/*
 * Microsoft Application Insights JavaScript SDK Channel, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 *
 * Microsoft Application Insights Team
 * https://github.com/microsoft/ApplicationInsights-JS#readme
 *
 * ---------------------------------------------------------------------------
 * This is a single combined (rollup) declaration file for the package,
 * if you require a namespace wrapped version it is also available.
 * - Namespaced version: types/applicationinsights-channel-js.namespaced.d.ts
 * ---------------------------------------------------------------------------
 */

import { BaseTelemetryPlugin } from '@microsoft/applicationinsights-core-js';
import { IAppInsightsCore } from '@microsoft/applicationinsights-core-js';
import { IBackendResponse } from '@microsoft/applicationinsights-core-js';
import { IChannelControls } from '@microsoft/applicationinsights-core-js';
import { IConfig } from '@microsoft/applicationinsights-common';
import { IConfiguration } from '@microsoft/applicationinsights-core-js';
import { IDiagnosticLogger } from '@microsoft/applicationinsights-core-js';
import { IEnvelope } from '@microsoft/applicationinsights-common';
import { IInternalOfflineSupport } from '@microsoft/applicationinsights-core-js';
import { IOfflineListener } from '@microsoft/applicationinsights-common';
import { IPlugin } from '@microsoft/applicationinsights-core-js';
import { IProcessTelemetryContext } from '@microsoft/applicationinsights-core-js';
import { IPromise } from '@nevware21/ts-async';
import { ISample } from '@microsoft/applicationinsights-common';
import { IStorageBuffer } from '@microsoft/applicationinsights-common';
import { ITelemetryItem } from '@microsoft/applicationinsights-core-js';
import { ITelemetryPluginChain } from '@microsoft/applicationinsights-core-js';
import { IXDomainRequest } from '@microsoft/applicationinsights-core-js';
import { IXHROverride } from '@microsoft/applicationinsights-core-js';
import { SendRequestReason } from '@microsoft/applicationinsights-core-js';

declare class ArraySendBuffer extends BaseSendBuffer implements ISendBuffer {
    constructor(logger: IDiagnosticLogger, config: ISenderConfig);
    markAsSent(payload: IInternalStorageItem[]): void;
    clearSent(payload: IInternalStorageItem[]): void;
}

declare abstract class BaseSendBuffer {
    protected _get: () => IInternalStorageItem[];
    protected _set: (buffer: IInternalStorageItem[]) => IInternalStorageItem[];
    constructor(logger: IDiagnosticLogger, config: ISenderConfig);
    enqueue(payload: IInternalStorageItem): void;
    count(): number;
    size(): number;
    clear(): void;
    getItems(): IInternalStorageItem[];
    batchPayloads(payload: IInternalStorageItem[]): string;
    createNew(newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean): ArraySendBuffer | SessionStorageSendBuffer;
}

/**
 * Internal interface for sendBuffer, do not export it
 * @internal
 * @since 3.1.3
 */
declare interface IInternalStorageItem {
    /**
     * serialized telemetry to be stored.
     */
    item: string;
    /**
     * total retry count
     */
    cnt?: number;
}

/**
 * Before 3.1.2, payload only allow string
 * After 3.2.0,  IInternalStorageItem is accepted
 */
declare interface ISendBuffer {
    /**
     * Enqueue the payload
     */
    enqueue: (payload: IInternalStorageItem) => void;
    /**
     * Returns the number of elements in the buffer
     */
    count: () => number;
    /**
     * Returns the current size of the serialized buffer
     */
    size: () => number;
    /**
     * Clears the buffer
     */
    clear: () => void;
    /**
     * Returns items stored in the buffer
     */
    getItems: () => IInternalStorageItem[];
    /**
     * Build a batch of all elements in the payload array
     */
    batchPayloads: (payload: IInternalStorageItem[]) => string;
    /**
     * Moves items to the SENT_BUFFER.
     * The buffer holds items which were sent, but we haven't received any response from the backend yet.
     */
    markAsSent: (payload: IInternalStorageItem[]) => void;
    /**
     * Removes items from the SENT_BUFFER. Should be called on successful response from the backend.
     */
    clearSent: (payload: IInternalStorageItem[]) => void;
    /**
     * Copy current buffer items to a new buffer.
     * if canUseSessionStorage is undefined, it will set to false.
     * if newLogger and newConfig are undefined, current logger and empty config will be used.
     * if canUseSessionStorage is set to true, new SessionStorageSendBuffer will be returned otherwise ArraySendBuffer will be returned.
     */
    createNew: (newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean) => ArraySendBuffer | SessionStorageSendBuffer;
}

export declare interface ISenderConfig {
    /**
     * The url to which payloads will be sent
     */
    endpointUrl: string;
    /**
     * The JSON format (normal vs line delimited). True means line delimited JSON.
     */
    emitLineDelimitedJson: boolean;
    /**
     * The maximum size of a batch in bytes
     */
    maxBatchSizeInBytes: number;
    /**
     * The maximum interval allowed between calls to batchInvoke
     */
    maxBatchInterval: number;
    /**
     * The master off switch.  Do not send any data if set to TRUE
     */
    disableTelemetry: boolean;
    /**
     * Store a copy of a send buffer in the session storage
     */
    enableSessionStorageBuffer: boolean;
    /**
     * Specify the storage buffer type implementation.
     * @since 2.8.12
     */
    bufferOverride: IStorageBuffer | false;
    /**
     * Is retry handler disabled.
     * If enabled, retry on 206 (partial success), 408 (timeout), 429 (too many requests), 500 (internal server error) and 503 (service unavailable).
     */
    isRetryDisabled: boolean;
    isBeaconApiDisabled: boolean;
    /**
     * Don't use XMLHttpRequest or XDomainRequest (for IE < 9) by default instead attempt to use fetch() or sendBeacon.
     * If no other transport is available it will still use XMLHttpRequest
     */
    disableXhr: boolean;
    /**
     * If fetch keepalive is supported do not use it for sending events during unload, it may still fallback to fetch() without keepalive
     */
    onunloadDisableFetch: boolean;
    /**
     * Is beacon disabled on page unload.
     * If enabled, flush events through beaconSender.
     */
    onunloadDisableBeacon: boolean;
    /**
     * (Optional) Override the instrumentation key that this channel instance sends to
     */
    instrumentationKey: string;
    namePrefix: string;
    samplingPercentage: number;
    /**
     * (Optional) The ability for the user to provide extra headers
     */
    customHeaders: [{
        header: string;
        value: string;
    }];
    /**
     * (Optional) Provide user an option to convert undefined field to user defined value.
     */
    convertUndefined: any;
    /**
     * (Optional) The number of events that can be kept in memory before the SDK starts to drop events. By default, this is 10,000.
     */
    eventsLimitInMem: number;
    /**
     * (Optional) Enable the sender to return a promise so that manually flushing (and general sending) can wait for the request to finish.
     * Note: Enabling this may cause unhandled promise rejection errors to occur if you do not listen and handle any rejection response,
     * this *should* only be for manual flush attempts.
     * Defaults to false
     * @since 3.0.1
     */
    enableSendPromise?: boolean;
    /**
     * [Optional] The HTTP override that should be used to send requests, as an IXHROverride object.
     * By default during the unload of a page or if the event specifies that it wants to use sendBeacon() or sync fetch (with keep-alive),
     * this override will NOT be called.
     * If alwaysUseXhrOverride configuration value is set to true, the override will always be used.
     * The payload data (first argument) now also includes any configured 'timeout' (defaults to undefined) and whether you should avoid
     * creating any synchronous XHR requests 'disableXhr' (defaults to false/undefined)
     * @since 3.0.4
     */
    httpXHROverride?: IXHROverride;
    /**
     * [Optional] By default during unload (or when you specify to use sendBeacon() or sync fetch (with keep-alive) for an event) the SDK
     * ignores any provided httpXhrOverride and attempts to use sendBeacon() or fetch(with keep-alive) when they are available.
     * When this configuration option is true any provided httpXhrOverride will always be used, so any provided httpXhrOverride will
     * also need to "handle" the synchronous unload scenario.
     * @since 3.0.4
     */
    alwaysUseXhrOverride?: boolean;
    /**
     * [Optional] Disable events splitting during sendbeacon.
     * Default: false
     * @since 3.0.6
     */
    disableSendBeaconSplit?: boolean;
    /**
     * [Optional] Either an array or single value identifying the requested TransportType type that should be used.
     * This is used during initialization to identify the requested send transport, it will be ignored if a httpXHROverride is provided.
     */
    transports?: number | number[];
    /**
     * [Optional] Either an array or single value identifying the requested TransportType type(s) that should be used during unload or events
     * marked as sendBeacon. This is used during initialization to identify the requested send transport, it will be ignored if a httpXHROverride
     * is provided and alwaysUseXhrOverride is true.
     */
    unloadTransports?: number | number[];
    /**
     * (Optional) The specific error codes that will cause a retry of sending data to the backend.
     * @since 3.1.1
     */
    retryCodes?: number[];
    /**
     * (Optional) The specific max retry count for each telemetry item.
     * Default: 10
     * if it is set to 0, means no retry allowed
     * if it is set to undefined, means no limit for retry times
     * @since 3.2.0
     */
    maxRetryCnt?: number;
}

export declare class Sender extends BaseTelemetryPlugin implements IChannelControls {
    static constructEnvelope(orig: ITelemetryItem, iKey: string, logger: IDiagnosticLogger, convertUndefined?: any): IEnvelope;
    readonly priority: number;
    readonly identifier: string;
    /**
     * The configuration for this sender instance
     */
    readonly _senderConfig: ISenderConfig;
    /**
     * A method which will cause data to be send to the url
     */
    _sender: SenderFunction;
    /**
     * A send buffer object
     */
    _buffer: ISendBuffer;
    /**
     * AppId of this component parsed from some backend response.
     */
    _appId: string;
    protected _sample: ISample;
    constructor();
    /**
     * Pause the sending (transmission) of events, this will cause all events to be batched only until the maximum limits are
     * hit at which point new events are dropped. Will also cause events to NOT be sent during page unload, so if Session storage
     * is disabled events will be lost.
     * SessionStorage Limit is 2000 events, In-Memory (Array) Storage is 10,000 events (can be configured via the eventsLimitInMem).
     */
    pause(): void;
    /**
     * Resume the sending (transmission) of events, this will restart the timer and any batched events will be sent using the normal
     * send interval.
     */
    resume(): void;
    /**
     * Flush to send data immediately; channel should default to sending data asynchronously. If executing asynchronously (the default) and
     * you DO NOT pass a callback function then a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
     * will be returned which will resolve once the flush is complete. The actual implementation of the `IPromise`
     * will be a native Promise (if supported) or the default as supplied by [ts-async library](https://github.com/nevware21/ts-async)
     * @param async - send data asynchronously when true
     * @param callBack - if specified, notify caller when send is complete, the channel should return true to indicate to the caller that it will be called.
     * If the caller doesn't return true the caller should assume that it may never be called.
     * @param sendReason - specify the reason that you are calling "flush" defaults to ManualFlush (1) if not specified
     * @returns - If a callback is provided `true` to indicate that callback will be called after the flush is complete otherwise the caller
     * should assume that any provided callback will never be called, Nothing or if occurring asynchronously a
     * [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) which will be resolved once the unload is complete,
     * the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) will only be returned when no callback is provided
     * and async is true.
     */
    flush(async?: boolean, callBack?: (flushComplete?: boolean) => void): void | IPromise<boolean>;
    /**
     * Flush the batched events synchronously (if possible -- based on configuration).
     * Will not flush if the Send has been paused.
     */
    onunloadFlush(): void;
    initialize(config: IConfiguration & IConfig, core: IAppInsightsCore, extensions: IPlugin[], pluginChain?: ITelemetryPluginChain): void;
    processTelemetry(telemetryItem: ITelemetryItem, itemCtx?: IProcessTelemetryContext): void;
    /**
     * xhr state changes
     * @deprecated
     * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
     */
    _xhrReadyStateChange(xhr: XMLHttpRequest, payload: string[] | IInternalStorageItem[], countOfItemsInPayload: number): void;
    /**
     * Trigger the immediate send of buffered data; If executing asynchronously (the default) this may (not required) return
     * an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) that will resolve once the
     * send is complete. The actual implementation of the `IPromise` will be a native Promise (if supported) or the default
     * as supplied by [ts-async library](https://github.com/nevware21/ts-async)
     * @param async - Indicates if the events should be sent asynchronously
     * @param forcedSender - {SenderFunction} - Indicates the forcedSender, undefined if not passed
     * @returns - Nothing or optionally, if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
     * which will be resolved (or reject) once the send is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
     * should only be returned when async is true.
     */
    triggerSend(async?: boolean, forcedSender?: SenderFunction, sendReason?: SendRequestReason): void | IPromise<boolean>;
    /**
     * error handler
     * @Internal
     * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
     */
    _onError(payload: string[] | IInternalStorageItem[], message: string, event?: ErrorEvent): void;
    /**
     * partial success handler
     * @Internal
     * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
     */
    _onPartialSuccess(payload: string[] | IInternalStorageItem[], results: IBackendResponse): void;
    /**
     * success handler
     * @Internal
     * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
     */
    _onSuccess(payload: string[] | IInternalStorageItem[], countOfItemsInPayload: number): void;
    /**
     * xdr state changes
     * @deprecated
     * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
     */
    _xdrOnLoad(xdr: IXDomainRequest, payload: string[] | IInternalStorageItem[]): void;
    /**
     * Add header to request
     * @param name - Header name.
     * @param value - Header value.
     */
    addHeader(name: string, value: string): void;
    /**
     * Check if there are no active requests being sent.
     * @returns True if idle, false otherwise.
     */
    isCompletelyIdle(): boolean;
    /**
     * Get Offline Serializer support
     * @returns internal Offline Serializer object
     */
    getOfflineSupport(): IInternalOfflineSupport;
    /**
     * Get Offline listener
     * @returns offlineListener
     * @since 3.3.4
     */
    getOfflineListener(): IOfflineListener;
}

declare type SenderFunction = (payload: string[] | IInternalStorageItem[], isAsync: boolean) => void | IPromise<boolean>;

declare class SessionStorageSendBuffer extends BaseSendBuffer implements ISendBuffer {
    static VERSION: string;
    static BUFFER_KEY: string;
    static SENT_BUFFER_KEY: string;
    static MAX_BUFFER_SIZE: number;
    constructor(logger: IDiagnosticLogger, config: ISenderConfig);
    enqueue(payload: IInternalStorageItem): void;
    clear(): void;
    markAsSent(payload: IInternalStorageItem[]): void;
    clearSent(payload: IInternalStorageItem[]): void;
    createNew(newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean): ArraySendBuffer | SessionStorageSendBuffer;
}

export { }
