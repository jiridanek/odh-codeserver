/*
 * Application Insights JavaScript SDK - Channel, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// ###################################################################################################################################################
// Note: DON'T Export these const from the package as we are still targeting IE/ES5 this will export a mutable variables that someone could change ###
// ###################################################################################################################################################
// Generally you should only put values that are used more than 2 times and then only if not already exposed as a constant (such as SdkCoreNames)
// as when using "short" named values from here they will be will be minified smaller than the SdkCoreNames[eSdkCoreNames.xxxx] value.
export var STR_DURATION = "duration";
//# sourceMappingURL=InternalConstants.js.map