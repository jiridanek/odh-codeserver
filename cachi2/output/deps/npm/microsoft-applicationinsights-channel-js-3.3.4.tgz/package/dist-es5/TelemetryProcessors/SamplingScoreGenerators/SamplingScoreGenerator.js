/*
 * Application Insights JavaScript SDK - Channel, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


import { ContextTagKeys } from "@microsoft/applicationinsights-common";
import { _DYN_GET_HASH_CODE_SCORE, _DYN_GET_SAMPLING_SCORE, _DYN_TAGS, _DYN_TRACE_ID } from "../../__DynamicConstants";
import { HashCodeScoreGenerator } from "./HashCodeScoreGenerator";
var SamplingScoreGenerator = /** @class */ (function () {
    function SamplingScoreGenerator() {
        var _self = this;
        var hashCodeGenerator = new HashCodeScoreGenerator();
        var keys = new ContextTagKeys();
        _self[_DYN_GET_SAMPLING_SCORE /* @min:%2egetSamplingScore */] = function (item) {
            var score = 0;
            if (item[_DYN_TAGS /* @min:%2etags */] && item[_DYN_TAGS /* @min:%2etags */][keys.userId]) { // search in tags first, then ext
                score = hashCodeGenerator.getHashCodeScore(item[_DYN_TAGS /* @min:%2etags */][keys.userId]);
            }
            else if (item.ext && item.ext.user && item.ext.user.id) {
                score = hashCodeGenerator[_DYN_GET_HASH_CODE_SCORE /* @min:%2egetHashCodeScore */](item.ext.user.id);
            }
            else if (item[_DYN_TAGS /* @min:%2etags */] && item[_DYN_TAGS /* @min:%2etags */][keys.operationId]) { // search in tags first, then ext
                score = hashCodeGenerator.getHashCodeScore(item[_DYN_TAGS /* @min:%2etags */][keys.operationId]);
            }
            else if (item.ext && item.ext.telemetryTrace && item.ext.telemetryTrace[_DYN_TRACE_ID /* @min:%2etraceID */]) {
                score = hashCodeGenerator.getHashCodeScore(item.ext.telemetryTrace[_DYN_TRACE_ID /* @min:%2etraceID */]);
            }
            else {
                // tslint:disable-next-line:insecure-random
                score = (Math.random() * 100);
            }
            return score;
        };
    }
    return SamplingScoreGenerator;
}());
export { SamplingScoreGenerator };
//# sourceMappingURL=SamplingScoreGenerator.js.map