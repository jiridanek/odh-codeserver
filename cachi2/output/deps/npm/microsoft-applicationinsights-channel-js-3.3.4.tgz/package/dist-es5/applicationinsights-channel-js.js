/*
 * Application Insights JavaScript SDK - Channel, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */
export { Sender } from "./Sender";
//# sourceMappingURL=applicationinsights-channel-js.js.map