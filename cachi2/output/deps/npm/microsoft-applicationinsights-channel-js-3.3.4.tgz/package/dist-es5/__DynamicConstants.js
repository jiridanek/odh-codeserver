/*
 * Application Insights JavaScript SDK - Channel, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_TAGS = "tags"; // Count: 17
export var _DYN_DEVICE_TYPE = "deviceType"; // Count: 3
export var _DYN_DATA = "data"; // Count: 15
export var _DYN_NAME = "name"; // Count: 8
export var _DYN_TRACE_ID = "traceID"; // Count: 5
export var _DYN_LENGTH = "length"; // Count: 38
export var _DYN_STRINGIFY = "stringify"; // Count: 5
export var _DYN_MEASUREMENTS = "measurements"; // Count: 7
export var _DYN_DATA_TYPE = "dataType"; // Count: 10
export var _DYN_ENVELOPE_TYPE = "envelopeType"; // Count: 7
export var _DYN_TO_STRING = "toString"; // Count: 7
export var _DYN__GET = "_get"; // Count: 5
export var _DYN_ENQUEUE = "enqueue"; // Count: 7
export var _DYN_COUNT = "count"; // Count: 7
export var _DYN_EVENTS_LIMIT_IN_MEM = "eventsLimitInMem"; // Count: 2
export var _DYN_PUSH = "push"; // Count: 9
export var _DYN_ITEM = "item"; // Count: 6
export var _DYN_EMIT_LINE_DELIMITED_0 = "emitLineDelimitedJson"; // Count: 3
export var _DYN_CLEAR = "clear"; // Count: 6
export var _DYN_CREATE_NEW = "createNew"; // Count: 3
export var _DYN_MARK_AS_SENT = "markAsSent"; // Count: 4
export var _DYN_CLEAR_SENT = "clearSent"; // Count: 5
export var _DYN_BUFFER_OVERRIDE = "bufferOverride"; // Count: 3
export var _DYN__BUFFER__KEY = "BUFFER_KEY"; // Count: 5
export var _DYN__SENT__BUFFER__KEY = "SENT_BUFFER_KEY"; // Count: 8
export var _DYN_CONCAT = "concat"; // Count: 6
export var _DYN__MAX__BUFFER__SIZE = "MAX_BUFFER_SIZE"; // Count: 5
export var _DYN_TRIGGER_SEND = "triggerSend"; // Count: 5
export var _DYN_DIAG_LOG = "diagLog"; // Count: 16
export var _DYN_INITIALIZE = "initialize"; // Count: 3
export var _DYN__SENDER = "_sender"; // Count: 5
export var _DYN_ENDPOINT_URL = "endpointUrl"; // Count: 5
export var _DYN_INSTRUMENTATION_KEY = "instrumentationKey"; // Count: 5
export var _DYN_CUSTOM_HEADERS = "customHeaders"; // Count: 3
export var _DYN_MAX_BATCH_SIZE_IN_BY1 = "maxBatchSizeInBytes"; // Count: 2
export var _DYN_ONUNLOAD_DISABLE_BEA2 = "onunloadDisableBeacon"; // Count: 3
export var _DYN_IS_BEACON_API_DISABL3 = "isBeaconApiDisabled"; // Count: 3
export var _DYN_ALWAYS_USE_XHR_OVERR4 = "alwaysUseXhrOverride"; // Count: 2
export var _DYN_DISABLE_XHR = "disableXhr"; // Count: 3
export var _DYN_ENABLE_SESSION_STORA5 = "enableSessionStorageBuffer"; // Count: 2
export var _DYN__BUFFER = "_buffer"; // Count: 9
export var _DYN_ONUNLOAD_DISABLE_FET6 = "onunloadDisableFetch"; // Count: 2
export var _DYN_DISABLE_SEND_BEACON_7 = "disableSendBeaconSplit"; // Count: 2
export var _DYN_ENABLE_SEND_PROMISE = "enableSendPromise"; // Count: 2
export var _DYN_GET_SENDER_INST = "getSenderInst"; // Count: 4
export var _DYN_UNLOAD_TRANSPORTS = "unloadTransports"; // Count: 2
export var _DYN_CONVERT_UNDEFINED = "convertUndefined"; // Count: 2
export var _DYN_MAX_BATCH_INTERVAL = "maxBatchInterval"; // Count: 2
export var _DYN_SERIALIZE = "serialize"; // Count: 4
export var _DYN__ON_ERROR = "_onError"; // Count: 7
export var _DYN__ON_PARTIAL_SUCCESS = "_onPartialSuccess"; // Count: 3
export var _DYN__ON_SUCCESS = "_onSuccess"; // Count: 6
export var _DYN_ITEMS_RECEIVED = "itemsReceived"; // Count: 3
export var _DYN_ITEMS_ACCEPTED = "itemsAccepted"; // Count: 3
export var _DYN_ORI_PAYLOAD = "oriPayload"; // Count: 3
export var _DYN_BASE_TYPE = "baseType"; // Count: 4
export var _DYN_SAMPLE_RATE = "sampleRate"; // Count: 4
export var _DYN_EVENTS_SEND_REQUEST = "eventsSendRequest"; // Count: 2
export var _DYN_GET_SAMPLING_SCORE = "getSamplingScore"; // Count: 2
export var _DYN_GET_HASH_CODE_SCORE = "getHashCodeScore"; // Count: 4
//# sourceMappingURL=__DynamicConstants.js.map