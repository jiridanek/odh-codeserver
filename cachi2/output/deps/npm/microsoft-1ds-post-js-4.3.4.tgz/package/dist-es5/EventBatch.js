/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* EventBatch.ts
* @author Nev Wylie (newylie)
* @copyright Microsoft 2020
*/
import { isNullOrUndefined, isValueAssigned } from "@microsoft/1ds-core-js";
import { STR_EMPTY, STR_MSFPC } from "./InternalConstants";
import { _DYN_CONCAT, _DYN_COUNT, _DYN_EVENTS, _DYN_I_KEY, _DYN_LENGTH, _DYN_PUSH, _DYN_SPLICE, _DYN_SPLIT } from "./__DynamicConstants";
function _getEventMsfpc(theEvent) {
    var intWeb = ((theEvent.ext || {})["intweb"]);
    if (intWeb && isValueAssigned(intWeb[STR_MSFPC])) {
        return intWeb[STR_MSFPC];
    }
    return null;
}
function _getMsfpc(theEvents) {
    var msfpc = null;
    for (var lp = 0; msfpc === null && lp < theEvents[_DYN_LENGTH /* @min:%2elength */]; lp++) {
        msfpc = _getEventMsfpc(theEvents[lp]);
    }
    return msfpc;
}
/**
* This class defines a "batch" events related to a specific iKey, it is used by the PostChannel and HttpManager
* to collect and transfer ownership of events without duplicating them in-memory. This reduces the previous
* array duplication and shared ownership issues that occurred due to race conditions caused by the async nature
* of sending requests.
*/
var EventBatch = /** @class */ (function () {
    /**
     * Private constructor so that caller is forced to use the static create method.
     * @param iKey - The iKey to associate with the events (not validated)
     * @param addEvents - The optional collection of events to assign to this batch - defaults to an empty array.
     */
    function EventBatch(iKey, addEvents) {
        var events = addEvents ? [][_DYN_CONCAT /* @min:%2econcat */](addEvents) : [];
        var _self = this;
        var _msfpc = _getMsfpc(events);
        _self[_DYN_I_KEY /* @min:%2eiKey */] = function () {
            return iKey;
        };
        _self.Msfpc = function () {
            // return the cached value unless it's undefined -- used to avoid cpu
            return _msfpc || STR_EMPTY;
        };
        _self[_DYN_COUNT /* @min:%2ecount */] = function () {
            return events[_DYN_LENGTH /* @min:%2elength */];
        };
        _self[_DYN_EVENTS /* @min:%2eevents */] = function () {
            return events;
        };
        _self.addEvent = function (theEvent) {
            if (theEvent) {
                events[_DYN_PUSH /* @min:%2epush */](theEvent);
                if (!_msfpc) {
                    // Not found so try and find one
                    _msfpc = _getEventMsfpc(theEvent);
                }
                return true;
            }
            return false;
        };
        _self[_DYN_SPLIT /* @min:%2esplit */] = function (fromEvent, numEvents) {
            // Create a new batch with the same iKey
            var theEvents;
            if (fromEvent < events[_DYN_LENGTH /* @min:%2elength */]) {
                var cnt = events[_DYN_LENGTH /* @min:%2elength */] - fromEvent;
                if (!isNullOrUndefined(numEvents)) {
                    cnt = numEvents < cnt ? numEvents : cnt;
                }
                theEvents = events[_DYN_SPLICE /* @min:%2esplice */](fromEvent, cnt);
                // reset the fetched msfpc value
                _msfpc = _getMsfpc(events);
            }
            return new EventBatch(iKey, theEvents);
        };
    }
    /**
     * Creates a new Event Batch object
     * @param iKey The iKey associated with this batch of events
     */
    EventBatch.create = function (iKey, theEvents) {
        return new EventBatch(iKey, theEvents);
    };
    return EventBatch;
}());
export { EventBatch };
//# sourceMappingURL=EventBatch.js.map