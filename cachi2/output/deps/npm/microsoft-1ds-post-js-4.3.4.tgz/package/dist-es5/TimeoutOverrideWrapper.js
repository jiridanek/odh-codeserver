/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* TimeoutOverrideWrapper.ts
* @author  Nev Wylie (newylie)
* @copyright Microsoft 2022
* Simple internal timeout wrapper
*/
import { scheduleTimeoutWith } from "@nevware21/ts-utils";
export function createTimeoutWrapper(argSetTimeout, argClearTimeout) {
    return {
        set: function (callback, ms) {
            var args = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                args[_i - 2] = arguments[_i];
            }
            return scheduleTimeoutWith([argSetTimeout, argClearTimeout], callback, ms, args);
        }
    };
}
//# sourceMappingURL=TimeoutOverrideWrapper.js.map