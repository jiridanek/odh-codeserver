/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
export {};
// export declare var XDomainRequest: {
//     prototype: IXDomainRequest;
//     new (): IXDomainRequest;
// };
//# sourceMappingURL=XDomainRequest.js.map