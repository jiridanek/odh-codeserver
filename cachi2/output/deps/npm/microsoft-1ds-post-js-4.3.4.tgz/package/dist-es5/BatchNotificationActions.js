/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
export {};
//# sourceMappingURL=BatchNotificationActions.js.map