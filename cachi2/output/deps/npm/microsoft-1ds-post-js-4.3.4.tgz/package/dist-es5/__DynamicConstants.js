/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */

// Licensed under the MIT License.
// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_ALLOW_REQUEST_SENDIN0 = "allowRequestSending"; // Count: 3
export var _DYN_FIRST_REQUEST_SENT = "firstRequestSent"; // Count: 2
export var _DYN_SHOULD_ADD_CLOCK_SKE1 = "shouldAddClockSkewHeaders"; // Count: 2
export var _DYN_GET_CLOCK_SKEW_HEADE2 = "getClockSkewHeaderValue"; // Count: 2
export var _DYN_SET_CLOCK_SKEW = "setClockSkew"; // Count: 3
export var _DYN_LENGTH = "length"; // Count: 38
export var _DYN_CONCAT = "concat"; // Count: 7
export var _DYN_I_KEY = "iKey"; // Count: 11
export var _DYN_COUNT = "count"; // Count: 19
export var _DYN_EVENTS = "events"; // Count: 8
export var _DYN_PUSH = "push"; // Count: 15
export var _DYN_SPLIT = "split"; // Count: 6
export var _DYN_SPLICE = "splice"; // Count: 4
export var _DYN_TO_LOWER_CASE = "toLowerCase"; // Count: 3
export var _DYN_HDRS = "hdrs"; // Count: 7
export var _DYN_USE_HDRS = "useHdrs"; // Count: 5
export var _DYN_INITIALIZE = "initialize"; // Count: 5
export var _DYN_SET_TIMEOUT_OVERRIDE = "setTimeoutOverride"; // Count: 3
export var _DYN_CLEAR_TIMEOUT_OVERRI3 = "clearTimeoutOverride"; // Count: 3
export var _DYN_PAYLOAD_PREPROCESSOR = "payloadPreprocessor"; // Count: 2
export var _DYN_OVERRIDE_ENDPOINT_UR4 = "overrideEndpointUrl"; // Count: 3
export var _DYN_AVOID_OPTIONS = "avoidOptions"; // Count: 3
export var _DYN_DISABLE_EVENT_TIMING5 = "disableEventTimings"; // Count: 2
export var _DYN_STRINGIFY_OBJECTS = "stringifyObjects"; // Count: 2
export var _DYN_ENABLE_COMPOUND_KEY = "enableCompoundKey"; // Count: 4
export var _DYN_DISABLE_XHR_SYNC = "disableXhrSync"; // Count: 6
export var _DYN_DISABLE_FETCH_KEEP_A6 = "disableFetchKeepAlive"; // Count: 7
export var _DYN_ADD_NO_RESPONSE = "addNoResponse"; // Count: 3
export var _DYN_EXCLUDE_CS_META_DATA = "excludeCsMetaData"; // Count: 2
export var _DYN_USE_SEND_BEACON = "useSendBeacon"; // Count: 3
export var _DYN_FETCH_CREDENTIALS = "fetchCredentials"; // Count: 4
export var _DYN_ALWAYS_USE_XHR_OVERR7 = "alwaysUseXhrOverride"; // Count: 3
export var _DYN_UNLOAD_TRANSPORTS = "unloadTransports"; // Count: 2
export var _DYN_SERIALIZE_OFFLINE_EV8 = "serializeOfflineEvt"; // Count: 2
export var _DYN_GET_OFFLINE_REQUEST_9 = "getOfflineRequestDetails"; // Count: 2
export var _DYN_CREATE_PAYLOAD = "createPayload"; // Count: 4
export var _DYN_CREATE_ONE_DSPAYLOAD = "createOneDSPayload"; // Count: 4
export var _DYN_PAYLOAD_BLOB = "payloadBlob"; // Count: 3
export var _DYN_HEADERS = "headers"; // Count: 12
export var _DYN__THE_PAYLOAD = "_thePayload"; // Count: 6
export var _DYN_URL_STRING = "urlString"; // Count: 5
export var _DYN_BATCHES = "batches"; // Count: 15
export var _DYN_SEND_TYPE = "sendType"; // Count: 13
export var _DYN_ADD_HEADER = "addHeader"; // Count: 3
export var _DYN_CAN_SEND_REQUEST = "canSendRequest"; // Count: 3
export var _DYN_SEND_QUEUED_REQUESTS = "sendQueuedRequests"; // Count: 5
export var _DYN_IS_COMPLETELY_IDLE = "isCompletelyIdle"; // Count: 2
export var _DYN_SET_UNLOADING = "setUnloading"; // Count: 3
export var _DYN_IS_TENANT_KILLED = "isTenantKilled"; // Count: 3
export var _DYN_RESUME = "resume"; // Count: 4
export var _DYN_SEND_SYNCHRONOUS_BAT10 = "sendSynchronousBatch"; // Count: 2
export var _DYN__TRANSPORT = "_transport"; // Count: 3
export var _DYN_GET_WPARAM = "getWParam"; // Count: 4
export var _DYN_IS_BEACON = "isBeacon"; // Count: 4
export var _DYN_TIMINGS = "timings"; // Count: 4
export var _DYN_IS_TEARDOWN = "isTeardown"; // Count: 3
export var _DYN_IS_SYNC = "isSync"; // Count: 4
export var _DYN_DATA = "data"; // Count: 7
export var _DYN_TIMEOUT = "timeout"; // Count: 4
export var _DYN__SEND_REASON = "_sendReason"; // Count: 4
export var _DYN_SET_KILL_SWITCH_TENA11 = "setKillSwitchTenants"; // Count: 2
export var _DYN__BACK_OFF_TRANSMISSI12 = "_backOffTransmission"; // Count: 2
export var _DYN_IDENTIFIER = "identifier"; // Count: 4
export var _DYN_DISABLE_OPTIMIZE_OBJ = "disableOptimizeObj"; // Count: 2
export var _DYN_IGNORE_MC1_MS0_COOKI13 = "ignoreMc1Ms0CookieProcessing"; // Count: 2
export var _DYN_EVENTS_LIMIT_IN_MEM = "eventsLimitInMem"; // Count: 2
export var _DYN_AUTO_FLUSH_EVENTS_LI14 = "autoFlushEventsLimit"; // Count: 2
export var _DYN_DISABLE_AUTO_BATCH_F15 = "disableAutoBatchFlushLimit"; // Count: 2
export var _DYN_OVERRIDE_INSTRUMENTA16 = "overrideInstrumentationKey"; // Count: 2
export var _DYN_DISABLE_TELEMETRY = "disableTelemetry"; // Count: 2
export var _DYN_BASE_DATA = "baseData"; // Count: 3
export var _DYN_SEND_ATTEMPT = "sendAttempt"; // Count: 4
export var _DYN_LATENCY = "latency"; // Count: 7
export var _DYN_SYNC = "sync"; // Count: 7
//# sourceMappingURL=__DynamicConstants.js.map