/*
 * 1DS JS SDK POST plugin, 4.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
/**
* @name Index.ts
* @author Abhilash Panwar (abpanwar)
* @copyright Microsoft 2018
* File to export public classes.
*/
import { BE_PROFILE, NRT_PROFILE, RT_PROFILE } from "./DataModels";
import { PostChannel } from "./PostChannel";
export { PostChannel, BE_PROFILE, NRT_PROFILE, RT_PROFILE };
//# sourceMappingURL=Index.js.map