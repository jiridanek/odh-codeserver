# Installation
> `npm install --save @types/xml2js`

# Summary
This package contains type definitions for node-xml2js (https://github.com/Leonidas-from-XIV/node-xml2js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/xml2js

Additional Details
 * Last updated: Sat, 11 Mar 2017 00:22:02 GMT
 * Dependencies: events
 * Global values: none

# Credits
These definitions were written by Michel Salib <https://github.com/michelsalib>, Jason McNeil <https://github.com/jasonrm>, Christopher Currens <https://github.com/ccurrens>, Edward Hinkle <https://github.com/edwardhinkle>.
