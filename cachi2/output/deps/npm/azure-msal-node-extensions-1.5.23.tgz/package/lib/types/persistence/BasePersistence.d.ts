import { IPersistence } from "./IPersistence.js";
export declare abstract class BasePersistence {
    abstract createForPersistenceValidation(): Promise<IPersistence>;
    verifyPersistence(): Promise<boolean>;
}
