export declare class StringUtils {
    /**
     * Converts a numeric tag to a string representation
     * @param tag - The numeric tag to convert
     * @returns The string representation of the tag
     */
    static tagToString(tag: number): string;
}
