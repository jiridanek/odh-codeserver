import { IPersistence } from "./IPersistence.js";
import { Logger, LoggerOptions } from "@azure/msal-common/node";
import { BasePersistence } from "./BasePersistence.js";
/**
 * Uses reads and writes passwords to macOS keychain
 *
 * serviceName: Identifier used as key for whatever value is stored
 * accountName: Account under which password should be stored
 */
export declare class KeychainPersistence extends BasePersistence implements IPersistence {
    protected readonly serviceName: string;
    protected readonly accountName: string;
    private filePersistence;
    private constructor();
    static create(fileLocation: string, serviceName: string, accountName: string, loggerOptions?: LoggerOptions): Promise<KeychainPersistence>;
    save(contents: string): Promise<void>;
    load(): Promise<string | null>;
    delete(): Promise<boolean>;
    reloadNecessary(lastSync: number): Promise<boolean>;
    getFilePath(): string;
    getLogger(): Logger;
    createForPersistenceValidation(): Promise<KeychainPersistence>;
}
