import { IPersistence } from "./IPersistence.js";
import { Logger, LoggerOptions } from "@azure/msal-common/node";
import { BasePersistence } from "./BasePersistence.js";
/**
 * Uses reads and writes passwords to Secret Service API/libsecret. Requires libsecret
 * to be installed.
 *
 * serviceName: Identifier used as key for whatever value is stored
 * accountName: Account under which password should be stored
 */
export declare class LibSecretPersistence extends BasePersistence implements IPersistence {
    protected readonly serviceName: string;
    protected readonly accountName: string;
    private filePersistence;
    private constructor();
    static create(fileLocation: string, serviceName: string, accountName: string, loggerOptions?: LoggerOptions): Promise<LibSecretPersistence>;
    save(contents: string): Promise<void>;
    load(): Promise<string | null>;
    delete(): Promise<boolean>;
    reloadNecessary(lastSync: number): Promise<boolean>;
    getFilePath(): string;
    getLogger(): Logger;
    createForPersistenceValidation(): Promise<LibSecretPersistence>;
}
