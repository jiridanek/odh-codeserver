export declare const Constants: {
    /**
     * An existing file was the target of an operation that required that the target not exist
     */
    EEXIST_ERROR: string;
    /**
     * No such file or directory: Commonly raised by fs operations to indicate that a component
     * of the specified pathname does not exist. No entity (file or directory) could be found
     * by the given path
     */
    ENOENT_ERROR: string;
    /**
     * Operation not permitted. An attempt was made to perform an operation that requires
     * elevated privileges.
     */
    EPERM_ERROR: string;
    /**
     * Default service name for using MSAL Keytar
     */
    DEFAULT_SERVICE_NAME: string;
    /**
     * Test data used to verify underlying persistence mechanism
     */
    PERSISTENCE_TEST_DATA: string;
    /**
     * This is the value of a the guid if the process is being ran by the root user
     */
    LINUX_ROOT_USER_GUID: number;
    /**
     * List of environment variables
     */
    ENVIRONMENT: {
        HOME: string;
        LOGNAME: string;
        USER: string;
        LNAME: string;
        USERNAME: string;
        PLATFORM: string;
        LOCAL_APPLICATION_DATA: string;
    };
    DEFAULT_CACHE_FILE_NAME: string;
};
export declare const Platform: {
    readonly WINDOWS: "win32";
    readonly LINUX: "linux";
    readonly MACOS: "darwin";
};
export type Platform = (typeof Platform)[keyof typeof Platform];
export declare const ErrorCodes: {
    readonly INTERATION_REQUIRED_ERROR_CODE: "interaction_required";
    readonly SERVER_UNAVAILABLE: "server_unavailable";
    readonly UNKNOWN: "unknown_error";
};
export type ErrorCodes = (typeof ErrorCodes)[keyof typeof ErrorCodes];
