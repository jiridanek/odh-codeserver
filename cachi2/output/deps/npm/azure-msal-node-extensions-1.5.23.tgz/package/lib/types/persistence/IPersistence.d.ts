import { Logger } from "@azure/msal-common/node";
export interface IPersistence {
    save(contents: string): Promise<void>;
    load(): Promise<string | null>;
    delete(): Promise<boolean>;
    reloadNecessary(lastSync: number): Promise<boolean>;
    getFilePath(): string;
    getLogger(): Logger;
    verifyPersistence(): Promise<boolean>;
    createForPersistenceValidation(): Promise<IPersistence>;
}
