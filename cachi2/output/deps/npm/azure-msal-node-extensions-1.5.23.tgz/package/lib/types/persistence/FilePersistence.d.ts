import { IPersistence } from "./IPersistence.js";
import { Logger, LoggerOptions } from "@azure/msal-common/node";
import { BasePersistence } from "./BasePersistence.js";
/**
 * Reads and writes data to file specified by file location. File contents are not
 * encrypted.
 *
 * If file or directory has not been created, it FilePersistence.create() will create
 * file and any directories in the path recursively.
 */
export declare class FilePersistence extends BasePersistence implements IPersistence {
    private filePath;
    private logger;
    private constructor();
    static create(fileLocation: string, loggerOptions?: LoggerOptions): Promise<FilePersistence>;
    save(contents: string): Promise<void>;
    saveBuffer(contents: Uint8Array): Promise<void>;
    load(): Promise<string | null>;
    loadBuffer(): Promise<Uint8Array>;
    delete(): Promise<boolean>;
    getFilePath(): string;
    reloadNecessary(lastSync: number): Promise<boolean>;
    getLogger(): Logger;
    createForPersistenceValidation(): Promise<FilePersistence>;
    private static createDefaultLoggerOptions;
    private timeLastModified;
    private createCacheFile;
    private createFileDirectory;
}
