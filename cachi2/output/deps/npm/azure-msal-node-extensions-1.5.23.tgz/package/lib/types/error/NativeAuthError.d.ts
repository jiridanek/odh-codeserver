import { AuthError } from "@azure/msal-common/node";
export declare class NativeAuthError extends AuthError {
    statusCode: number;
    tag: string;
    constructor(errorStatus: string, errorContext: string, errorCode: number, errorTag: number);
}
