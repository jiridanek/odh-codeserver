export interface DpapiBindings {
    protectData(dataToEncrypt: Uint8Array, optionalEntropy: Uint8Array | null, scope: string): Uint8Array;
    unprotectData(encryptData: Uint8Array, optionalEntropy: Uint8Array | null, scope: string): Uint8Array;
}
declare let Dpapi: DpapiBindings;
export { Dpapi };
