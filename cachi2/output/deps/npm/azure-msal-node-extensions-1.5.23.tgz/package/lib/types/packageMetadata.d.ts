export declare const name = "@azure/msal-node-extensions";
export declare const version = "1.5.23";
