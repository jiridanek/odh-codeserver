export declare class Environment {
    static get homeEnvVar(): string;
    static get lognameEnvVar(): string;
    static get userEnvVar(): string;
    static get lnameEnvVar(): string;
    static get usernameEnvVar(): string;
    static getEnvironmentVariable(name: string): string;
    static getEnvironmentPlatform(): string;
    static isWindowsPlatform(): boolean;
    static isLinuxPlatform(): boolean;
    static isMacPlatform(): boolean;
    static isLinuxRootUser(): boolean;
    static getUserRootDirectory(): string | null;
    static getUserHomeDirOnWindows(): string;
    static getUserHomeDirOnUnix(): string | null;
}
