/// <reference types="node" resolution-mode="require"/>
/// <reference types="node" resolution-mode="require"/>
import { AccountInfo, AuthenticationResult, INativeBrokerPlugin, LoggerOptions, NativeRequest, NativeSignOutRequest } from "@azure/msal-common/node";
export declare class NativeBrokerPlugin implements INativeBrokerPlugin {
    private logger;
    isBrokerAvailable: boolean;
    constructor();
    setLogger(loggerOptions: LoggerOptions): void;
    getAccountById(accountId: string, correlationId: string): Promise<AccountInfo>;
    getAllAccounts(clientId: string, correlationId: string): Promise<AccountInfo[]>;
    acquireTokenSilent(request: NativeRequest): Promise<AuthenticationResult>;
    acquireTokenInteractive(request: NativeRequest, providedWindowHandle?: Buffer): Promise<AuthenticationResult>;
    signOut(request: NativeSignOutRequest): Promise<void>;
    private getAccount;
    private readAccountById;
    private generateRequestParameters;
    private chooseRedirectUriByPlatform;
    private getAuthenticationResult;
    private generateAccountInfo;
    private isMsalRuntimeError;
    private wrapError;
}
