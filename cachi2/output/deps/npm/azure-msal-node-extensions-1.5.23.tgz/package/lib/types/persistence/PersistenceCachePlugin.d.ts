import { IPersistence } from "./IPersistence.js";
import { CrossPlatformLockOptions } from "../lock/CrossPlatformLockOptions.js";
import { TokenCacheContext, ICachePlugin } from "@azure/msal-common/node";
/**
 * MSAL cache plugin which enables callers to write the MSAL cache to disk on Windows,
 * macOs, and Linux.
 *
 * - Persistence can be one of:
 * - FilePersistence: Writes and reads from an unencrypted file. Can be used on Windows,
 * macOs, or Linux.
 * - FilePersistenceWithDataProtection: Used on Windows, writes and reads from file encrypted
 * with windows dpapi-addon.
 * - KeychainPersistence: Used on macOs, writes and reads from keychain.
 * - LibSecretPersistence: Used on linux, writes and reads from secret service API. Requires
 * libsecret be installed.
 */
export declare class PersistenceCachePlugin implements ICachePlugin {
    persistence: IPersistence;
    lastSync: number;
    currentCache: string | null;
    lockFilePath: string;
    private crossPlatformLock;
    private logger;
    constructor(persistence: IPersistence, lockOptions?: CrossPlatformLockOptions);
    /**
     * Reads from storage and saves an in-memory copy. If persistence has not been updated
     * since last time data was read, in memory copy is used.
     *
     * If cacheContext.cacheHasChanged === true, then file lock is created and not deleted until
     * afterCacheAccess() is called, to prevent the cache file from changing in between
     * beforeCacheAccess() and afterCacheAccess().
     */
    beforeCacheAccess(cacheContext: TokenCacheContext): Promise<void>;
    /**
     * Writes to storage if MSAL in memory copy of cache has been changed.
     */
    afterCacheAccess(cacheContext: TokenCacheContext): Promise<void>;
}
