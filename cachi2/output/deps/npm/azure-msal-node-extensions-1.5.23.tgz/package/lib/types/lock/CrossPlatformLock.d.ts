import { CrossPlatformLockOptions } from "./CrossPlatformLockOptions.js";
import { Logger } from "@azure/msal-common/node";
/**
 * Cross-process lock that works on all platforms.
 */
export declare class CrossPlatformLock {
    private readonly lockFilePath;
    private lockFileHandle;
    private readonly retryNumber;
    private readonly retryDelay;
    private logger;
    constructor(lockFilePath: string, logger: Logger, lockOptions?: CrossPlatformLockOptions);
    /**
     * Locks cache from read or writes by creating file with same path and name as
     * cache file but with .lockfile extension. If another process has already created
     * the lockfile, will back off and retry based on configuration settings set by CrossPlatformLockOptions
     */
    lock(): Promise<void>;
    /**
     * unlocks cache file by deleting .lockfile.
     */
    unlock(): Promise<void>;
    private sleep;
}
