/**
 * Error thrown when trying to write MSAL cache to persistence.
 */
export declare class PersistenceError extends Error {
    errorCode: string;
    errorMessage: string;
    constructor(errorCode: string, errorMessage: string);
    /**
     * Error thrown when trying to access the file system.
     */
    static createFileSystemError(errorCode: string, errorMessage: string): PersistenceError;
    /**
     * Error thrown when trying to write, load, or delete data from secret service on linux.
     * Libsecret is used to access secret service.
     */
    static createLibSecretError(errorMessage: string): PersistenceError;
    /**
     * Error thrown when trying to write, load, or delete data from keychain on macOs.
     */
    static createKeychainPersistenceError(errorMessage: string): PersistenceError;
    /**
     * Error thrown when trying to encrypt or decrypt data using DPAPI on Windows.
     */
    static createFilePersistenceWithDPAPIError(errorMessage: string): PersistenceError;
    /**
     * Error thrown when using the cross platform lock.
     */
    static createCrossPlatformLockError(errorMessage: string): PersistenceError;
    /**
     * Throw cache persistence error
     *
     * @param errorMessage string
     * @returns PersistenceError
     */
    static createCachePersistenceError(errorMessage: string): PersistenceError;
    /**
     * Throw unsupported error
     *
     * @param errorMessage string
     * @returns PersistenceError
     */
    static createNotSupportedError(errorMessage: string): PersistenceError;
    /**
     * Throw persistence not verified error
     *
     * @param errorMessage string
     * @returns PersistenceError
     */
    static createPersistenceNotVerifiedError(errorMessage: string): PersistenceError;
    /**
     * Throw persistence creation validation error
     *
     * @param errorMessage string
     * @returns PersistenceError
     */
    static createPersistenceNotValidatedError(errorMessage: string): PersistenceError;
}
