import { IPersistence } from "./IPersistence.js";
import { IPersistenceConfiguration } from "./IPersistenceConfiguration.js";
export declare class PersistenceCreator {
    static createPersistence(config: IPersistenceConfiguration): Promise<IPersistence>;
}
