/// <reference types="node" resolution-mode="require"/>
/**
 * Returns whether or not the given object is a Node.js error
 */
export declare const isNodeError: (error: unknown) => error is NodeJS.ErrnoException;
