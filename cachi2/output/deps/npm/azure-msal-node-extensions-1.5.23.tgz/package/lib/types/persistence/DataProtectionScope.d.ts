/**
 * Specifies the scope of the data protection - either the current user or the local
 * machine.
 *
 * You do not need a key to protect or unprotect the data.
 * If you set the Scope to CurrentUser, only applications running on your credentials can
 * unprotect the data; however, that means that any application running on your credentials
 * can access the protected data. If you set the Scope to LocalMachine, any full-trust
 * application on the computer can unprotect, access, and modify the data.
 *
 */
export declare const DataProtectionScope: {
    readonly CurrentUser: "CurrentUser";
    readonly LocalMachine: "LocalMachine";
};
export type DataProtectionScope = (typeof DataProtectionScope)[keyof typeof DataProtectionScope];
