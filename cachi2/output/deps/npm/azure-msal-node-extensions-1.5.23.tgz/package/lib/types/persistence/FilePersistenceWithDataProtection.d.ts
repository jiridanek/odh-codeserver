import { IPersistence } from "./IPersistence.js";
import { DataProtectionScope } from "./DataProtectionScope.js";
import { Logger, LoggerOptions } from "@azure/msal-common/node";
import { BasePersistence } from "./BasePersistence.js";
/**
 * Uses CryptProtectData and CryptUnprotectData on Windows to encrypt and decrypt file contents.
 *
 * scope: Scope of the data protection. Either local user or the current machine
 * optionalEntropy: Password or other additional entropy used to encrypt the data
 */
export declare class FilePersistenceWithDataProtection extends BasePersistence implements IPersistence {
    private filePersistence;
    private scope;
    private optionalEntropy;
    private constructor();
    static create(fileLocation: string, scope: DataProtectionScope, optionalEntropy?: string, loggerOptions?: LoggerOptions): Promise<FilePersistenceWithDataProtection>;
    save(contents: string): Promise<void>;
    load(): Promise<string | null>;
    delete(): Promise<boolean>;
    reloadNecessary(lastSync: number): Promise<boolean>;
    getFilePath(): string;
    getLogger(): Logger;
    createForPersistenceValidation(): Promise<FilePersistenceWithDataProtection>;
}
