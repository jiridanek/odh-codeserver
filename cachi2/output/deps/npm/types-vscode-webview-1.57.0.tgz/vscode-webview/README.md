# Installation
> `npm install --save @types/vscode-webview`

# Summary
This package contains type definitions for vscode-webview (https://code.visualstudio.com/api/extension-guides/webview).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vscode-webview.

### Additional Details
 * Last updated: Wed, 26 May 2021 19:01:22 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Matt Bierner](https://github.com/mjbvz).
