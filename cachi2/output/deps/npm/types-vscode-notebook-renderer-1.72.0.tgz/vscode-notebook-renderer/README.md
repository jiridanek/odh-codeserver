# Installation
> `npm install --save @types/vscode-notebook-renderer`

# Summary
This package contains type definitions for vscode-notebook-renderer (https://github.com/microsoft/vscode-docs/blob/notebook/api/extension-guides/notebook.md).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vscode-notebook-renderer.

### Additional Details
 * Last updated: Thu, 15 Sep 2022 19:02:48 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Connor Peet](https://github.com/connor4312), and [Matt Bierner](https://github.com/mjbvz).
