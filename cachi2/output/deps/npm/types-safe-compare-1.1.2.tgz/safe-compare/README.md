# Installation
> `npm install --save @types/safe-compare`

# Summary
This package contains type definitions for safe-compare (https://github.com/Bruce17/safe-compare#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/safe-compare.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/safe-compare/index.d.ts)
````ts
export = safeCompare;

/**
 * Do a constant time string comparison. Always compare the complete strings
 * against each other to get a constant time. This method does not short-cut
 * if the two string's length differs.
 */
declare function safeCompare(a: string, b: string): boolean;

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: none

# Credits
These definitions were written by [Vadim Belorussov](https://github.com/bevalorous).
