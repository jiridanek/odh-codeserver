# Installation
> `npm install --save @types/gulp-filter`

# Summary
This package contains type definitions for gulp-filter (https://github.com/sindresorhus/gulp-filter).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-filter

Additional Details
 * Last updated: Thu, 22 Mar 2018 21:28:49 GMT
 * Dependencies: vinyl, minimatch, node
 * Global values: none

# Credits
These definitions were written by Tanguy Krotoff <https://github.com/tkrotoff>.
