// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import { createClientLogger } from "@azure/logger";
/**
 * The `@azure/logger` configuration for this package.
 */
export const logger = createClientLogger("storage-blob");
//# sourceMappingURL=log.js.map