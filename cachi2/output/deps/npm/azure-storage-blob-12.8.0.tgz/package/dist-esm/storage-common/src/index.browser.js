// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
export * from "./BufferScheduler.browser";
//# sourceMappingURL=index.browser.js.map