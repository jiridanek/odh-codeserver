import { TelemetryUnloadReason } from "../JavaScriptSDK.Enums/TelemetryUnloadReason";
export interface ITelemetryUnloadState {
    reason: TelemetryUnloadReason;
    isAsync: boolean;
    flushComplete?: boolean;
}
