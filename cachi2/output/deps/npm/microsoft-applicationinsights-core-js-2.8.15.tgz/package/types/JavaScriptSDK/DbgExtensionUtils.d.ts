import { IConfiguration } from "../JavaScriptSDK.Interfaces/IConfiguration";
import { IDbgExtension } from "../JavaScriptSDK.Interfaces/IDbgExtension";
import { INotificationListener } from "../JavaScriptSDK.Interfaces/INotificationListener";
export declare function getDebugExt(config: IConfiguration): IDbgExtension;
export declare function getDebugListener(config: IConfiguration): INotificationListener;
