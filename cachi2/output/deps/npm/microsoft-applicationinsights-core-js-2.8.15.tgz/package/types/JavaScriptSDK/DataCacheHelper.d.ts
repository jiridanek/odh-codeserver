export interface IDataCache {
    id: string;
    accept: (target: any) => boolean;
    get: <T>(target: any, name: string, defValue?: T, addDefault?: boolean) => T;
    kill: (target: any, name: string) => void;
}
export declare function createUniqueNamespace(name: string, includeVersion?: boolean): string;
export declare function createElmNodeData(name?: string): {
    id: string;
    accept: (target: any) => boolean;
    get: <T>(target: any, name: string, defValue?: T, addDefault?: boolean) => T;
    kill: (target: any, name: string) => void;
};
