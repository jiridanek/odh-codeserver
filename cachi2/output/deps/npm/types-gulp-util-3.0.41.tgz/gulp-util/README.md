# Installation
> `npm install --save @types/gulp-util`

# Summary
This package contains type definitions for gulp-util (https://github.com/gulpjs/gulp-util).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gulp-util.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node), [@types/through2](https://npmjs.com/package/@types/through2), [@types/vinyl](https://npmjs.com/package/@types/vinyl), [chalk](https://npmjs.com/package/chalk)

# Credits
These definitions were written by .
