# Installation
> `npm install --save @types/windows-foreground-love`

# Summary
This package contains type definitions for windows-foreground-love (https://github.com/the-ress/node-windows-foreground-love#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/windows-foreground-love.

### Additional Details
 * Last updated: Mon, 11 Nov 2019 23:03:26 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Tereza Tomcova (https://github.com/the-ress).
