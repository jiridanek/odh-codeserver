const VERSION = "8.2.1";
export {
  VERSION
};
