/*
 * Application Insights JavaScript Web SDK - Basic, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


var _a;
import dynamicProto from "@microsoft/dynamicproto-js";
import { Sender } from "@microsoft/applicationinsights-channel-js";
import { DEFAULT_BREEZE_PATH, parseConnectionString } from "@microsoft/applicationinsights-common";
import { AppInsightsCore, cfgDfValidate, createDynamicConfig, onConfigChange, proxyFunctions } from "@microsoft/applicationinsights-core-js";
import { createSyncPromise, doAwaitResponse } from "@nevware21/ts-async";
import { isNullOrUndefined, isPromiseLike, isString, objDefine, throwError } from "@nevware21/ts-utils";
import { _DYN_CONNECTION_STRING, _DYN_ENDPOINT_URL, _DYN_INGESTIONENDPOINT, _DYN_INSTRUMENTATIONKEY0, _DYN_INSTRUMENTATION_KEY, _DYN_USER_OVERRIDE_ENDPOI1 } from "./__DynamicConstants";
var UNDEFINED_VALUE = undefined;
var defaultConfigValues = (_a = {
        diagnosticLogInterval: cfgDfValidate(_chkDiagLevel, 10000)
    },
    _a[_DYN_CONNECTION_STRING /* @min:connectionString */] = UNDEFINED_VALUE,
    _a[_DYN_ENDPOINT_URL /* @min:endpointUrl */] = UNDEFINED_VALUE,
    _a[_DYN_INSTRUMENTATION_KEY /* @min:instrumentationKey */] = UNDEFINED_VALUE,
    _a.extensionConfig = {},
    _a);
function _chkDiagLevel(value) {
    // Make sure we have a value > 0
    return value && value > 0;
}
/**
 * @export
 * @class ApplicationInsights
 */
var ApplicationInsights = /** @class */ (function () {
    /**
     * Creates an instance of ApplicationInsights.
     * @param config
     * @memberof ApplicationInsights
     */
    function ApplicationInsights(config) {
        var core = new AppInsightsCore();
        var _config;
        // initialize the queue and config in case they are undefined
        if (isNullOrUndefined(config) ||
            (isNullOrUndefined(config[_DYN_INSTRUMENTATION_KEY /* @min:%2einstrumentationKey */]) && isNullOrUndefined(config[_DYN_CONNECTION_STRING /* @min:%2econnectionString */]))) {
            throwError("Invalid input configuration");
        }
        dynamicProto(ApplicationInsights, this, function (_self) {
            // Define _self.config
            objDefine(_self, "config", {
                g: function () { return _config; }
            });
            _initialize();
            _self.initialize = _initialize;
            _self.track = _track;
            proxyFunctions(_self, core, [
                "flush",
                "pollInternalLogs",
                "stopPollingInternalLogs",
                "unload",
                "getPlugin",
                "addPlugin",
                "evtNamespace",
                "addUnloadCb",
                "onCfgChange",
                "getTraceCtx",
                "updateCfg",
                "addTelemetryInitializer"
            ]);
            function _initialize() {
                var cfgHandler = createDynamicConfig(config || {}, defaultConfigValues);
                _config = cfgHandler.cfg;
                core.addUnloadHook(onConfigChange(cfgHandler, function () {
                    var configCs = _config[_DYN_CONNECTION_STRING /* @min:%2econnectionString */];
                    if (isPromiseLike(configCs)) {
                        var ikeyPromise = createSyncPromise(function (resolve, reject) {
                            doAwaitResponse(configCs, function (res) {
                                var curCs = res.value;
                                var ikey = _config[_DYN_INSTRUMENTATION_KEY /* @min:%2einstrumentationKey */];
                                if (!res.rejected && curCs) {
                                    // replace cs with resolved values in case of circular promises
                                    _config[_DYN_CONNECTION_STRING /* @min:%2econnectionString */] = curCs;
                                    var resolvedCs = parseConnectionString(curCs);
                                    ikey = resolvedCs[_DYN_INSTRUMENTATIONKEY0 /* @min:%2einstrumentationkey */] || ikey;
                                }
                                resolve(ikey);
                            });
                        });
                        var urlPromise = createSyncPromise(function (resolve, reject) {
                            doAwaitResponse(configCs, function (res) {
                                var curCs = res.value;
                                var url = _config[_DYN_ENDPOINT_URL /* @min:%2eendpointUrl */];
                                if (!res.rejected && curCs) {
                                    var resolvedCs = parseConnectionString(curCs);
                                    var ingest = resolvedCs[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */];
                                    url = ingest ? ingest + DEFAULT_BREEZE_PATH : url;
                                }
                                resolve(url);
                            });
                        });
                        _config[_DYN_INSTRUMENTATION_KEY /* @min:%2einstrumentationKey */] = ikeyPromise;
                        _config[_DYN_ENDPOINT_URL /* @min:%2eendpointUrl */] = _config[_DYN_USER_OVERRIDE_ENDPOI1 /* @min:%2euserOverrideEndpointUrl */] || urlPromise;
                    }
                    if (isString(configCs)) {
                        var cs = parseConnectionString(configCs);
                        var ingest = cs[_DYN_INGESTIONENDPOINT /* @min:%2eingestionendpoint */];
                        _config[_DYN_ENDPOINT_URL /* @min:%2eendpointUrl */] = _config[_DYN_USER_OVERRIDE_ENDPOI1 /* @min:%2euserOverrideEndpointUrl */] ? _config[_DYN_USER_OVERRIDE_ENDPOI1 /* @min:%2euserOverrideEndpointUrl */] : (ingest + DEFAULT_BREEZE_PATH); // only add /v2/track when from connectionstring
                        _config[_DYN_INSTRUMENTATION_KEY /* @min:%2einstrumentationKey */] = cs[_DYN_INSTRUMENTATIONKEY0 /* @min:%2einstrumentationkey */] || _config[_DYN_INSTRUMENTATION_KEY /* @min:%2einstrumentationKey */];
                    }
                    // userOverrideEndpointUrl have the highest priority
                    _config[_DYN_ENDPOINT_URL /* @min:%2eendpointUrl */] = _config[_DYN_USER_OVERRIDE_ENDPOI1 /* @min:%2euserOverrideEndpointUrl */] ? _config[_DYN_USER_OVERRIDE_ENDPOI1 /* @min:%2euserOverrideEndpointUrl */] : _config[_DYN_ENDPOINT_URL /* @min:%2eendpointUrl */];
                }));
                // initialize core
                core.initialize(_config, [new Sender()]);
            }
        });
        function _track(item) {
            if (item) {
                // to pass sender.processTelemetry()
                item.baseData = item.baseData || {};
                item.baseType = item.baseType || "EventData";
            }
            core.track(item);
        }
    }
// Removed Stub for ApplicationInsights.prototype.initialize.
// Removed Stub for ApplicationInsights.prototype.track.
// Removed Stub for ApplicationInsights.prototype.flush.
// Removed Stub for ApplicationInsights.prototype.pollInternalLogs.
// Removed Stub for ApplicationInsights.prototype.stopPollingInternalLogs.
// Removed Stub for ApplicationInsights.prototype.unload.
// Removed Stub for ApplicationInsights.prototype.getPlugin.
// Removed Stub for ApplicationInsights.prototype.addPlugin.
// Removed Stub for ApplicationInsights.prototype.evtNamespace.
// Removed Stub for ApplicationInsights.prototype.addUnloadCb.
// Removed Stub for ApplicationInsights.prototype.getTraceCtx.
// Removed Stub for ApplicationInsights.prototype.addTelemetryInitializer.
// Removed Stub for ApplicationInsights.prototype.updateCfg.
// Removed Stub for ApplicationInsights.prototype.onCfgChange.
    // This is a workaround for an IE bug when using dynamicProto() with classes that don't have any
    // non-dynamic functions or static properties/functions when using uglify-js to minify the resulting code.
    ApplicationInsights.__ieDyn=1;

    return ApplicationInsights;
}());
export { ApplicationInsights };
export { AppInsightsCore, arrForEach, isNullOrUndefined, throwError, proxyFunctions } from "@microsoft/applicationinsights-core-js";
export { SeverityLevel } from "@microsoft/applicationinsights-common";
export { Sender } from "@microsoft/applicationinsights-channel-js";
//# sourceMappingURL=index.js.map