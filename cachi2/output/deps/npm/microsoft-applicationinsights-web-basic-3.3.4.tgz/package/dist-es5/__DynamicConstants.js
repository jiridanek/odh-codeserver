/*
 * Application Insights JavaScript Web SDK - Basic, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// @skip-file-minify
// ##############################################################
// AUTO GENERATED FILE: This file is Auto Generated during build.
// ##############################################################
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var _DYN_INSTRUMENTATION_KEY = "instrumentationKey"; // Count: 6
export var _DYN_CONNECTION_STRING = "connectionString"; // Count: 4
export var _DYN_INSTRUMENTATIONKEY0 = "instrumentationkey"; // Count: 2
export var _DYN_ENDPOINT_URL = "endpointUrl"; // Count: 6
export var _DYN_INGESTIONENDPOINT = "ingestionendpoint"; // Count: 2
export var _DYN_USER_OVERRIDE_ENDPOI1 = "userOverrideEndpointUrl"; // Count: 5
//# sourceMappingURL=__DynamicConstants.js.map