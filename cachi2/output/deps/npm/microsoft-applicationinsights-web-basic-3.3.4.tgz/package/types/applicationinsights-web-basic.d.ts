/*
 * Microsoft.ApplicationInsights, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 *
 * Microsoft Application Insights Team
 * https://github.com/microsoft/ApplicationInsights-JS#readme
 *
 * ---------------------------------------------------------------------------
 * This is a single combined (rollup) declaration file for the package,
 * if you require a namespace wrapped version it is also available.
 * - Namespaced version: types/applicationinsights-web-basic.namespaced.d.ts
 * ---------------------------------------------------------------------------
 */

import { AppInsightsCore } from '@microsoft/applicationinsights-core-js';
import { arrForEach } from '@microsoft/applicationinsights-core-js';
import { _eInternalMessageId } from '@microsoft/applicationinsights-core-js';
import { eSeverityLevel } from '@microsoft/applicationinsights-common';
import { IAppInsightsCore } from '@microsoft/applicationinsights-core-js';
import { IAutoExceptionTelemetry } from '@microsoft/applicationinsights-common';
import { IConfig } from '@microsoft/applicationinsights-common';
import { IConfiguration } from '@microsoft/applicationinsights-core-js';
import { IDependencyTelemetry } from '@microsoft/applicationinsights-common';
import { IDistributedTraceContext } from '@microsoft/applicationinsights-core-js';
import { IEventTelemetry } from '@microsoft/applicationinsights-common';
import { ILoadedPlugin } from '@microsoft/applicationinsights-core-js';
import { IMetricTelemetry } from '@microsoft/applicationinsights-common';
import { IPageViewPerformanceTelemetry } from '@microsoft/applicationinsights-common';
import { IPageViewTelemetry } from '@microsoft/applicationinsights-common';
import { IPlugin } from '@microsoft/applicationinsights-core-js';
import { IPromise } from '@nevware21/ts-async';
import { ISenderConfig } from '@microsoft/applicationinsights-channel-js';
import { isNullOrUndefined } from '@microsoft/applicationinsights-core-js';
import { ITelemetryInitializerHandler } from '@microsoft/applicationinsights-core-js';
import { ITelemetryItem } from '@microsoft/applicationinsights-core-js';
import { ITelemetryPlugin } from '@microsoft/applicationinsights-core-js';
import { ITelemetryUnloadState } from '@microsoft/applicationinsights-core-js';
import { ITraceTelemetry } from '@microsoft/applicationinsights-common';
import { IUnloadHook } from '@microsoft/applicationinsights-core-js';
import { proxyFunctions } from '@microsoft/applicationinsights-core-js';
import { Sender } from '@microsoft/applicationinsights-channel-js';
import { SendRequestReason } from '@microsoft/applicationinsights-core-js';
import { SeverityLevel } from '@microsoft/applicationinsights-common';
import { throwError } from '@microsoft/applicationinsights-core-js';
import { UnloadHandler } from '@microsoft/applicationinsights-core-js';
import { WatcherFunction } from '@microsoft/applicationinsights-core-js';

export { AppInsightsCore }

/**
 * @export
 * @class ApplicationInsights
 */
export declare class ApplicationInsights {
    readonly config: IConfiguration & IConfig;
    /**
     * Creates an instance of ApplicationInsights.
     * @param config
     * @memberof ApplicationInsights
     */
    constructor(config: IConfiguration & IConfig);
    /**
     * Initialize this instance of ApplicationInsights
     *
     * @memberof ApplicationInsights
     */
    initialize(): void;
    /**
     * Send a manually constructed custom event
     *
     * @param item
     * @memberof ApplicationInsights
     */
    track(item: ITelemetryItem): void;
    /**
     * Immediately send all batched telemetry
     * @param [async=true]
     * @memberof ApplicationInsights
     */
    flush(async?: boolean): void;
    pollInternalLogs(): void;
    stopPollingInternalLogs(): void;
    /**
     * Unload and Tear down the SDK and any initialized plugins, after calling this the SDK will be considered
     * to be un-initialized and non-operational, re-initializing the SDK should only be attempted if the previous
     * unload call return `true` stating that all plugins reported that they also unloaded, the recommended
     * approach is to create a new instance and initialize that instance.
     * This is due to possible unexpected side effects caused by plugins not supporting unload / teardown, unable
     * to successfully remove any global references or they may just be completing the unload process asynchronously.
     * @param isAsync - Can the unload be performed asynchronously (default)
     * @param unloadComplete - An optional callback that will be called once the unload has completed
     * @param cbTimeout - An optional timeout to wait for any flush operations to complete before proceeding with the
     * unload. Defaults to 5 seconds.
     * @return Nothing or if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
     * which will be resolved once the unload is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
     * will only be returned when no callback is provided and isAsync is true
     */
    unload(isAsync?: boolean, unloadComplete?: (unloadState: ITelemetryUnloadState) => void, cbTimeout?: number): void | IPromise<ITelemetryUnloadState>;
    /**
     * Find and return the (first) plugin with the specified identifier if present
     * @param pluginIdentifier
     */
    getPlugin<T extends IPlugin = IPlugin>(pluginIdentifier: string): ILoadedPlugin<T>;
    /**
     * Add a new plugin to the installation
     * @param plugin - The new plugin to add
     * @param replaceExisting - should any existing plugin be replaced
     * @param doAsync - Should the add be performed asynchronously
     */
    addPlugin<T extends IPlugin = ITelemetryPlugin>(plugin: T, replaceExisting: boolean, doAsync: boolean, addCb?: (added?: boolean) => void): void;
    /**
     * Returns the unique event namespace that should be used
     */
    evtNamespace(): string;
    /**
     * Add an unload handler that will be called when the SDK is being unloaded
     * @param handler - the handler
     */
    addUnloadCb(handler: UnloadHandler): void;
    /**
     * Gets the current distributed trace context for this instance if available
     */
    getTraceCtx(): IDistributedTraceContext | null | undefined;
    addTelemetryInitializer(telemetryInitializer: (item: ITelemetryItem) => boolean | void): ITelemetryInitializerHandler;
    /**
     * Update the configuration used and broadcast the changes to all loaded plugins
     * @param newConfig - The new configuration is apply
     * @param mergeExisting - Should the new configuration merge with the existing or just replace it. Default is to merge.
     */
    updateCfg<T extends IConfiguration = IConfiguration>(newConfig: T, mergeExisting?: boolean): void;
    /**
     * Watches and tracks changes for accesses to the current config, and if the accessed config changes the
     * handler will be recalled.
     * @param handler
     * @returns A watcher handler instance that can be used to remove itself when being unloaded
     */
    onCfgChange(handler: WatcherFunction<IConfiguration>): IUnloadHook;
}

export { arrForEach }

export { _eInternalMessageId }

export { eSeverityLevel }

export { IAppInsightsCore }

export { IAutoExceptionTelemetry }

export { IConfiguration }

export { IDependencyTelemetry }

export { IEventTelemetry }

export { ILoadedPlugin }

export { IMetricTelemetry }

export { IPageViewPerformanceTelemetry }

export { IPageViewTelemetry }

export { IPlugin }

export { ISenderConfig }

export { isNullOrUndefined }

export { ITelemetryItem }

export { ITelemetryPlugin }

export { ITraceTelemetry }

export { proxyFunctions }

export { Sender }

export { SendRequestReason }

export { SeverityLevel }

export { throwError }

export { }
