/*
 * Microsoft.ApplicationInsights, 3.3.4
 * Copyright (c) Microsoft and contributors. All rights reserved.
 *
 * Microsoft Application Insights Team
 * https://github.com/microsoft/ApplicationInsights-JS#readme
 */

declare namespace ApplicationInsights {
    /**
     * @group Classes
     * @group Entrypoint
     */
    class AppInsightsCore<CfgType extends IConfiguration = IConfiguration> implements IAppInsightsCore<CfgType> {
        config: CfgType;
        logger: IDiagnosticLogger;
        /**
         * An array of the installed plugins that provide a version
         */
        readonly pluginVersionStringArr: string[];
        /**
         * The formatted string of the installed plugins that contain a version number
         */
        readonly pluginVersionString: string;
        /**
         * Returns a value that indicates whether the instance has already been previously initialized.
         */
        isInitialized: () => boolean;
        /**
         * Function used to identify the get w parameter used to identify status bit to some channels
         */
        getWParam: () => number;
        constructor();
        initialize(config: CfgType, extensions: IPlugin[], logger?: IDiagnosticLogger, notificationManager?: INotificationManager): void;
        getChannels(): IChannelControls[];
        track(telemetryItem: ITelemetryItem): void;
        getProcessTelContext(): IProcessTelemetryContext;
        getNotifyMgr(): INotificationManager;
        /**
         * Adds a notification listener. The SDK calls methods on the listener when an appropriate notification is raised.
         * The added plugins must raise notifications. If the plugins do not implement the notifications, then no methods will be
         * called.
         * @param listener - An INotificationListener object.
         */
        addNotificationListener(listener: INotificationListener): void;
        /**
         * Removes all instances of the listener.
         * @param listener - INotificationListener to remove.
         */
        removeNotificationListener(listener: INotificationListener): void;
        /**
         * Get the current cookie manager for this instance
         */
        getCookieMgr(): ICookieMgr;
        /**
         * Set the current cookie manager for this instance
         * @param cookieMgr - The manager, if set to null/undefined will cause the default to be created
         */
        setCookieMgr(cookieMgr: ICookieMgr): void;
        getPerfMgr(): IPerfManager;
        setPerfMgr(perfMgr: IPerfManager): void;
        eventCnt(): number;
        /**
         * Enable the timer that checks the logger.queue for log messages to be flushed.
         * Note: Since 3.0.1 and 2.8.13 this is no longer an interval timer but is a normal
         * timer that is only started when this function is called and then subsequently
         * only _if_ there are any logger.queue messages to be sent.
         */
        pollInternalLogs(eventName?: string): ITimerHandler;
        /**
         * Stop the timer that log messages from logger.queue when available
         */
        stopPollingInternalLogs(): void;
        /**
         * Add a telemetry processor to decorate or drop telemetry events.
         * @param telemetryInitializer - The Telemetry Initializer function
         * @returns - A ITelemetryInitializerHandler to enable the initializer to be removed
         */
        addTelemetryInitializer(telemetryInitializer: TelemetryInitializerFunction): ITelemetryInitializerHandler;
        /**
         * Unload and Tear down the SDK and any initialized plugins, after calling this the SDK will be considered
         * to be un-initialized and non-operational, re-initializing the SDK should only be attempted if the previous
         * unload call return `true` stating that all plugins reported that they also unloaded, the recommended
         * approach is to create a new instance and initialize that instance.
         * This is due to possible unexpected side effects caused by plugins not supporting unload / teardown, unable
         * to successfully remove any global references or they may just be completing the unload process asynchronously.
         * If you pass isAsync as `true` (also the default) and DO NOT pass a callback function then an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will be returned which will resolve once the unload is complete. The actual implementation of the `IPromise`
         * will be a native Promise (if supported) or the default as supplied by [ts-async library](https://github.com/nevware21/ts-async)
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @param unloadComplete - An optional callback that will be called once the unload has completed
         * @param cbTimeout - An optional timeout to wait for any flush operations to complete before proceeding with the
         * unload. Defaults to 5 seconds.
         * @return Nothing or if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * which will be resolved once the unload is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will only be returned when no callback is provided and isAsync is true
         */
        unload(isAsync?: boolean, unloadComplete?: (unloadState: ITelemetryUnloadState) => void, cbTimeout?: number): void | IPromise<ITelemetryUnloadState>;
        getPlugin<T extends IPlugin = IPlugin>(pluginIdentifier: string): ILoadedPlugin<T>;
        /**
         * Add a new plugin to the installation
         * @param plugin - The new plugin to add
         * @param replaceExisting - should any existing plugin be replaced, default is false
         * @param doAsync - Should the add be performed asynchronously
         * @param addCb - [Optional] callback to call after the plugin has been added
         */
        addPlugin<T extends IPlugin = ITelemetryPlugin>(plugin: T, replaceExisting?: boolean, doAsync?: boolean, addCb?: (added?: boolean) => void): void;
        /**
         * Update the configuration used and broadcast the changes to all loaded plugins
         * @param newConfig - The new configuration is apply
         * @param mergeExisting - Should the new configuration merge with the existing or just replace it. Default is to true.
         */
        updateCfg(newConfig: CfgType, mergeExisting?: boolean): void;
        /**
         * Returns the unique event namespace that should be used
         */
        evtNamespace(): string;
        /**
         * Add an unload handler that will be called when the SDK is being unloaded
         * @param handler - the handler
         */
        addUnloadCb(handler: UnloadHandler): void;
        /**
         * Flush and send any batched / cached data immediately
         * @param async - send data asynchronously when true (defaults to true)
         * @param callBack - if specified, notify caller when send is complete, the channel should return true to indicate to the caller that it will be called.
         * If the caller doesn't return true the caller should assume that it may never be called.
         * @param sendReason - specify the reason that you are calling "flush" defaults to ManualFlush (1) if not specified
         * @returns - true if the callback will be return after the flush is complete otherwise the caller should assume that any provided callback will never be called
         */
        flush(isAsync?: boolean, callBack?: (flushComplete?: boolean) => void, sendReason?: SendRequestReason): void;
        /**
         * Gets the current distributed trace context for this instance if available
         * @param createNew - Optional flag to create a new instance if one doesn't currently exist, defaults to true
         */
        getTraceCtx(createNew?: boolean): IDistributedTraceContext | null;
        /**
         * Sets the current distributed trace context for this instance if available
         */
        setTraceCtx(newTracectx: IDistributedTraceContext): void;
        /**
         * Add this hook so that it is automatically removed during unloading
         * @param hooks - The single hook or an array of IInstrumentHook objects
         */
        addUnloadHook(hooks: IUnloadHook | IUnloadHook[] | Iterator<IUnloadHook> | ILegacyUnloadHook | ILegacyUnloadHook[] | Iterator<ILegacyUnloadHook>): void;
        /**
         * Watches and tracks changes for accesses to the current config, and if the accessed config changes the
         * handler will be recalled.
         * @param handler
         * @returns A watcher handler instance that can be used to remove itself when being unloaded
         */
        onCfgChange(handler: WatcherFunction<CfgType>): IUnloadHook;
        /**
         * Watches and tracks status of initialization process
         * @returns ActiveStatus
         * @since 3.3.0
         * If returned status is active, it means initialization process is completed.
         * If returned status is pending, it means the initialization process is waiting for promieses to be resolved.
         * If returned status is inactive, it means ikey is invalid or can 't get ikey or enpoint url from promsises.
         */
        activeStatus(): eActiveStatus | number;
        /**
         * Set Active Status to pending, which will block the incoming changes until internal promises are resolved
         * @internal Internal use
         * @since 3.3.0
         */
        _setPendingStatus(): void;
        protected releaseQueue(): void;
        /**
         * Hook for Core extensions to allow them to update their own configuration before updating all of the plugins.
         * @param updateCtx - The plugin update context
         * @param updateState - The Update State
         * @returns boolean - True means the extension class will call updateState otherwise the Core will
         */
        protected _updateHook?(updateCtx: IProcessTelemetryUpdateContext, updateState: ITelemetryUpdateState): void | boolean;
    }

    /**
     * @export
     * @class ApplicationInsights
     */
    class ApplicationInsights {
        readonly config: IConfiguration & IConfig;
        /**
         * Creates an instance of ApplicationInsights.
         * @param config
         * @memberof ApplicationInsights
         */
        constructor(config: IConfiguration & IConfig);
        /**
         * Initialize this instance of ApplicationInsights
         *
         * @memberof ApplicationInsights
         */
        initialize(): void;
        /**
         * Send a manually constructed custom event
         *
         * @param item
         * @memberof ApplicationInsights
         */
        track(item: ITelemetryItem): void;
        /**
         * Immediately send all batched telemetry
         * @param [async=true]
         * @memberof ApplicationInsights
         */
        flush(async?: boolean): void;
        pollInternalLogs(): void;
        stopPollingInternalLogs(): void;
        /**
         * Unload and Tear down the SDK and any initialized plugins, after calling this the SDK will be considered
         * to be un-initialized and non-operational, re-initializing the SDK should only be attempted if the previous
         * unload call return `true` stating that all plugins reported that they also unloaded, the recommended
         * approach is to create a new instance and initialize that instance.
         * This is due to possible unexpected side effects caused by plugins not supporting unload / teardown, unable
         * to successfully remove any global references or they may just be completing the unload process asynchronously.
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @param unloadComplete - An optional callback that will be called once the unload has completed
         * @param cbTimeout - An optional timeout to wait for any flush operations to complete before proceeding with the
         * unload. Defaults to 5 seconds.
         * @return Nothing or if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * which will be resolved once the unload is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will only be returned when no callback is provided and isAsync is true
         */
        unload(isAsync?: boolean, unloadComplete?: (unloadState: ITelemetryUnloadState) => void, cbTimeout?: number): void | IPromise<ITelemetryUnloadState>;
        /**
         * Find and return the (first) plugin with the specified identifier if present
         * @param pluginIdentifier
         */
        getPlugin<T extends IPlugin = IPlugin>(pluginIdentifier: string): ILoadedPlugin<T>;
        /**
         * Add a new plugin to the installation
         * @param plugin - The new plugin to add
         * @param replaceExisting - should any existing plugin be replaced
         * @param doAsync - Should the add be performed asynchronously
         */
        addPlugin<T extends IPlugin = ITelemetryPlugin>(plugin: T, replaceExisting: boolean, doAsync: boolean, addCb?: (added?: boolean) => void): void;
        /**
         * Returns the unique event namespace that should be used
         */
        evtNamespace(): string;
        /**
         * Add an unload handler that will be called when the SDK is being unloaded
         * @param handler - the handler
         */
        addUnloadCb(handler: UnloadHandler): void;
        /**
         * Gets the current distributed trace context for this instance if available
         */
        getTraceCtx(): IDistributedTraceContext | null | undefined;
        addTelemetryInitializer(telemetryInitializer: (item: ITelemetryItem) => boolean | void): ITelemetryInitializerHandler;
        /**
         * Update the configuration used and broadcast the changes to all loaded plugins
         * @param newConfig - The new configuration is apply
         * @param mergeExisting - Should the new configuration merge with the existing or just replace it. Default is to merge.
         */
        updateCfg<T extends IConfiguration = IConfiguration>(newConfig: T, mergeExisting?: boolean): void;
        /**
         * Watches and tracks changes for accesses to the current config, and if the accessed config changes the
         * handler will be recalled.
         * @param handler
         * @returns A watcher handler instance that can be used to remove itself when being unloaded
         */
        onCfgChange(handler: WatcherFunction<IConfiguration>): IUnloadHook;
    }

    class ArraySendBuffer extends BaseSendBuffer implements ISendBuffer {
        constructor(logger: IDiagnosticLogger, config: ISenderConfig);
        markAsSent(payload: IInternalStorageItem[]): void;
        clearSent(payload: IInternalStorageItem[]): void;
    }

    /**
     * Calls the provided `callbackFn` function once for each element in an array in ascending index order. It is not invoked for index properties
     * that have been deleted or are uninitialized. And unlike the ES6 forEach() you CAN stop or break the iteration by returning -1 from the
     * `callbackFn` function.
     *
     * The range (number of elements) processed by arrForEach() is set before the first call to the `callbackFn`. Any elements added beyond the range
     * or elements which as assigned to indexes already processed will not be visited by the `callbackFn`.
     * @group Array
     * @group ArrayLike
     * @typeParam T - Identifies the element type of the array
     * @param theArray - The array or array like object of elements to be searched.
     * @param callbackfn A `synchronous` function that accepts up to three arguments. arrForEach calls the callbackfn function one time for each element in the array.
     * @param thisArg An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, null or undefined
     * the array will be used as the this value.
     * @remarks
     * arrForEach expects a `synchronous` function.
     * arrForEach does not wait for promises. Make sure you are aware of the implications while using promises (or async functions) as forEach callback.
     * @example
     * ```ts
     * const items = ['item1', 'item2', 'item3'];
     * const copyItems = [];
     *
     * // before using for loop
     * for (let i = 0; i < items.length; i++) {
     *   copyItems.push(items[i]);
     * }
     *
     * // before using forEach()
     * items.forEach((item) => {
     *   copyItems.push(item);
     * });
     *
     * // after
     * arrForEach(items, (item) => {
     *   copyItems.push(item);
     *   // May return -1 to abort the iteration
     * });
     *
     * // Also supports input as an array like object
     * const items = { length: 3, 0: 'item1', 1: 'item2', 2: 'item3' };
     * ```
     */
    function arrForEach<T = any>(theArray: ArrayLike<T>, callbackfn: (value: T, index: number, array: T[]) => void | number, thisArg?: any): void;

    abstract class BaseSendBuffer {
        protected _get: () => IInternalStorageItem[];
        protected _set: (buffer: IInternalStorageItem[]) => IInternalStorageItem[];
        constructor(logger: IDiagnosticLogger, config: ISenderConfig);
        enqueue(payload: IInternalStorageItem): void;
        count(): number;
        size(): number;
        clear(): void;
        getItems(): IInternalStorageItem[];
        batchPayloads(payload: IInternalStorageItem[]): string;
        createNew(newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean): ArraySendBuffer | SessionStorageSendBuffer;
    }

    /**
     * BaseTelemetryPlugin provides a basic implementation of the ITelemetryPlugin interface so that plugins
     * can avoid implementation the same set of boiler plate code as well as provide a base
     * implementation so that new default implementations can be added without breaking all plugins.
     */
    abstract class BaseTelemetryPlugin implements ITelemetryPlugin {
        identifier: string;
        version?: string;
        /**
         * Holds the core instance that was used during initialization
         */
        core: IAppInsightsCore;
        priority: number;
        /**
         * Call back for telemetry processing before it it is sent
         * @param env - This is the current event being reported
         * @param itemCtx - This is the context for the current request, ITelemetryPlugin instances
         * can optionally use this to access the current core instance or define / pass additional information
         * to later plugins (vs appending items to the telemetry item)
         */
        processNext: (env: ITelemetryItem, itemCtx: IProcessTelemetryContext) => void;
        /**
         * Set next extension for telemetry processing
         */
        setNextPlugin: (next: ITelemetryPlugin | ITelemetryPluginChain) => void;
        /**
         * Returns the current diagnostic logger that can be used to log issues, if no logger is currently
         * assigned a new default one will be created and returned.
         */
        diagLog: (itemCtx?: IProcessTelemetryContext) => IDiagnosticLogger;
        /**
         * Returns whether the plugin has been initialized
         */
        isInitialized: () => boolean;
        /**
         * Helper to return the current IProcessTelemetryContext, if the passed argument exists this just
         * returns that value (helps with minification for callers), otherwise it will return the configured
         * context or a temporary one.
         * @param currentCtx - [Optional] The current execution context
         */
        protected _getTelCtx: (currentCtx?: IProcessTelemetryContext) => IProcessTelemetryContext;
        /**
         * Internal helper to allow setting of the internal initialized setting for inherited instances and unit testing
         */
        protected setInitialized: (isInitialized: boolean) => void;
        /**
         * Teardown / Unload hook to allow implementations to perform some additional unload operations before the BaseTelemetryPlugin
         * finishes it's removal.
         * @param unloadCtx - This is the context that should be used during unloading.
         * @param unloadState - The details / state of the unload process, it holds details like whether it should be unloaded synchronously or asynchronously and the reason for the unload.
         * @param asyncCallback - An optional callback that the plugin must call if it returns true to inform the caller that it has completed any async unload/teardown operations.
         * @returns boolean - true if the plugin has or will call asyncCallback, this allows the plugin to perform any asynchronous operations.
         */
        protected _doTeardown?: (unloadCtx?: IProcessTelemetryUnloadContext, unloadState?: ITelemetryUnloadState, asyncCallback?: () => void) => void | boolean;
        /**
         * Extension hook to allow implementations to perform some additional update operations before the BaseTelemetryPlugin finishes it's removal
         * @param updateCtx - This is the context that should be used during updating.
         * @param updateState - The details / state of the update process, it holds details like the current and previous configuration.
         * @param asyncCallback - An optional callback that the plugin must call if it returns true to inform the caller that it has completed any async update operations.
         * @returns boolean - true if the plugin has or will call asyncCallback, this allows the plugin to perform any asynchronous operations.
         */
        protected _doUpdate?: (updateCtx?: IProcessTelemetryUpdateContext, updateState?: ITelemetryUpdateState, asyncCallback?: () => void) => void | boolean;
        /**
         * Exposes the underlying unload hook container instance for this extension to allow it to be passed down to any sub components of the class.
         * This should NEVER be exposed or called publically as it's scope is for internal use by BaseTelemetryPlugin and any derived class (which is why
         * it's scoped as protected)
         */
        protected readonly _unloadHooks: IUnloadHookContainer;
        constructor();
        initialize(config: IConfiguration, core: IAppInsightsCore, extensions: IPlugin[], pluginChain?: ITelemetryPluginChain): void;
        /**
         * Tear down the plugin and remove any hooked value, the plugin should be removed so that it is no longer initialized and
         * therefore could be re-initialized after being torn down. The plugin should ensure that once this has been called any further
         * processTelemetry calls are ignored and it just calls the processNext() with the provided context.
         * @param unloadCtx - This is the context that should be used during unloading.
         * @param unloadState - The details / state of the unload process, it holds details like whether it should be unloaded synchronously or asynchronously and the reason for the unload.
         * @returns boolean - true if the plugin has or will call processNext(), this for backward compatibility as previously teardown was synchronous and returned nothing.
         */
        teardown(unloadCtx?: IProcessTelemetryUnloadContext, unloadState?: ITelemetryUnloadState): void | boolean;
        abstract processTelemetry(env: ITelemetryItem, itemCtx?: IProcessTelemetryContext): void;
        /**
         * The the plugin should re-evaluate configuration and update any cached configuration settings.
         * @param updateCtx - This is the context that should be used during updating.
         * @param updateState - The details / state of the update process, it holds details like the current and previous configuration.
         * @returns boolean - true if the plugin has or will call updateCtx.processNext(), this allows the plugin to perform any asynchronous operations.
         */
        update(updateCtx: IProcessTelemetryUpdateContext, updateState: ITelemetryUpdateState): void | boolean;
        /**
         * Add an unload handler that will be called when the SDK is being unloaded
         * @param handler - the handler
         */
        protected _addUnloadCb(handler: UnloadHandler): void;
        /**
         * Add this hook so that it is automatically removed during unloading
         * @param hooks - The single hook or an array of IInstrumentHook objects
         */
        protected _addHook(hooks: IUnloadHook | IUnloadHook[] | Iterator<IUnloadHook> | ILegacyUnloadHook | ILegacyUnloadHook[] | Iterator<ILegacyUnloadHook>): void;
    }

    const DistributedTracingModes: EnumValue<typeof eDistributedTracingModes>;

    type DistributedTracingModes = number | eDistributedTracingModes;

    const enum eActiveStatus {
        NONE = 0,
        /**
         * inactive status means there might be rejected ikey/endpoint promises or ikey/endpoint resolved is not valid
         */
        INACTIVE = 1,
        /**
         * active mean ikey/endpoint promises is resolved and initializing with ikey/endpoint is successful
         */
        ACTIVE = 2,
        /**
         * Waiting for promises to be resolved
         * NOTE: if status is set to be pending, incoming changes will be dropped until pending status is removed
         */
        PENDING = 3
    }

    const enum eDistributedTracingModes {
        /**
         * (Default) Send Application Insights correlation headers
         */
        AI = 0,
        /**
         * Send both W3C Trace Context headers and back-compatibility Application Insights headers
         */
        AI_AND_W3C = 1,
        /**
         * Send W3C Trace Context headers
         */
        W3C = 2
    }

    const enum _eInternalMessageId {
        BrowserDoesNotSupportLocalStorage = 0,
        BrowserCannotReadLocalStorage = 1,
        BrowserCannotReadSessionStorage = 2,
        BrowserCannotWriteLocalStorage = 3,
        BrowserCannotWriteSessionStorage = 4,
        BrowserFailedRemovalFromLocalStorage = 5,
        BrowserFailedRemovalFromSessionStorage = 6,
        CannotSendEmptyTelemetry = 7,
        ClientPerformanceMathError = 8,
        ErrorParsingAISessionCookie = 9,
        ErrorPVCalc = 10,
        ExceptionWhileLoggingError = 11,
        FailedAddingTelemetryToBuffer = 12,
        FailedMonitorAjaxAbort = 13,
        FailedMonitorAjaxDur = 14,
        FailedMonitorAjaxOpen = 15,
        FailedMonitorAjaxRSC = 16,
        FailedMonitorAjaxSend = 17,
        FailedMonitorAjaxGetCorrelationHeader = 18,
        FailedToAddHandlerForOnBeforeUnload = 19,
        FailedToSendQueuedTelemetry = 20,
        FailedToReportDataLoss = 21,
        FlushFailed = 22,
        MessageLimitPerPVExceeded = 23,
        MissingRequiredFieldSpecification = 24,
        NavigationTimingNotSupported = 25,
        OnError = 26,
        SessionRenewalDateIsZero = 27,
        SenderNotInitialized = 28,
        StartTrackEventFailed = 29,
        StopTrackEventFailed = 30,
        StartTrackFailed = 31,
        StopTrackFailed = 32,
        TelemetrySampledAndNotSent = 33,
        TrackEventFailed = 34,
        TrackExceptionFailed = 35,
        TrackMetricFailed = 36,
        TrackPVFailed = 37,
        TrackPVFailedCalc = 38,
        TrackTraceFailed = 39,
        TransmissionFailed = 40,
        FailedToSetStorageBuffer = 41,
        FailedToRestoreStorageBuffer = 42,
        InvalidBackendResponse = 43,
        FailedToFixDepricatedValues = 44,
        InvalidDurationValue = 45,
        TelemetryEnvelopeInvalid = 46,
        CreateEnvelopeError = 47,
        MaxUnloadHookExceeded = 48,
        CannotSerializeObject = 48,
        CannotSerializeObjectNonSerializable = 49,
        CircularReferenceDetected = 50,
        ClearAuthContextFailed = 51,
        ExceptionTruncated = 52,
        IllegalCharsInName = 53,
        ItemNotInArray = 54,
        MaxAjaxPerPVExceeded = 55,
        MessageTruncated = 56,
        NameTooLong = 57,
        SampleRateOutOfRange = 58,
        SetAuthContextFailed = 59,
        SetAuthContextFailedAccountName = 60,
        StringValueTooLong = 61,
        StartCalledMoreThanOnce = 62,
        StopCalledWithoutStart = 63,
        TelemetryInitializerFailed = 64,
        TrackArgumentsNotSpecified = 65,
        UrlTooLong = 66,
        SessionStorageBufferFull = 67,
        CannotAccessCookie = 68,
        IdTooLong = 69,
        InvalidEvent = 70,
        FailedMonitorAjaxSetRequestHeader = 71,
        SendBrowserInfoOnUserInit = 72,
        PluginException = 73,
        NotificationException = 74,
        SnippetScriptLoadFailure = 99,
        InvalidInstrumentationKey = 100,
        CannotParseAiBlobValue = 101,
        InvalidContentBlob = 102,
        TrackPageActionEventFailed = 103,
        FailedAddingCustomDefinedRequestContext = 104,
        InMemoryStorageBufferFull = 105,
        InstrumentationKeyDeprecation = 106,
        ConfigWatcherException = 107,
        DynamicConfigException = 108,
        DefaultThrottleMsgKey = 109,
        CdnDeprecation = 110,
        SdkLdrUpdate = 111,
        InitPromiseException = 112
    }

    const enum eLoggingSeverity {
        /**
         * No Logging will be enabled
         */
        DISABLED = 0,
        /**
         * Error will be sent as internal telemetry
         */
        CRITICAL = 1,
        /**
         * Error will NOT be sent as internal telemetry, and will only be shown in browser console
         */
        WARNING = 2,
        /**
         * The Error will NOT be sent as an internal telemetry, and will only be shown in the browser
         * console if the logging level allows it.
         */
        DEBUG = 3
    }

    /**
     * A type that identifies an enum class generated from a constant enum.
     * @group Enum
     * @typeParam E - The constant enum type
     *
     * Returned from {@link createEnum}
     */
    type EnumCls<E = any> = {
        readonly [key in keyof E extends string | number | symbol ? keyof E : never]: key extends string ? E[key] : key;
    } & {
        readonly [key in keyof E]: E[key];
    };

    type EnumValue<E = any> = EnumCls<E>;

    /**
     * This is the enum for the different network states current ai is experiencing
     */
    const enum eOfflineValue {
        Unknown = 0,
        Online = 1,
        Offline = 2
    }

    /**
     * Defines the level of severity for the event.
     */
    const enum eSeverityLevel {
        Verbose = 0,
        Information = 1,
        Warning = 2,
        Error = 3,
        Critical = 4
    }

    const enum FeatureOptInMode {
        /**
         * not set, completely depends on cdn cfg
         */
        none = 1,
        /**
         * try to not apply config from cdn
         */
        disable = 2,
        /**
         * try to apply config from cdn
         */
        enable = 3
    }

    /**
     * This defines the handler function that is called via the finally when the promise is resolved or rejected
     */
    type FinallyPromiseHandler = (() => void) | undefined | null;

    interface IAppInsightsCore<CfgType extends IConfiguration = IConfiguration> extends IPerfManagerProvider {
        readonly config: CfgType;
        /**
         * The current logger instance for this instance.
         */
        readonly logger: IDiagnosticLogger;
        /**
         * An array of the installed plugins that provide a version
         */
        readonly pluginVersionStringArr: string[];
        /**
         * The formatted string of the installed plugins that contain a version number
         */
        readonly pluginVersionString: string;
        /**
         * Returns a value that indicates whether the instance has already been previously initialized.
         */
        isInitialized?: () => boolean;
        initialize(config: CfgType, extensions: IPlugin[], logger?: IDiagnosticLogger, notificationManager?: INotificationManager): void;
        getChannels(): IChannelControls[];
        track(telemetryItem: ITelemetryItem): void;
        /**
         * Get the current notification manager
         */
        getNotifyMgr(): INotificationManager;
        /**
         * Get the current cookie manager for this instance
         */
        getCookieMgr(): ICookieMgr;
        /**
         * Set the current cookie manager for this instance
         * @param cookieMgr - The manager, if set to null/undefined will cause the default to be created
         */
        setCookieMgr(cookieMgr: ICookieMgr): void;
        /**
         * Adds a notification listener. The SDK calls methods on the listener when an appropriate notification is raised.
         * The added plugins must raise notifications. If the plugins do not implement the notifications, then no methods will be
         * called.
         * @param listener - An INotificationListener object.
         */
        addNotificationListener?(listener: INotificationListener): void;
        /**
         * Removes all instances of the listener.
         * @param listener - INotificationListener to remove.
         */
        removeNotificationListener?(listener: INotificationListener): void;
        /**
         * Add a telemetry processor to decorate or drop telemetry events.
         * @param telemetryInitializer - The Telemetry Initializer function
         * @returns - A ITelemetryInitializerHandler to enable the initializer to be removed
         */
        addTelemetryInitializer(telemetryInitializer: TelemetryInitializerFunction): ITelemetryInitializerHandler;
        pollInternalLogs?(eventName?: string): ITimerHandler;
        stopPollingInternalLogs?(): void;
        /**
         * Return a new instance of the IProcessTelemetryContext for processing events
         */
        getProcessTelContext(): IProcessTelemetryContext;
        /**
         * Unload and Tear down the SDK and any initialized plugins, after calling this the SDK will be considered
         * to be un-initialized and non-operational, re-initializing the SDK should only be attempted if the previous
         * unload call return `true` stating that all plugins reported that they also unloaded, the recommended
         * approach is to create a new instance and initialize that instance.
         * This is due to possible unexpected side effects caused by plugins not supporting unload / teardown, unable
         * to successfully remove any global references or they may just be completing the unload process asynchronously.
         * If you pass isAsync as `true` (also the default) and DO NOT pass a callback function then an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will be returned which will resolve once the unload is complete. The actual implementation of the `IPromise`
         * will be a native Promise (if supported) or the default as supplied by [ts-async library](https://github.com/nevware21/ts-async)
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @param unloadComplete - An optional callback that will be called once the unload has completed
         * @param cbTimeout - An optional timeout to wait for any flush operations to complete before proceeding with the
         * unload. Defaults to 5 seconds.
         * @return Nothing or if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * which will be resolved once the unload is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will only be returned when no callback is provided and isAsync is true
         */
        unload(isAsync?: boolean, unloadComplete?: (unloadState: ITelemetryUnloadState) => void, cbTimeout?: number): void | IPromise<ITelemetryUnloadState>;
        /**
         * Find and return the (first) plugin with the specified identifier if present
         * @param pluginIdentifier
         */
        getPlugin<T extends IPlugin = IPlugin>(pluginIdentifier: string): ILoadedPlugin<T>;
        /**
         * Add a new plugin to the installation
         * @param plugin - The new plugin to add
         * @param replaceExisting - should any existing plugin be replaced, default is false
         * @param doAsync - Should the add be performed asynchronously
         * @param addCb - [Optional] callback to call after the plugin has been added
         */
        addPlugin<T extends IPlugin = ITelemetryPlugin>(plugin: T, replaceExisting?: boolean, doAsync?: boolean, addCb?: (added?: boolean) => void): void;
        /**
         * Update the configuration used and broadcast the changes to all loaded plugins, this does NOT support updating, adding or removing
         * any the plugins (extensions or channels). It will notify each plugin (if supported) that the configuration has changed but it will
         * not remove or add any new plugins, you need to call addPlugin or getPlugin(identifier).remove();
         * @param newConfig - The new configuration is apply
         * @param mergeExisting - Should the new configuration merge with the existing or just replace it. Default is to merge.
         */
        updateCfg(newConfig: CfgType, mergeExisting?: boolean): void;
        /**
         * Returns the unique event namespace that should be used when registering events
         */
        evtNamespace(): string;
        /**
         * Add a handler that will be called when the SDK is being unloaded
         * @param handler - the handler
         */
        addUnloadCb(handler: UnloadHandler): void;
        /**
         * Add this hook so that it is automatically removed during unloading
         * @param hooks - The single hook or an array of IInstrumentHook objects
         */
        addUnloadHook(hooks: IUnloadHook | IUnloadHook[] | Iterator<IUnloadHook> | ILegacyUnloadHook | ILegacyUnloadHook[] | Iterator<ILegacyUnloadHook>): void;
        /**
         * Flush and send any batched / cached data immediately
         * @param async - send data asynchronously when true (defaults to true)
         * @param callBack - if specified, notify caller when send is complete, the channel should return true to indicate to the caller that it will be called.
         * If the caller doesn't return true the caller should assume that it may never be called.
         * @param sendReason - specify the reason that you are calling "flush" defaults to ManualFlush (1) if not specified
         * @param cbTimeout - An optional timeout to wait for any flush operations to complete before proceeding with the unload. Defaults to 5 seconds.
         * @returns - true if the callback will be return after the flush is complete otherwise the caller should assume that any provided callback will never be called
         */
        flush(isAsync?: boolean, callBack?: (flushComplete?: boolean) => void, sendReason?: SendRequestReason, cbTimeout?: number): boolean | void;
        /**
         * Gets the current distributed trace context for this instance if available
         * @param createNew - Optional flag to create a new instance if one doesn't currently exist, defaults to true
         */
        getTraceCtx(createNew?: boolean): IDistributedTraceContext | null;
        /**
         * Sets the current distributed trace context for this instance if available
         */
        setTraceCtx(newTraceCtx: IDistributedTraceContext | null | undefined): void;
        /**
         * Watches and tracks changes for accesses to the current config, and if the accessed config changes the
         * handler will be recalled.
         * @param handler
         * @returns A watcher handler instance that can be used to remove itself when being unloaded
         */
        onCfgChange(handler: WatcherFunction<CfgType>): IUnloadHook;
        /**
         * Function used to identify the get w parameter used to identify status bit to some channels
         */
        getWParam: () => number;
        /**
         * Watches and tracks status of initialization process
         * @returns ActiveStatus
         * @since 3.3.0
         * If returned status is active, it means initialization process is completed.
         * If returned status is pending, it means the initialization process is waiting for promieses to be resolved.
         * If returned status is inactive, it means ikey is invalid or can 't get ikey or enpoint url from promsises.
         */
        activeStatus?: () => eActiveStatus | number;
        /**
         * Set Active Status to pending, which will block the incoming changes until internal promises are resolved
         * @internal Internal use
         * @since 3.3.0
         */
        _setPendingStatus?: () => void;
    }

    /**
     * @description window.onerror function parameters
     * @export
     * @interface IAutoExceptionTelemetry
     */
    interface IAutoExceptionTelemetry {
        /**
         * @description error message. Available as event in HTML onerror="" handler
         * @type {string}
         * @memberof IAutoExceptionTelemetry
         */
        message: string;
        /**
         * @description URL of the script where the error was raised
         * @type {string}
         * @memberof IAutoExceptionTelemetry
         */
        url: string;
        /**
         * @description Line number where error was raised
         * @type {number}
         * @memberof IAutoExceptionTelemetry
         */
        lineNumber: number;
        /**
         * @description Column number for the line where the error occurred
         * @type {number}
         * @memberof IAutoExceptionTelemetry
         */
        columnNumber: number;
        /**
         * @description Error Object (object)
         * @type {any}
         * @memberof IAutoExceptionTelemetry
         */
        error: any;
        /**
         * @description The event at the time of the exception (object)
         * @type {Event|string}
         * @memberof IAutoExceptionTelemetry
         */
        evt?: Event | string;
        /**
         * @description The provided stack for the error
         * @type {IStackDetails}
         * @memberof IAutoExceptionTelemetry
         */
        stackDetails?: IStackDetails;
        /**
         * @description The calculated type of the error
         * @type {string}
         * @memberof IAutoExceptionTelemetry
         */
        typeName?: string;
        /**
         * @description The descriptive source of the error
         * @type {string}
         * @memberof IAutoExceptionTelemetry
         */
        errorSrc?: string;
    }

    interface IBackendResponse {
        /**
         * Number of items received by the backend
         */
        readonly itemsReceived: number;
        /**
         * Number of items succesfuly accepted by the backend
         */
        readonly itemsAccepted: number;
        /**
         * List of errors for items which were not accepted
         */
        readonly errors: IResponseError[];
        /**
         * App id returned by the backend - not necessary returned, but we don't need it with each response.
         */
        readonly appId?: string;
    }

    interface IBaseProcessingContext {
        /**
         * The current core instance for the request
         */
        core: () => IAppInsightsCore;
        /**
         * THe current diagnostic logger for the request
         */
        diagLog: () => IDiagnosticLogger;
        /**
         * Gets the current core config instance
         */
        getCfg: () => IConfiguration;
        /**
         * Gets the named extension config
         */
        getExtCfg: <T>(identifier: string, defaultValue?: IConfigDefaults<T>) => T;
        /**
         * Gets the named config from either the named identifier extension or core config if neither exist then the
         * default value is returned
         * @param identifier - The named extension identifier
         * @param field - The config field name
         * @param defaultValue - The default value to return if no defined config exists
         */
        getConfig: (identifier: string, field: string, defaultValue?: number | string | boolean | string[] | RegExp[] | Function) => number | string | boolean | string[] | RegExp[] | Function;
        /**
         * Helper to allow plugins to check and possibly shortcut executing code only
         * required if there is a nextPlugin
         */
        hasNext: () => boolean;
        /**
         * Returns the next configured plugin proxy
         */
        getNext: () => ITelemetryPluginChain;
        /**
         * Helper to set the next plugin proxy
         */
        setNext: (nextCtx: ITelemetryPluginChain) => void;
        /**
         * Synchronously iterate over the context chain running the callback for each plugin, once
         * every plugin has been executed via the callback, any associated onComplete will be called.
         * @param callback - The function call for each plugin in the context chain
         */
        iterate: <T extends ITelemetryPlugin = ITelemetryPlugin>(callback: (plugin: T) => void) => void;
        /**
         * Set the function to call when the current chain has executed all processNext or unloadNext items.
         * @param onComplete - The onComplete to call
         * @param that - The "this" value to use for the onComplete call, if not provided or undefined defaults to the current context
         * @param args - Any additional arguments to pass to the onComplete function
         */
        onComplete: (onComplete: () => void, that?: any, ...args: any[]) => void;
        /**
         * Create a new context using the core and config from the current instance, returns a new instance of the same type
         * @param plugins - The execution order to process the plugins, if null or not supplied
         *                  then the current execution order will be copied.
         * @param startAt - The plugin to start processing from, if missing from the execution
         *                  order then the next plugin will be NOT set.
         */
        createNew: (plugins?: IPlugin[] | ITelemetryPluginChain, startAt?: IPlugin) => IBaseProcessingContext;
    }

    /**
     * Provides data transmission capabilities
     */
    interface IChannelControls extends ITelemetryPlugin {
        /**
         * Pause sending data
         */
        pause?(): void;
        /**
         * Resume sending data
         */
        resume?(): void;
        /**
         * Tear down the plugin and remove any hooked value, the plugin should be removed so that it is no longer initialized and
         * therefore could be re-initialized after being torn down. The plugin should ensure that once this has been called any further
         * processTelemetry calls are ignored and it just calls the processNext() with the provided context.
         * @param unloadCtx - This is the context that should be used during unloading.
         * @param unloadState - The details / state of the unload process, it holds details like whether it should be unloaded synchronously or asynchronously and the reason for the unload.
         * @returns boolean - true if the plugin has or will call processNext(), this for backward compatibility as previously teardown was synchronous and returned nothing.
         */
        teardown?: (unloadCtx?: IProcessTelemetryUnloadContext, unloadState?: ITelemetryUnloadState) => void | boolean;
        /**
         * Flush to send data immediately; channel should default to sending data asynchronously. If executing asynchronously and
         * you DO NOT pass a callback function then a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will be returned which will resolve once the flush is complete. The actual implementation of the `IPromise`
         * will be a native Promise (if supported) or the default as supplied by [ts-async library](https://github.com/nevware21/ts-async)
         * @param async - send data asynchronously when true
         * @param callBack - if specified, notify caller when send is complete, the channel should return true to indicate to the caller that it will be called.
         * If the caller doesn't return true the caller should assume that it may never be called.
         * @param sendReason - specify the reason that you are calling "flush" defaults to ManualFlush (1) if not specified
         * @returns - If a callback is provided `true` to indicate that callback will be called after the flush is complete otherwise the caller
         * should assume that any provided callback will never be called, Nothing or if occurring asynchronously a
         * [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) which will be resolved once the unload is complete,
         * the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) will only be returned when no callback is provided
         * and async is true.
         */
        flush?(async: boolean, callBack?: (flushComplete?: boolean) => void, sendReason?: SendRequestReason): boolean | void | IPromise<boolean>;
        /**
         * Get offline support
         * @returns IInternalOfflineSupport
         */
        getOfflineSupport?: () => IInternalOfflineSupport;
    }

    /**
     * Configuration settings for how telemetry is sent
     * @export
     * @interface IConfig
     */
    interface IConfig {
        /**
         * The JSON format (normal vs line delimited). True means line delimited JSON.
         */
        emitLineDelimitedJson?: boolean;
        /**
         * An optional account id, if your app groups users into accounts. No spaces, commas, semicolons, equals, or vertical bars.
         */
        accountId?: string;
        /**
         * A session is logged if the user is inactive for this amount of time in milliseconds. Default 30 mins.
         * @default 30*60*1000
         */
        sessionRenewalMs?: number;
        /**
         * A session is logged if it has continued for this amount of time in milliseconds. Default 24h.
         * @default 24*60*60*1000
         */
        sessionExpirationMs?: number;
        /**
         * Max size of telemetry batch. If batch exceeds limit, it is sent and a new batch is started
         * @default 100000
         */
        maxBatchSizeInBytes?: number;
        /**
         * How long to batch telemetry for before sending (milliseconds)
         * @default 15 seconds
         */
        maxBatchInterval?: number;
        /**
         * If true, debugging data is thrown as an exception by the logger. Default false
         * @defaultValue false
         */
        enableDebug?: boolean;
        /**
         * If true, exceptions are not autocollected. Default is false
         * @defaultValue false
         */
        disableExceptionTracking?: boolean;
        /**
         * If true, telemetry is not collected or sent. Default is false
         * @defaultValue false
         */
        disableTelemetry?: boolean;
        /**
         * Percentage of events that will be sent. Default is 100, meaning all events are sent.
         * @defaultValue 100
         */
        samplingPercentage?: number;
        /**
         * If true, on a pageview, the previous instrumented page's view time is tracked and sent as telemetry and a new timer is started for the current pageview. It is sent as a custom metric named PageVisitTime in milliseconds and is calculated via the Date now() function (if available) and falls back to (new Date()).getTime() if now() is unavailable (IE8 or less). Default is false.
         */
        autoTrackPageVisitTime?: boolean;
        /**
         * Automatically track route changes in Single Page Applications (SPA). If true, each route change will send a new Pageview to Application Insights.
         */
        enableAutoRouteTracking?: boolean;
        /**
         * If true, Ajax calls are not autocollected. Default is false
         * @defaultValue false
         */
        disableAjaxTracking?: boolean;
        /**
         * If true, Fetch requests are not autocollected. Default is false (Since 2.8.0, previously true).
         * @defaultValue false
         */
        disableFetchTracking?: boolean;
        /**
         * Provide a way to exclude specific route from automatic tracking for XMLHttpRequest or Fetch request. For an ajax / fetch request that the request url matches with the regex patterns, auto tracking is turned off.
         * @defaultValue undefined.
         */
        excludeRequestFromAutoTrackingPatterns?: string[] | RegExp[];
        /**
         * Provide a way to enrich dependencies logs with context at the beginning of api call.
         * Default is undefined.
         */
        addRequestContext?: (requestContext?: IRequestContext) => ICustomProperties;
        /**
         * If true, default behavior of trackPageView is changed to record end of page view duration interval when trackPageView is called. If false and no custom duration is provided to trackPageView, the page view performance is calculated using the navigation timing API. Default is false
         * @defaultValue false
         */
        overridePageViewDuration?: boolean;
        /**
         * Default 500 - controls how many ajax calls will be monitored per page view. Set to -1 to monitor all (unlimited) ajax calls on the page.
         */
        maxAjaxCallsPerView?: number;
        /**
         * @ignore
         * If false, internal telemetry sender buffers will be checked at startup for items not yet sent. Default is true
         * @defaultValue true
         */
        disableDataLossAnalysis?: boolean;
        /**
         * If false, the SDK will add two headers ('Request-Id' and 'Request-Context') to all dependency requests to correlate them with corresponding requests on the server side. Default is false.
         * @defaultValue false
         */
        disableCorrelationHeaders?: boolean;
        /**
         * Sets the distributed tracing mode. If AI_AND_W3C mode or W3C mode is set, W3C trace context headers (traceparent/tracestate) will be generated and included in all outgoing requests.
         * AI_AND_W3C is provided for back-compatibility with any legacy Application Insights instrumented services
         * @defaultValue AI_AND_W3C
         */
        distributedTracingMode?: DistributedTracingModes;
        /**
         * Disable correlation headers for specific domain
         */
        correlationHeaderExcludedDomains?: string[];
        /**
         * Default false. If true, flush method will not be called when onBeforeUnload, onUnload, onPageHide or onVisibilityChange (hidden state) event(s) trigger.
         */
        disableFlushOnBeforeUnload?: boolean;
        /**
         * Default value of {@link #disableFlushOnBeforeUnload}. If true, flush method will not be called when onPageHide or onVisibilityChange (hidden state) event(s) trigger.
         */
        disableFlushOnUnload?: boolean;
        /**
         * If true, the buffer with all unsent telemetry is stored in session storage. The buffer is restored on page load. Default is true.
         * @defaultValue true
         */
        enableSessionStorageBuffer?: boolean;
        /**
         * If specified, overrides the storage & retrieval mechanism that is used to manage unsent telemetry.
         */
        bufferOverride?: IStorageBuffer;
        /**
         * @deprecated Use either disableCookiesUsage or specify a cookieCfg with the enabled value set.
         * If true, the SDK will not store or read any data from cookies. Default is false. As this field is being deprecated, when both
         * isCookieUseDisabled and disableCookiesUsage are used disableCookiesUsage will take precedent.
         * @defaultValue false
         */
        isCookieUseDisabled?: boolean;
        /**
         * If true, the SDK will not store or read any data from cookies. Default is false.
         * If you have also specified a cookieCfg then enabled property (if specified) will take precedent over this value.
         * @defaultValue false
         */
        disableCookiesUsage?: boolean;
        /**
         * Custom cookie domain. This is helpful if you want to share Application Insights cookies across subdomains.
         * @defaultValue ""
         */
        cookieDomain?: string;
        /**
         * Custom cookie path. This is helpful if you want to share Application Insights cookies behind an application gateway.
         * @defaultValue ""
         */
        cookiePath?: string;
        /**
         * Default false. If false, retry on 206 (partial success), 408 (timeout), 429 (too many requests), 500 (internal server error), 503 (service unavailable), and 0 (offline, only if detected)
         * @description
         * @defaultValue false
         */
        isRetryDisabled?: boolean;
        /**
         * @deprecated Used when initizialing from snippet only.
         *  The url from where the JS SDK will be downloaded.
         */
        url?: string;
        /**
         * If true, the SDK will not store or read any data from local and session storage. Default is false.
         * @defaultValue false
         */
        isStorageUseDisabled?: boolean;
        /**
         * If false, the SDK will send all telemetry using the [Beacon API](https://www.w3.org/TR/beacon)
         * @defaultValue true
         */
        isBeaconApiDisabled?: boolean;
        /**
         * Don't use XMLHttpRequest or XDomainRequest (for IE < 9) by default instead attempt to use fetch() or sendBeacon.
         * If no other transport is available it will still use XMLHttpRequest
         */
        disableXhr?: boolean;
        /**
         * If fetch keepalive is supported do not use it for sending events during unload, it may still fallback to fetch() without keepalive
         */
        onunloadDisableFetch?: boolean;
        /**
         * Sets the sdk extension name. Only alphabetic characters are allowed. The extension name is added as a prefix to the 'ai.internal.sdkVersion' tag (e.g. 'ext_javascript:2.0.0'). Default is null.
         * @defaultValue null
         */
        sdkExtension?: string;
        /**
         * Default is false. If true, the SDK will track all [Browser Link](https://docs.microsoft.com/en-us/aspnet/core/client-side/using-browserlink) requests.
         * @defaultValue false
         */
        isBrowserLinkTrackingEnabled?: boolean;
        /**
         * AppId is used for the correlation between AJAX dependencies happening on the client-side with the server-side requets. When Beacon API is enabled, it cannot be used automatically, but can be set manually in the configuration. Default is null
         * @defaultValue null
         */
        appId?: string;
        /**
         * If true, the SDK will add two headers ('Request-Id' and 'Request-Context') to all CORS requests to correlate outgoing AJAX dependencies with corresponding requests on the server side. Default is false
         * @defaultValue false
         */
        enableCorsCorrelation?: boolean;
        /**
         * An optional value that will be used as name postfix for localStorage and session cookie name.
         * @defaultValue null
         */
        namePrefix?: string;
        /**
         * An optional value that will be used as name postfix for session cookie name. If undefined, namePrefix is used as name postfix for session cookie name.
         * @defaultValue null
         */
        sessionCookiePostfix?: string;
        /**
         * An optional value that will be used as name postfix for user cookie name. If undefined, no postfix is added on user cookie name.
         * @defaultValue null
         */
        userCookiePostfix?: string;
        /**
         * An optional value that will track Request Header through trackDependency function.
         * @defaultValue false
         */
        enableRequestHeaderTracking?: boolean;
        /**
         * An optional value that will track Response Header through trackDependency function.
         * @defaultValue false
         */
        enableResponseHeaderTracking?: boolean;
        /**
         * An optional value that will track Response Error data through trackDependency function.
         * @defaultValue false
         */
        enableAjaxErrorStatusText?: boolean;
        /**
         * Flag to enable looking up and including additional browser window.performance timings
         * in the reported ajax (XHR and fetch) reported metrics.
         * Defaults to false.
         */
        enableAjaxPerfTracking?: boolean;
        /**
         * The maximum number of times to look for the window.performance timings (if available), this
         * is required as not all browsers populate the window.performance before reporting the
         * end of the XHR request and for fetch requests this is added after its complete
         * Defaults to 3
         */
        maxAjaxPerfLookupAttempts?: number;
        /**
         * The amount of time to wait before re-attempting to find the windows.performance timings
         * for an ajax request, time is in milliseconds and is passed directly to setTimeout()
         * Defaults to 25.
         */
        ajaxPerfLookupDelay?: number;
        /**
         * Default false. when tab is closed, the SDK will send all remaining telemetry using the [Beacon API](https://www.w3.org/TR/beacon)
         * @defaultValue false
         */
        onunloadDisableBeacon?: boolean;
        /**
         * @ignore
         * Internal only
         */
        autoExceptionInstrumented?: boolean;
        /**
         *
         */
        correlationHeaderDomains?: string[];
        /**
         * @ignore
         * Internal only
         */
        autoUnhandledPromiseInstrumented?: boolean;
        /**
         * Default false. Define whether to track unhandled promise rejections and report as JS errors.
         * When disableExceptionTracking is enabled (dont track exceptions) this value will be false.
         * @defaultValue false
         */
        enableUnhandledPromiseRejectionTracking?: boolean;
        /**
         * Disable correlation headers using regular expressions
         */
        correlationHeaderExcludePatterns?: RegExp[];
        /**
         * The ability for the user to provide extra headers
         */
        customHeaders?: [{
            header: string;
            value: string;
        }];
        /**
         * Provide user an option to convert undefined field to user defined value.
         */
        convertUndefined?: any;
        /**
         * [Optional] The number of events that can be kept in memory before the SDK starts to drop events. By default, this is 10,000.
         */
        eventsLimitInMem?: number;
        /**
         * [Optional] Disable iKey deprecation error message.
         * @defaultValue true
         */
        disableIkeyDeprecationMessage?: boolean;
        /**
         * [Optional] Sets to true if user wants to disable sending internal log message 'SendBrowserInfoOnUserInit'
         * default to be false for versions 2.8.x and 3.0.x, true for versions 3.1.x and later
         */
        disableUserInitMessage?: boolean;
        /**
         * [Optional] Flag to indicate whether the internal looking endpoints should be automatically
         * added to the `excludeRequestFromAutoTrackingPatterns` collection. (defaults to true).
         * This flag exists as the provided regex is generic and may unexpectedly match a domain that
         * should not be excluded.
         */
        addIntEndpoints?: boolean;
        /**
         * [Optional] Sets throttle mgr configuration by key
         */
        throttleMgrCfg?: {
            [key: number]: IThrottleMgrConfig;
        };
        /**
         * [Optional] Specifies a Highest Priority custom endpoint URL where telemetry data will be sent.
         * This URL takes precedence over the 'config.endpointUrl' and any endpoint in the connection string.
         */
        userOverrideEndpointUrl?: string;
    }

    /**
     * The type to identify whether the default value should be applied in preference to the provided value.
     */
    type IConfigCheckFn<V> = (value: V) => boolean;

    /**
     * The default values with a check function
     */
    interface IConfigDefaultCheck<T, V, C = IConfiguration> {
        /**
         * Callback function to check if the user-supplied value is valid, if not the default will be applied
         */
        isVal?: IConfigCheckFn<V>;
        /**
         * Optional function to allow converting and setting of the default value
         */
        set?: IConfigSetFn<T, V>;
        /**
         * The default value to apply if the user-supplied value is not valid
         */
        v?: V | IConfigDefaults<V, T>;
        /**
         *  The default fallback key if the main key is not present, this is the key value from the config
         */
        fb?: keyof T | keyof C | Array<keyof T | keyof C>;
        /**
         * Use this check to determine the default fallback, default only checked whether the property isDefined,
         * therefore `null`; `""` are considered to be valid values.
         */
        dfVal?: (value: any) => boolean;
        /**
         * Specify that any provided value should have the default value(s) merged into the value rather than
         * just using either the default of user provided values. Mergeed objects will automatically be marked
         * as referenced.
         */
        mrg?: boolean;
        /**
         * Set this field of the target as referenced, which will cause any object or array instance
         * to be updated in-place rather than being entirely replaced. All other values will continue to be replaced.
         * This is required for nested default objects to avoid multiple repetitive updates to listeners
         * @returns The referenced properties current value
         */
        ref?: boolean;
        /**
         * Set this field of the target as read-only, which will block this single named property from
         * ever being changed for the target instance.
         * This does NOT freeze or seal the instance, it just stops the direct re-assignment of the named property,
         * if the value is a non-primitive (ie. an object or array) it's properties will still be mutable.
         * @returns The referenced properties current value
         */
        rdOnly?: boolean;
        /**
         * Block the value associated with this property from having it's properties / values converted into
         * dynamic properties, this is generally used to block objects or arrays provided by external libraries
         * which may be a plain object with readonly (non-configurable) or const properties.
         */
        blkVal?: boolean;
    }

    /**
     * The Type definition to define default values to be applied to the config
     * The value may be either the direct value or a ConfigDefaultCheck definition
     */
    type IConfigDefaults<T, C = IConfiguration> = {
        [key in keyof T]: T[key] | IConfigDefaultCheck<T, T[key], C>;
    };

    /**
     * The type which identifies the function use to validate the user supplied value
     */
    type IConfigSetFn<T, V> = (value: any, defValue: V, theConfig: T) => V;

    /**
     * Configuration provided to SDK core
     */
    interface IConfiguration {
        /**
         * Instrumentation key of resource. Either this or connectionString must be specified.
         */
        instrumentationKey?: string | IPromise<string>;
        /**
         * Connection string of resource. Either this or instrumentationKey must be specified.
         */
        connectionString?: string | IPromise<string>;
        /**
         * Set the timer interval (in ms) for internal logging queue, this is the
         * amount of time to wait after logger.queue messages are detected to be sent.
         * Note: since 3.0.1 and 2.8.13 the diagnostic logger timer is a normal timeout timer
         * and not an interval timer. So this now represents the timer "delay" and not
         * the frequency at which the events are sent.
         */
        diagnosticLogInterval?: number;
        /**
         * Maximum number of iKey transmitted logging telemetry per page view
         */
        maxMessageLimit?: number;
        /**
         * Console logging level. All logs with a severity level higher
         * than the configured level will be printed to console. Otherwise
         * they are suppressed. ie Level 2 will print both CRITICAL and
         * WARNING logs to console, level 1 prints only CRITICAL.
         *
         * Note: Logs sent as telemetry to instrumentation key will also
         * be logged to console if their severity meets the configured loggingConsoleLevel
         *
         * 0: ALL console logging off
         * 1: logs to console: severity >= CRITICAL
         * 2: logs to console: severity >= WARNING
         */
        loggingLevelConsole?: number;
        /**
         * Telemtry logging level to instrumentation key. All logs with a severity
         * level higher than the configured level will sent as telemetry data to
         * the configured instrumentation key.
         *
         * 0: ALL iKey logging off
         * 1: logs to iKey: severity >= CRITICAL
         * 2: logs to iKey: severity >= WARNING
         */
        loggingLevelTelemetry?: number;
        /**
         * If enabled, uncaught exceptions will be thrown to help with debugging
         */
        enableDebug?: boolean;
        /**
         * Endpoint where telemetry data is sent
         */
        endpointUrl?: string | IPromise<string>;
        /**
         * Extension configs loaded in SDK
         */
        extensionConfig?: {
            [key: string]: any;
        };
        /**
         * Additional plugins that should be loaded by core at runtime
         */
        readonly extensions?: ITelemetryPlugin[];
        /**
         * Channel queues that is setup by caller in desired order.
         * If channels are provided here, core will ignore any channels that are already setup, example if there is a SKU with an initialized channel
         */
        readonly channels?: IChannelControls[][];
        /**
         * @type {boolean}
         * Flag that disables the Instrumentation Key validation.
         */
        disableInstrumentationKeyValidation?: boolean;
        /**
         * [Optional] When enabled this will create local perfEvents based on sections of the code that have been instrumented
         * to emit perfEvents (via the doPerf()) when this is enabled. This can be used to identify performance issues within
         * the SDK, the way you are using it or optionally your own instrumented code.
         * The provided IPerfManager implementation does NOT send any additional telemetry events to the server it will only fire
         * the new perfEvent() on the INotificationManager which you can listen to.
         * This also does not use the window.performance API, so it will work in environments where this API is not supported.
         */
        enablePerfMgr?: boolean;
        /**
         * [Optional] Callback function that will be called to create a the IPerfManager instance when required and ```enablePerfMgr```
         * is enabled, this enables you to override the default creation of a PerfManager() without needing to ```setPerfMgr()```
         * after initialization.
         */
        createPerfMgr?: (core: IAppInsightsCore, notificationManager: INotificationManager) => IPerfManager;
        /**
         * [Optional] Fire every single performance event not just the top level root performance event. Defaults to false.
         */
        perfEvtsSendAll?: boolean;
        /**
         * [Optional] Identifies the default length used to generate random session and user id's if non currently exists for the user / session.
         * Defaults to 22, previous default value was 5, if you need to keep the previous maximum length you should set this value to 5.
         */
        idLength?: number;
        /**
         * @description Custom cookie domain. This is helpful if you want to share Application Insights cookies across subdomains. It
         * can be set here or as part of the cookieCfg.domain, the cookieCfg takes precedence if both are specified.
         * @type {string}
         * @defaultValue ""
         */
        cookieDomain?: string;
        /**
         * @description Custom cookie path. This is helpful if you want to share Application Insights cookies behind an application
         * gateway. It can be set here or as part of the cookieCfg.domain, the cookieCfg takes precedence if both are specified.
         * @type {string}
         * @defaultValue ""
         */
        cookiePath?: string;
        /**
         * [Optional] A boolean that indicated whether to disable the use of cookies by the SDK. If true, the SDK will not store or
         * read any data from cookies. Cookie usage can be re-enabled after initialization via the core.getCookieMgr().enable().
         */
        disableCookiesUsage?: boolean;
        /**
         * [Optional] A Cookie Manager configuration which includes hooks to allow interception of the get, set and delete cookie
         * operations. If this configuration is specified any specified enabled and domain properties will take precedence over the
         * cookieDomain and disableCookiesUsage values.
         */
        cookieCfg?: ICookieMgrConfig;
        /**
         * [Optional] An array of the page unload events that you would like to be ignored, special note there must be at least one valid unload
         * event hooked, if you list all or the runtime environment only supports a listed "disabled" event it will still be hooked, if required by the SDK.
         * Unload events include "beforeunload", "unload", "visibilitychange" (with 'hidden' state) and "pagehide"
         */
        disablePageUnloadEvents?: string[];
        /**
         * [Optional] An array of page show events that you would like to be ignored, special note there must be at lease one valid show event
         * hooked, if you list all or the runtime environment only supports a listed (disabled) event it will STILL be hooked, if required by the SDK.
         * Page Show events include "pageshow" and "visibilitychange" (with 'visible' state)
         */
        disablePageShowEvents?: string[];
        /**
         * [Optional] A flag for performance optimization to disable attempting to use the Chrome Debug Extension, if disabled and the extension is installed
         * this will not send any notifications.
         */
        disableDbgExt?: boolean;
        /**
         * Add "&w=0" parameter to support UA Parsing when web-workers don't have access to Document.
         * Default is false
         */
        enableWParam?: boolean;
        /**
         * Custom optional value that will be added as a prefix for storage name.
         * @defaultValue undefined
         */
        storagePrefix?: string;
        /**
         * Custom optional value to opt in features
         * @defaultValue undefined
         */
        featureOptIn?: IFeatureOptIn;
        /**
         * If your connection string, instrumentation key and endpoint url are promises,
         * this config is to manually set timeout for those promises.
         * Default: 50000ms
         * @since 3.3.0
         */
        initTimeOut?: number;
        /**
         * If your connection string, instrumentation key and endpoint url are promises,
         * this config is to manually set in memory proxy track calls count limit before promises finished.
         * Default: 100
         * @since 3.3.0
         */
        initInMemoMaxSize?: number;
        /**
         * [Optional] Set additional configuration for exceptions, such as more scripts to include in the exception telemetry.
         * @since 3.3.2
         */
        expCfg?: IExceptionConfig;
    }

    interface ICookieMgr {
        /**
         * Enable or Disable the usage of cookies
         */
        setEnabled(value: boolean): void;
        /**
         * Can the system use cookies, if this returns false then all cookie setting and access functions will return nothing
         */
        isEnabled(): boolean;
        /**
         * Set the named cookie with the value and optional domain and optional
         * @param name - The name of the cookie
         * @param value - The value of the cookie (Must already be encoded)
         * @param maxAgeSec - [optional] The maximum number of SECONDS that this cookie should survive
         * @param domain - [optional] The domain to set for the cookie
         * @param path - [optional] Path to set for the cookie, if not supplied will default to "/"
         * @returns - True if the cookie was set otherwise false (Because cookie usage is not enabled or available)
         */
        set(name: string, value: string, maxAgeSec?: number, domain?: string, path?: string): boolean;
        /**
         * Get the value of the named cookie
         * @param name - The name of the cookie
         */
        get(name: string): string;
        /**
         * Delete/Remove the named cookie if cookie support is available and enabled.
         * Note: Not using "delete" as the name because it's a reserved word which would cause issues on older browsers
         * @param name - The name of the cookie
         * @param path - [optional] Path to set for the cookie, if not supplied will default to "/"
         * @returns - True if the cookie was marked for deletion otherwise false (Because cookie usage is not enabled or available)
         */
        del(name: string, path?: string): boolean;
        /**
         * Purge the cookie from the system if cookie support is available, this function ignores the enabled setting of the manager
         * so any cookie will be removed.
         * Note: Not using "delete" as the name because it's a reserved word which would cause issues on older browsers
         * @param name - The name of the cookie
         * @param path - [optional] Path to set for the cookie, if not supplied will default to "/"
         * @returns - True if the cookie was marked for deletion otherwise false (Because cookie usage is not available)
         */
        purge(name: string, path?: string): boolean;
        /**
         * Optional Callback hook to allow the cookie manager to update it's configuration, not generally implemented now that
         * dynamic configuration is supported
         * @param updateState
         */
        update?(updateState: ITelemetryUpdateState): void;
        /**
         * Unload and remove any state that this ICookieMgr may be holding, this is generally called when the
         * owning SDK is being unloaded.
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @return If the unload occurs synchronously then nothing should be returned, if happening asynchronously then
         * the function should return an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * / Promise to allow any listeners to wait for the operation to complete.
         */
        unload?(isAsync?: boolean): void | IPromise<void>;
    }

    /**
     * Configuration definition for instance based cookie management configuration
     */
    interface ICookieMgrConfig {
        /**
         * Defaults to true, A boolean that indicates whether the use of cookies by the SDK is enabled by the current instance.
         * If false, the instance of the SDK initialized by this configuration will not store or read any data from cookies
         */
        enabled?: boolean;
        /**
         * Custom cookie domain. This is helpful if you want to share Application Insights cookies across subdomains.
         */
        domain?: string;
        /**
         * Specifies the path to use for the cookie, defaults to '/'
         */
        path?: string;
        /**
         * Specify the cookie name(s) to be ignored, this will cause any matching cookie name to never be read or written.
         * They may still be explicitly purged or deleted. You do not need to repeat the name in the `blockedCookies`
         * configuration.(Since v2.8.8)
         */
        ignoreCookies?: string[];
        /**
         * Specify the cookie name(s) to never be written, this will cause any cookie name to never be created or updated,
         * they will still be read unless also included in the ignoreCookies and may still be explicitly purged or deleted.
         * If not provided defaults to the same list provided in ignoreCookies. (Since v2.8.8)
         */
        blockedCookies?: string[];
        /**
         * Hook function to fetch the named cookie value.
         * @param name - The name of the cookie
         */
        getCookie?: (name: string) => string;
        /**
         * Hook function to set the named cookie with the specified value.
         * @param name - The name of the cookie
         * @param value - The value to set for the cookie
         */
        setCookie?: (name: string, value: string) => void;
        /**
         * Hook function to delete the named cookie with the specified value, separated from
         * setCookie to avoid the need to parse the value to determine whether the cookie is being
         * added or removed.
         * @param name - The name of the cookie
         * @param cookieValue - The value to set to expire the cookie
         */
        delCookie?: (name: string, cookieValue: string) => void;
    }

    interface ICustomProperties {
        [key: string]: any;
    }

    /**
     * DependencyTelemetry telemetry interface
     */
    interface IDependencyTelemetry extends IPartC {
        id: string;
        name?: string;
        duration?: number;
        success?: boolean;
        startTime?: Date;
        responseCode: number;
        correlationContext?: string;
        type?: string;
        data?: string;
        target?: string;
        iKey?: string;
    }

    interface IDiagnosticLogger {
        /**
         * 0: OFF
         * 1: only critical (default)
         * 2: critical + info
         */
        consoleLoggingLevel: () => number;
        /**
         * The internal logging queue
         */
        queue: _InternalLogMessage[];
        /**
         * This method will throw exceptions in debug mode or attempt to log the error as a console warning.
         * @param severity - The severity of the log message
         * @param message - The log message.
         */
        throwInternal(severity: LoggingSeverity, msgId: _InternalMessageId, msg: string, properties?: Object, isUserAct?: boolean): void;
        /**
         * This will write a debug message to the console if possible
         * @param message - {string} - The debug message
         */
        debugToConsole?(message: string): void;
        /**
         * This will write a warning to the console if possible
         * @param message - The warning message
         */
        warnToConsole(message: string): void;
        /**
         * This will write an error to the console if possible.
         * Provided by the default DiagnosticLogger instance, and internally the SDK will fall back to warnToConsole, however,
         * direct callers MUST check for its existence on the logger as you can provide your own IDiagnosticLogger instance.
         * @param message - The error message
         */
        errorToConsole?(message: string): void;
        /**
         * Resets the internal message count
         */
        resetInternalMessageCount(): void;
        /**
         * Logs a message to the internal queue.
         * @param severity - The severity of the log message
         * @param message - The message to log.
         */
        logInternalMessage?(severity: LoggingSeverity, message: _InternalLogMessage): void;
        /**
         * Optional Callback hook to allow the diagnostic logger to update it's configuration
         * @param updateState
         */
        update?(updateState: ITelemetryUpdateState): void;
        /**
         * Unload and remove any state that this IDiagnosticLogger may be holding, this is generally called when the
         * owning SDK is being unloaded.
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @return If the unload occurs synchronously then nothing should be returned, if happening asynchronously then
         * the function should return an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * / Promise to allow any listeners to wait for the operation to complete.
         */
        unload?(isAsync?: boolean): void | IPromise<void>;
    }

    interface IDistributedTraceContext {
        /**
         * Returns the current name of the page
         */
        getName(): string;
        /**
         * Sets the current name of the page
         * @param pageName
         */
        setName(pageName: string): void;
        /**
         * Returns the unique identifier for a trace. All requests / spans from the same trace share the same traceId.
         * Must be read from incoming headers or generated according to the W3C TraceContext specification,
         * in a hex representation of 16-byte array. A.k.a. trace-id, TraceID or Distributed TraceID
         */
        getTraceId(): string;
        /**
         * Set the unique identifier for a trace. All requests / spans from the same trace share the same traceId.
         * Must be conform to the W3C TraceContext specification, in a hex representation of 16-byte array.
         * A.k.a. trace-id, TraceID or Distributed TraceID https://www.w3.org/TR/trace-context/#trace-id
         */
        setTraceId(newValue: string): void;
        /**
         * Self-generated 8-bytes identifier of the incoming request. Must be a hex representation of 8-byte array.
         * Also know as the parentId, used to link requests together
         */
        getSpanId(): string;
        /**
         * Self-generated 8-bytes identifier of the incoming request. Must be a hex representation of 8-byte array.
         * Also know as the parentId, used to link requests together
         * https://www.w3.org/TR/trace-context/#parent-id
         */
        setSpanId(newValue: string): void;
        /**
         * An integer representation of the W3C TraceContext trace-flags.
         */
        getTraceFlags(): number | undefined;
        /**
         * https://www.w3.org/TR/trace-context/#trace-flags
         * @param newValue
         */
        setTraceFlags(newValue?: number): void;
    }

    interface IEnvelope extends ISerializable {
        /**
         * Envelope version. For internal use only. By assigning this the default, it will not be serialized within the payload unless changed to a value other than #1.
         */
        ver: number;
        /**
         * Type name of telemetry data item.
         */
        name: string;
        /**
         * Event date time when telemetry item was created. This is the wall clock time on the client when the event was generated. There is no guarantee that the client's time is accurate. This field must be formatted in UTC ISO 8601 format, with a trailing 'Z' character, as described publicly on https://en.wikipedia.org/wiki/ISO_8601#UTC. Note: the number of decimal seconds digits provided are variable (and unspecified). Consumers should handle this, i.e. managed code consumers should not use format 'O' for parsing as it specifies a fixed length. Example: 2009-06-15T13:45:30.0000000Z.
         */
        time: string;
        /**
         * Sampling rate used in application. This telemetry item represents 1 / sampleRate actual telemetry items.
         */
        sampleRate: number;
        /**
         * Sequence field used to track absolute order of uploaded events.
         */
        seq: string;
        /**
         * The application's instrumentation key. The key is typically represented as a GUID, but there are cases when it is not a guid. No code should rely on iKey being a GUID. Instrumentation key is case insensitive.
         */
        iKey: string;
        /**
         * Key/value collection of context properties. See ContextTagKeys for information on available properties.
         */
        tags: {
            [name: string]: any;
        };
        /**
         * Telemetry data item.
         */
        data: any;
    }

    interface IEventTelemetry extends IPartC {
        /**
         * @description An event name string
         * @type {string}
         * @memberof IEventTelemetry
         */
        name: string;
        /**
         * @description custom defined iKey
         * @type {string}
         * @memberof IEventTelemetry
         */
        iKey?: string;
    }

    /**
     * Configuration for extra exceptions information sent with the exception telemetry.
     * @example
     * ```js
     * const appInsights = new ApplicationInsights({
     config: {
     connectionString: 'InstrumentationKey=YOUR_INSTRUMENTATION_KEY_GOES_HERE',
     expCfg: {
     inclScripts: true,
     expLog : () => {
     return {logs: ["log info 1", "log info 2"]};
     },
     maxLogs : 100
     }
     }
     });
     appInsights.trackException({error: new Error(), severityLevel: SeverityLevel.Critical});
     * ```
     * @interface IExceptionConfig
     */
    interface IExceptionConfig {
        /**
         * If set to true, when exception is sent out, the SDK will also send out all scripts basic info that are loaded on the page.
         * Notice: This would increase the size of the exception telemetry.
         * @defaultvalue true
         */
        inclScripts?: boolean;
        /**
         * Callback function for collecting logs to be included in telemetry data.
         *
         * The length of logs to generate is controlled by the `maxLogs` parameter.
         *
         * This callback is called before telemetry data is sent, allowing for dynamic customization of the logs.
         *
         * @returns {Object} An object with the following property:
         * - logs: An array of strings, where each string represents a log entry to be included in the telemetry.
         *
         * @property {number} maxLogs - Specifies the maximum number of logs that can be generated. If not explicitly set, it defaults to 50.
         */
        expLog?: () => {
            logs: string[];
        };
        /**
         * The maximum number of logs to include in the telemetry data.
         * If not explicitly set, it defaults to 50.
         * This is used in conjunction with the `expLog` callback.
         */
        maxLogs?: number;
    }

    interface IFeatureOptIn {
        [feature: string]: IFeatureOptInDetails;
    }

    interface IFeatureOptInDetails {
        /**
         * sets feature opt-in mode
         * @default undefined
         */
        mode?: FeatureOptInMode;
        /**
         * Identifies configuration override values when given feature is enabled
         * NOTE: should use flat string for fields, for example, if you want to set value for extensionConfig.Ananlytics.disableAjaxTrackig in configurations,
         * you should use "extensionConfig.Ananlytics.disableAjaxTrackig" as field name: {["extensionConfig.Analytics.disableAjaxTrackig"]:1}
         * Default: undefined
         */
        onCfg?: {
            [field: string]: any;
        };
        /**
         * Identifies configuration override values when given feature is disabled
         * NOTE: should use flat string for fields, for example, if you want to set value for extensionConfig.Ananlytics.disableAjaxTrackig in configurations,
         * you should use "extensionConfig.Ananlytics.disableAjaxTrackig" as field name: {["extensionConfig.Analytics.disableAjaxTrackig"]:1}
         * Default: undefined
         */
        offCfg?: {
            [field: string]: any;
        };
        /**
         * define if should block any changes from cdn cfg, if set to true, cfgValue will be applied under all scenarios
         * @default false
         */
        blockCdnCfg?: boolean;
    }

    /**
     * Internal Interface
     */
    interface IInternalOfflineSupport {
        /**
         * Get current endpoint url
         * @returns endpoint
         */
        getUrl: () => string;
        /**
         * Create payload data
         * @param data data
         * @returns IPayloadData
         */
        createPayload: (data: string | Uint8Array) => IPayloadData;
        /**
         * Serialize an item into a string
         * @param input telemetry item
         * @param convertUndefined convert undefined to a custom-defined object
         * @returns Serialized string
         */
        serialize?: (input: ITelemetryItem, convertUndefined?: any) => string;
        /**
         * Batch an array of strings into one string
         * @param arr array of strings
         * @returns a string represent all items in the given array
         */
        batch?: (arr: string[]) => string;
        /**
         * If the item should be processed by offline channel
         * @param evt telemetry item
         * @returns should process or not
         */
        shouldProcess?: (evt: ITelemetryItem) => boolean;
        /**
         * Create 1ds payload data
         * @param evts ITelemetryItems
         * @returns IPayloadData
         */
        createOneDSPayload?: (evts: ITelemetryItem[]) => IPayloadData;
    }

    /**
     * Internal interface for sendBuffer, do not export it
     * @internal
     * @since 3.1.3
     */
    interface IInternalStorageItem {
        /**
         * serialized telemetry to be stored.
         */
        item: string;
        /**
         * total retry count
         */
        cnt?: number;
    }

    /**
     * An alternate interface which provides automatic removal during unloading of the component
     */
    interface ILegacyUnloadHook {
        /**
         * Legacy Self remove the referenced component
         */
        remove: () => void;
    }

    interface ILoadedPlugin<T extends IPlugin> {
        plugin: T;
        /**
         * Identifies whether the plugin is enabled and can process events. This is slightly different from isInitialized as the plugin may be initialized but disabled
         * via the setEnabled() or it may be a shared plugin which has had it's teardown function called from another instance..
         * @returns boolean = true if the plugin is in a state where it is operational.
         */
        isEnabled: () => boolean;
        /**
         * You can optionally enable / disable a plugin from processing events.
         * Setting enabled to true will not necessarily cause the `isEnabled()` to also return true
         * as the plugin must also have been successfully initialized and not had it's `teardown` method called
         * (unless it's also been re-initialized)
         */
        setEnabled: (isEnabled: boolean) => void;
        remove: (isAsync?: boolean, removeCb?: (removed?: boolean) => void) => void;
    }

    interface IMetricTelemetry extends IPartC {
        /**
         * @description (required) - name of this metric
         * @type {string}
         * @memberof IMetricTelemetry
         */
        name: string;
        /**
         * @description (required) - Recorded value/average for this metric
         * @type {number}
         * @memberof IMetricTelemetry
         */
        average: number;
        /**
         * @description (optional) Number of samples represented by the average.
         * @type {number=}
         * @memberof IMetricTelemetry
         * @default sampleCount=1
         */
        sampleCount?: number;
        /**
         * @description (optional) The smallest measurement in the sample. Defaults to the average
         * @type {number}
         * @memberof IMetricTelemetry
         * @default min=average
         */
        min?: number;
        /**
         * @description (optional) The largest measurement in the sample. Defaults to the average.
         * @type {number}
         * @memberof IMetricTelemetry
         * @default max=average
         */
        max?: number;
        /**
         * (optional) The standard deviation measurement in the sample, Defaults to undefined which results in zero.
         */
        stdDev?: number;
        /**
         * @description custom defined iKey
         * @type {string}
         * @memberof IMetricTelemetry
         */
        iKey?: string;
    }

    /**
     * An interface used for the notification listener.
     * @interface
     */
    interface INotificationListener {
        /**
         * [Optional] A function called when events are sent.
         * @param events - The array of events that have been sent.
         */
        eventsSent?: (events: ITelemetryItem[]) => void;
        /**
         * [Optional] A function called when events are discarded.
         * @param events - The array of events that have been discarded.
         * @param reason - The reason for discarding the events. The EventsDiscardedReason
         * constant should be used to check the different values.
         */
        eventsDiscarded?: (events: ITelemetryItem[], reason: number) => void;
        /**
         * [Optional] A function called when the events have been requested to be sent to the sever.
         * @param sendReason - The reason why the event batch is being sent.
         * @param isAsync - A flag which identifies whether the requests are being sent in an async or sync manner.
         */
        eventsSendRequest?: (sendReason: number, isAsync?: boolean) => void;
        /**
         * [Optional] This event is sent if you have enabled perf events, they are primarily used to track internal performance testing and debugging
         * the event can be displayed via the debug plugin extension.
         * @param perfEvent
         */
        perfEvent?: (perfEvent: IPerfEvent) => void;
        /**
         * Unload and remove any state that this INotificationListener may be holding, this is generally called when the
         * owning Manager is being unloaded.
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @return If the unload occurs synchronously then nothing should be returned, if happening asynchronously then
         * the function should return an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * / Promise to allow any listeners to wait for the operation to complete.
         */
        unload?(isAsync?: boolean): void | IPromise<void>;
        /**
         * [Optional] A function called when the offline events have been stored to the persistent storage
         * @param events - items that are stored in the persistent storage
         * @since v3.1.1
         */
        offlineEventsStored?(events: ITelemetryItem[]): void;
        /**
         * [Optional] A function called when the offline events have been sent from the persistent storage
         * @param batch - payload data that is sent from the persistent storage
         * @since v3.1.1
         */
        offlineBatchSent?(batch: IPayloadData): void;
        /**
         * [Optional] A function called when the offline events have been dropped from the persistent storage
         * @param cnt - count of batches dropped
         * @param reason - the reason why the batches is dropped
         * @since v3.1.1
         */
        offlineBatchDrop?(cnt: number, reason?: number): void;
    }

    /**
     * Class to manage sending notifications to all the listeners.
     */
    interface INotificationManager {
        listeners: INotificationListener[];
        /**
         * Adds a notification listener.
         * @param listener - The notification listener to be added.
         */
        addNotificationListener(listener: INotificationListener): void;
        /**
         * Removes all instances of the listener.
         * @param listener - AWTNotificationListener to remove.
         */
        removeNotificationListener(listener: INotificationListener): void;
        /**
         * Notification for events sent.
         * @param events - The array of events that have been sent.
         */
        eventsSent(events: ITelemetryItem[]): void;
        /**
         * Notification for events being discarded.
         * @param events - The array of events that have been discarded by the SDK.
         * @param reason - The reason for which the SDK discarded the events. The EventsDiscardedReason
         * constant should be used to check the different values.
         */
        eventsDiscarded(events: ITelemetryItem[], reason: number): void;
        /**
         * [Optional] A function called when the events have been requested to be sent to the sever.
         * @param sendReason - The reason why the event batch is being sent.
         * @param isAsync - A flag which identifies whether the requests are being sent in an async or sync manner.
         */
        eventsSendRequest?(sendReason: number, isAsync: boolean): void;
        /**
         * [Optional] This event is sent if you have enabled perf events, they are primarily used to track internal performance testing and debugging
         * the event can be displayed via the debug plugin extension.
         * @param perfEvent - The perf event details
         */
        perfEvent?(perfEvent: IPerfEvent): void;
        /**
         * Unload and remove any state that this INotificationManager may be holding, this is generally called when the
         * owning SDK is being unloaded.
         * @param isAsync - Can the unload be performed asynchronously (default)
         * @return If the unload occurs synchronously then nothing should be returned, if happening asynchronously then
         * the function should return an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * / Promise to allow any listeners to wait for the operation to complete.
         */
        unload?(isAsync?: boolean): void | IPromise<void>;
        /**
         * [Optional] A function called when the offline events have been stored to the persistent storage
         * @param events - items that are stored in the persistent storage
         * @since v3.1.1
         */
        offlineEventsStored?(events: ITelemetryItem[]): void;
        /**
         * [Optional] A function called when the offline events have been sent from the persistent storage
         * @param batch - payload data that is sent from the persistent storage
         * @since v3.1.1
         */
        offlineBatchSent?(batch: IPayloadData): void;
        /**
         * [Optional] A function called when the offline events have been dropped from the persistent storage
         * @param cnt - count of batches dropped
         * @param reason - the reason why the batches is dropped
         * @since v3.1.1
         */
        offlineBatchDrop?(cnt: number, reason?: number): void;
    }

    class _InternalLogMessage {
        static dataType: string;
        message: string;
        messageId: _InternalMessageId;
        constructor(msgId: _InternalMessageId, msg: string, isUserAct?: boolean, properties?: Object);
    }

    type _InternalMessageId = number | _eInternalMessageId;

    interface IOfflineListener {
        isOnline: () => boolean;
        isListening: () => boolean;
        unload: () => void;
        addListener: (callback: OfflineCallback) => IUnloadHook;
        setOnlineState: (uState: eOfflineValue) => void;
    }

    /**
     * This is the interface for the Offline state
     * runtime state is retrieved from the browser state
     * user state is set by the user
     */
    interface IOfflineState {
        readonly isOnline: boolean;
        readonly rState: eOfflineValue;
        readonly uState: eOfflineValue;
    }

    interface IPageViewPerformanceTelemetry extends IPartC {
        /**
         * name String - The name of the page. Defaults to the document title.
         */
        name?: string;
        /**
         * url String - a relative or absolute URL that identifies the page or other item. Defaults to the window location.
         */
        uri?: string;
        /**
         * Performance total in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff". This is total duration in timespan format.
         */
        perfTotal?: string;
        /**
         * Performance total in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff". This represents the total page load time.
         */
        duration?: string;
        /**
         * Sent request time in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff
         */
        networkConnect?: string;
        /**
         * Sent request time in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff.
         */
        sentRequest?: string;
        /**
         * Received response time in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff.
         */
        receivedResponse?: string;
        /**
         * DOM processing time in TimeSpan 'G' (general long) format: d:hh:mm:ss.fffffff
         */
        domProcessing?: string;
    }

    /**
     * Pageview telemetry interface
     */
    interface IPageViewTelemetry extends IPartC {
        /**
         * name String - The string you used as the name in startTrackPage. Defaults to the document title.
         */
        name?: string;
        /**
         * uri  String - a relative or absolute URL that identifies the page or other item. Defaults to the window location.
         */
        uri?: string;
        /**
         * refUri  String - the URL of the source page where current page is loaded from
         */
        refUri?: string;
        /**
         * pageType  String - page type
         */
        pageType?: string;
        /**
         * isLoggedIn - boolean is user logged in
         */
        isLoggedIn?: boolean;
        /**
         * Property bag to contain additional custom properties (Part C)
         */
        properties?: {
            /**
             * The number of milliseconds it took to load the page. Defaults to undefined. If set to default value, page load time is calculated internally.
             */
            duration?: number;
            [key: string]: any;
        };
        /**
         * iKey String - custom defined iKey.
         */
        iKey?: string;
        /**
         * Time first page view is triggered
         */
        startTime?: Date;
    }

    /**
     * PartC  telemetry interface
     */
    interface IPartC {
        /**
         * Property bag to contain additional custom properties (Part C)
         */
        properties?: {
            [key: string]: any;
        };
        /**
         * Property bag to contain additional custom measurements (Part C)
         * @deprecated -- please use properties instead
         */
        measurements?: {
            [key: string]: number;
        };
    }

    /** IPayloadData describes interface of payload sent via POST channel */
    interface IPayloadData {
        urlString: string;
        data: Uint8Array | string;
        headers?: {
            [name: string]: string;
        };
        timeout?: number;
        disableXhrSync?: boolean;
        disableFetchKeepAlive?: boolean;
        sendReason?: SendRequestReason;
    }

    /**
     * This interface identifies the details of an internal performance event - it does not represent an outgoing reported event
     */
    interface IPerfEvent {
        /**
         * The name of the performance event
         */
        name: string;
        /**
         * The start time of the performance event
         */
        start: number;
        /**
         * The payload (contents) of the perfEvent, may be null or only set after the event has completed depending on
         * the runtime environment.
         */
        payload: any;
        /**
         * Is this occurring from an asynchronous event
         */
        isAsync: boolean;
        /**
         * Identifies the total inclusive time spent for this event, including the time spent for child events,
         * this will be undefined until the event is completed
         */
        time?: number;
        /**
         * Identifies the exclusive time spent in for this event (not including child events),
         * this will be undefined until the event is completed.
         */
        exTime?: number;
        /**
         * The Parent event that was started before this event was created
         */
        parent?: IPerfEvent;
        /**
         * The child perf events that are contained within the total time of this event.
         */
        childEvts?: IPerfEvent[];
        /**
         * Identifies whether this event is a child event of a parent
         */
        isChildEvt: () => boolean;
        /**
         * Get the names additional context associated with this perf event
         */
        getCtx?: (key: string) => any;
        /**
         * Set the named additional context to be associated with this perf event, this will replace any existing value
         */
        setCtx?: (key: string, value: any) => void;
        /**
         * Mark this event as completed, calculating the total execution time.
         */
        complete: () => void;
    }

    /**
     * This defines an internal performance manager for tracking and reporting the internal performance of the SDK -- It does
     * not represent or report any event to the server.
     */
    interface IPerfManager {
        /**
         * Create a new event and start timing, the manager may return null/undefined to indicate that it does not
         * want to monitor this source event.
         * @param src - The source name of the event
         * @param payloadDetails - An optional callback function to fetch the payload details for the event.
         * @param isAsync - Is the event occurring from a async event
         */
        create(src: string, payloadDetails?: () => any, isAsync?: boolean): IPerfEvent | null | undefined;
        /**
         * Complete the perfEvent and fire any notifications.
         * @param perfEvent - Fire the event which will also complete the passed event
         */
        fire(perfEvent: IPerfEvent): void;
        /**
         * Set an execution context value
         * @param key - The context key name
         * @param value - The value
         */
        setCtx(key: string, value: any): void;
        /**
         * Get the execution context value
         * @param key - The context key
         */
        getCtx(key: string): any;
    }

    /**
     * Identifies an interface to a host that can provide an IPerfManager implementation
     */
    interface IPerfManagerProvider {
        /**
         * Get the current performance manager
         */
        getPerfMgr(): IPerfManager;
        /**
         * Set the current performance manager
         * @param perfMgr - The performance manager
         */
        setPerfMgr(perfMgr: IPerfManager): void;
    }

    interface IPlugin {
        /**
         * Initialize plugin loaded by SDK
         * @param config - The config for the plugin to use
         * @param core - The current App Insights core to use for initializing this plugin instance
         * @param extensions - The complete set of extensions to be used for initializing the plugin
         * @param pluginChain - [Optional] specifies the current plugin chain which identifies the
         * set of plugins and the order they should be executed for the current request.
         */
        initialize: (config: IConfiguration, core: IAppInsightsCore, extensions: IPlugin[], pluginChain?: ITelemetryPluginChain) => void;
        /**
         * Returns a value that indicates whether the plugin has already been previously initialized.
         * New plugins should implement this method to avoid being initialized more than once.
         */
        isInitialized?: () => boolean;
        /**
         * Tear down the plugin and remove any hooked value, the plugin should be removed so that it is no longer initialized and
         * therefore could be re-initialized after being torn down. The plugin should ensure that once this has been called any further
         * processTelemetry calls are ignored and it just calls the processNext() with the provided context.
         * @param unloadCtx - This is the context that should be used during unloading.
         * @param unloadState - The details / state of the unload process, it holds details like whether it should be unloaded synchronously or asynchronously and the reason for the unload.
         * @returns boolean - true if the plugin has or will call processNext(), this for backward compatibility as previously teardown was synchronous and returned nothing.
         */
        teardown?: (unloadCtx: IProcessTelemetryUnloadContext, unloadState?: ITelemetryUnloadState) => void | boolean;
        /**
         * Extension name
         */
        readonly identifier: string;
        /**
         * Plugin version (available in data.properties.version in common schema)
         */
        readonly version?: string;
        /**
         * The App Insights core to use for backward compatibility.
         * Therefore the interface will be able to access the core without needing to cast to "any".
         * [optional] any 3rd party plugins which are already implementing this interface don't fail to compile.
         */
        core?: IAppInsightsCore;
    }

    /**
     * The current context for the current call to processTelemetry(), used to support sharing the same plugin instance
     * between multiple AppInsights instances
     */
    interface IProcessTelemetryContext extends IBaseProcessingContext {
        /**
         * Call back for telemetry processing before it it is sent
         * @param env - This is the current event being reported
         * @returns boolean (true) if there is no more plugins to process otherwise false or undefined (void)
         */
        processNext: (env: ITelemetryItem) => boolean | void;
        /**
         * Create a new context using the core and config from the current instance, returns a new instance of the same type
         * @param plugins - The execution order to process the plugins, if null or not supplied
         *                  then the current execution order will be copied.
         * @param startAt - The plugin to start processing from, if missing from the execution
         *                  order then the next plugin will be NOT set.
         */
        createNew: (plugins?: IPlugin[] | ITelemetryPluginChain, startAt?: IPlugin) => IProcessTelemetryContext;
    }

    /**
     * The current context for the current call to teardown() implementations, used to support when plugins are being removed
     * or the SDK is being unloaded.
     */
    interface IProcessTelemetryUnloadContext extends IBaseProcessingContext {
        /**
         * This Plugin has finished unloading, so unload the next one
         * @param uploadState - The state of the unload process
         * @returns boolean (true) if there is no more plugins to process otherwise false or undefined (void)
         */
        processNext: (unloadState: ITelemetryUnloadState) => boolean | void;
        /**
         * Create a new context using the core and config from the current instance, returns a new instance of the same type
         * @param plugins - The execution order to process the plugins, if null or not supplied
         *                  then the current execution order will be copied.
         * @param startAt - The plugin to start processing from, if missing from the execution
         *                  order then the next plugin will be NOT set.
         */
        createNew: (plugins?: IPlugin[] | ITelemetryPluginChain, startAt?: IPlugin) => IProcessTelemetryUnloadContext;
    }

    /**
     * The current context for the current call to the plugin update() implementations, used to support the notifications
     * for when plugins are added, removed or the configuration was changed.
     */
    interface IProcessTelemetryUpdateContext extends IBaseProcessingContext {
        /**
         * This Plugin has finished unloading, so unload the next one
         * @param updateState - The update State
         * @returns boolean (true) if there is no more plugins to process otherwise false or undefined (void)
         */
        processNext: (updateState: ITelemetryUpdateState) => boolean | void;
        /**
         * Create a new context using the core and config from the current instance, returns a new instance of the same type
         * @param plugins - The execution order to process the plugins, if null or not supplied
         *                  then the current execution order will be copied.
         * @param startAt - The plugin to start processing from, if missing from the execution
         *                  order then the next plugin will be NOT set.
         */
        createNew: (plugins?: IPlugin[] | ITelemetryPluginChain, startAt?: IPlugin) => IProcessTelemetryUpdateContext;
    }

    /**
     * Create a Promise object that represents the eventual completion (or failure) of an asynchronous operation and its resulting value.
     * This interface definition, closely mirrors the typescript / javascript PromiseLike<T> and Promise<T> definitions as well as providing
     * simular functions as that provided by jQuery deferred objects.
     *
     * The returned Promise is a proxy for a value not necessarily known when the promise is created. It allows you to associate handlers
     * with an asynchronous action's eventual success value or failure reason. This lets asynchronous methods return values like synchronous
     * methods: instead of immediately returning the final value, the asynchronous method returns a promise to supply the value at some point
     * in the future.
     *
     * A Promise is in one of these states:
     * <ul>
     * <li> pending: initial state, neither fulfilled nor rejected.
     * <li> fulfilled: meaning that the operation was completed successfully.
     * <li> rejected: meaning that the operation failed.
     * </ul>
     *
     * A pending promise can either be fulfilled with a value or rejected with a reason (error). When either of these options happens, the
     * associated handlers queued up by a promise's then method are called synchronously. If the promise has already been fulfilled or rejected
     * when a corresponding handler is attached, the handler will be called synchronously, so there is no race condition between an asynchronous
     * operation completing and its handlers being attached.
     *
     * As the `then()` and `catch()` methods return promises, they can be chained.
     * @typeParam T - Identifies the expected return type from the promise
     */
    interface IPromise<T> extends PromiseLike<T>, Promise<T> {
        /**
         * Returns a string representation of the current state of the promise. The promise can be in one of four states.
         * <ul>
         * <li> <b>"pending"</b>: The promise is not yet in a completed state (neither "rejected"; or "resolved").</li>
         * <li> <b>"resolved"</b>: The promise is in the resolved state.</li>
         * <li> <b>"rejected"</b>: The promise is in the rejected state.</li>
         * </ul>
         * @example
         * ```ts
         * let doResolve;
         * let promise: IPromise<any> = createSyncPromise((resolve) => {
         *  doResolve = resolve;
         * });
         *
         * let state: string = promise.state();
         * console.log("State: " + state);      // State: pending
         * doResolve(true);                     // Promise will resolve synchronously as it's a synchronous promise
         * console.log("State: " + state);      // State: resolved
         * ```
         */
        state?: string;
        /**
         * Attaches callbacks for the resolution and/or rejection of the Promise.
         * @param onResolved The callback to execute when the Promise is resolved.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of which ever callback is executed.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   resolve('Success!');
         * });
         *
         * promise1.then((value) => {
         *   console.log(value);
         *   // expected output: "Success!"
         * });
         * ```
         */
        then<TResult1 = T, TResult2 = never>(onResolved?: ResolvedPromiseHandler<T, TResult1>, onRejected?: RejectedPromiseHandler<TResult2>): IPromise<TResult1 | TResult2>;
        /**
         * Attaches callbacks for the resolution and/or rejection of the Promise.
         * @param onResolved The callback to execute when the Promise is resolved.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of which ever callback is executed.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   resolve('Success!');
         * });
         *
         * promise1.then((value) => {
         *   console.log(value);
         *   // expected output: "Success!"
         * });
         * ```
         */
        then<TResult1 = T, TResult2 = never>(onResolved?: ResolvedPromiseHandler<T, TResult1>, onRejected?: RejectedPromiseHandler<TResult2>): PromiseLike<TResult1 | TResult2>;
        /**
         * Attaches callbacks for the resolution and/or rejection of the Promise.
         * @param onResolved The callback to execute when the Promise is resolved.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of which ever callback is executed.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   resolve('Success!');
         * });
         *
         * promise1.then((value) => {
         *   console.log(value);
         *   // expected output: "Success!"
         * });
         * ```
         */
        then<TResult1 = T, TResult2 = never>(onResolved?: ResolvedPromiseHandler<T, TResult1>, onRejected?: RejectedPromiseHandler<TResult2>): Promise<TResult1 | TResult2>;
        /**
         * Attaches a callback for only the rejection of the Promise.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of the callback.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   throw 'Uh-oh!';
         * });
         *
         * promise1.catch((error) => {
         *   console.error(error);
         * });
         * // expected output: Uh-oh!
         * ```
         */
        catch<TResult = never>(onRejected?: ((reason: any) => TResult | IPromise<TResult>) | undefined | null): IPromise<T | TResult>;
        /**
         * Attaches a callback for only the rejection of the Promise.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of the callback.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   throw 'Uh-oh!';
         * });
         *
         * promise1.catch((error) => {
         *   console.error(error);
         * });
         * // expected output: Uh-oh!
         * ```
         */
        catch<TResult = never>(onRejected?: ((reason: any) => TResult | IPromise<TResult>) | undefined | null): PromiseLike<T | TResult>;
        /**
         * Attaches a callback for only the rejection of the Promise.
         * @param onRejected The callback to execute when the Promise is rejected.
         * @returns A Promise for the completion of the callback.
         * @example
         * ```ts
         * const promise1 = createPromise((resolve, reject) => {
         *   throw 'Uh-oh!';
         * });
         *
         * promise1.catch((error) => {
         *   console.error(error);
         * });
         * // expected output: Uh-oh!
         * ```
         */
        catch<TResult = never>(onRejected?: ((reason: any) => TResult | IPromise<TResult>) | undefined | null): Promise<T | TResult>;
        /**
         * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
         * resolved value cannot be modified from the callback.
         * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
         * @returns A Promise for the completion of the callback.
         * @example
         * ```ts
         * function doFunction() {
         *   return createPromise((resolve, reject) => {
         *     if (Math.random() > 0.5) {
         *       resolve('Function has completed');
         *     } else {
         *       reject(new Error('Function failed to process'));
         *     }
         *   });
         * }
         *
         * doFunction().then((data) => {
         *     console.log(data);
         * }).catch((err) => {
         *     console.error(err);
         * }).finally(() => {
         *     console.log('Function processing completed');
         * });
         * ```
         */
        finally(onfinally?: FinallyPromiseHandler): IPromise<T>;
    }

    interface IRequestContext {
        status?: number;
        xhr?: XMLHttpRequest;
        request?: Request;
        response?: Response | string;
    }

    interface IResponseError {
        readonly index: number;
        readonly statusCode: number;
        readonly message: string;
    }

    interface ISample {
        /**
         * Sample rate
         */
        sampleRate: number;
        isSampledIn(envelope: ITelemetryItem): boolean;
    }

    /**
     * Before 3.1.2, payload only allow string
     * After 3.2.0,  IInternalStorageItem is accepted
     */
    interface ISendBuffer {
        /**
         * Enqueue the payload
         */
        enqueue: (payload: IInternalStorageItem) => void;
        /**
         * Returns the number of elements in the buffer
         */
        count: () => number;
        /**
         * Returns the current size of the serialized buffer
         */
        size: () => number;
        /**
         * Clears the buffer
         */
        clear: () => void;
        /**
         * Returns items stored in the buffer
         */
        getItems: () => IInternalStorageItem[];
        /**
         * Build a batch of all elements in the payload array
         */
        batchPayloads: (payload: IInternalStorageItem[]) => string;
        /**
         * Moves items to the SENT_BUFFER.
         * The buffer holds items which were sent, but we haven't received any response from the backend yet.
         */
        markAsSent: (payload: IInternalStorageItem[]) => void;
        /**
         * Removes items from the SENT_BUFFER. Should be called on successful response from the backend.
         */
        clearSent: (payload: IInternalStorageItem[]) => void;
        /**
         * Copy current buffer items to a new buffer.
         * if canUseSessionStorage is undefined, it will set to false.
         * if newLogger and newConfig are undefined, current logger and empty config will be used.
         * if canUseSessionStorage is set to true, new SessionStorageSendBuffer will be returned otherwise ArraySendBuffer will be returned.
         */
        createNew: (newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean) => ArraySendBuffer | SessionStorageSendBuffer;
    }

    interface ISenderConfig {
        /**
         * The url to which payloads will be sent
         */
        endpointUrl: string;
        /**
         * The JSON format (normal vs line delimited). True means line delimited JSON.
         */
        emitLineDelimitedJson: boolean;
        /**
         * The maximum size of a batch in bytes
         */
        maxBatchSizeInBytes: number;
        /**
         * The maximum interval allowed between calls to batchInvoke
         */
        maxBatchInterval: number;
        /**
         * The master off switch.  Do not send any data if set to TRUE
         */
        disableTelemetry: boolean;
        /**
         * Store a copy of a send buffer in the session storage
         */
        enableSessionStorageBuffer: boolean;
        /**
         * Specify the storage buffer type implementation.
         * @since 2.8.12
         */
        bufferOverride: IStorageBuffer | false;
        /**
         * Is retry handler disabled.
         * If enabled, retry on 206 (partial success), 408 (timeout), 429 (too many requests), 500 (internal server error) and 503 (service unavailable).
         */
        isRetryDisabled: boolean;
        isBeaconApiDisabled: boolean;
        /**
         * Don't use XMLHttpRequest or XDomainRequest (for IE < 9) by default instead attempt to use fetch() or sendBeacon.
         * If no other transport is available it will still use XMLHttpRequest
         */
        disableXhr: boolean;
        /**
         * If fetch keepalive is supported do not use it for sending events during unload, it may still fallback to fetch() without keepalive
         */
        onunloadDisableFetch: boolean;
        /**
         * Is beacon disabled on page unload.
         * If enabled, flush events through beaconSender.
         */
        onunloadDisableBeacon: boolean;
        /**
         * (Optional) Override the instrumentation key that this channel instance sends to
         */
        instrumentationKey: string;
        namePrefix: string;
        samplingPercentage: number;
        /**
         * (Optional) The ability for the user to provide extra headers
         */
        customHeaders: [{
            header: string;
            value: string;
        }];
        /**
         * (Optional) Provide user an option to convert undefined field to user defined value.
         */
        convertUndefined: any;
        /**
         * (Optional) The number of events that can be kept in memory before the SDK starts to drop events. By default, this is 10,000.
         */
        eventsLimitInMem: number;
        /**
         * (Optional) Enable the sender to return a promise so that manually flushing (and general sending) can wait for the request to finish.
         * Note: Enabling this may cause unhandled promise rejection errors to occur if you do not listen and handle any rejection response,
         * this *should* only be for manual flush attempts.
         * Defaults to false
         * @since 3.0.1
         */
        enableSendPromise?: boolean;
        /**
         * [Optional] The HTTP override that should be used to send requests, as an IXHROverride object.
         * By default during the unload of a page or if the event specifies that it wants to use sendBeacon() or sync fetch (with keep-alive),
         * this override will NOT be called.
         * If alwaysUseXhrOverride configuration value is set to true, the override will always be used.
         * The payload data (first argument) now also includes any configured 'timeout' (defaults to undefined) and whether you should avoid
         * creating any synchronous XHR requests 'disableXhr' (defaults to false/undefined)
         * @since 3.0.4
         */
        httpXHROverride?: IXHROverride;
        /**
         * [Optional] By default during unload (or when you specify to use sendBeacon() or sync fetch (with keep-alive) for an event) the SDK
         * ignores any provided httpXhrOverride and attempts to use sendBeacon() or fetch(with keep-alive) when they are available.
         * When this configuration option is true any provided httpXhrOverride will always be used, so any provided httpXhrOverride will
         * also need to "handle" the synchronous unload scenario.
         * @since 3.0.4
         */
        alwaysUseXhrOverride?: boolean;
        /**
         * [Optional] Disable events splitting during sendbeacon.
         * Default: false
         * @since 3.0.6
         */
        disableSendBeaconSplit?: boolean;
        /**
         * [Optional] Either an array or single value identifying the requested TransportType type that should be used.
         * This is used during initialization to identify the requested send transport, it will be ignored if a httpXHROverride is provided.
         */
        transports?: number | number[];
        /**
         * [Optional] Either an array or single value identifying the requested TransportType type(s) that should be used during unload or events
         * marked as sendBeacon. This is used during initialization to identify the requested send transport, it will be ignored if a httpXHROverride
         * is provided and alwaysUseXhrOverride is true.
         */
        unloadTransports?: number | number[];
        /**
         * (Optional) The specific error codes that will cause a retry of sending data to the backend.
         * @since 3.1.1
         */
        retryCodes?: number[];
        /**
         * (Optional) The specific max retry count for each telemetry item.
         * Default: 10
         * if it is set to 0, means no retry allowed
         * if it is set to undefined, means no limit for retry times
         * @since 3.2.0
         */
        maxRetryCnt?: number;
    }

    interface ISerializable {
        /**
         * The set of fields for a serializable object.
         * This defines the serialization order and a value of true/false
         * for each field defines whether the field is required or not.
         */
        aiDataContract: any;
    }

    /**
     * Checks if the provided value is null, undefined or contains the string value of "undefined".
     * @group Type Identity
     * @group Value Check
     * @param value - The value to check
     * @returns `true` if the value is `null` or `undefined`
     * @example
     * ```ts
     * isNullOrUndefined(null);         // true
     * isNullOrUndefined(undefined);    // true
     * isNullOrUndefined("undefined");  // true
     *
     * let value = null;
     * isNullOrUndefined(value);        // true
     * let value = undefined;
     * isNullOrUndefined(value);        // true
     *
     * isNullOrUndefined("");           // false
     * isNullOrUndefined(0);            // false
     * isNullOrUndefined(new Date());   // false
     * isNullOrUndefined(true);         // false
     * isNullOrUndefined(false);        // false
     * ```
     */
    function isNullOrUndefined(value: any): boolean;

    interface IStackDetails {
        src: string;
        obj: string[];
    }

    /**
     * Identifies a simple interface to allow you to override the storage mechanism used
     * to track unsent and unacknowledged events. When provided it must provide both
     * the get and set item functions.
     * @since 2.8.12
     */
    interface IStorageBuffer {
        /**
         * Retrieves the stored value for a given key
         */
        getItem(logger: IDiagnosticLogger, name: string): string;
        /**
         * Sets the stored value for a given key
         */
        setItem(logger: IDiagnosticLogger, name: string, data: string): boolean;
    }

    interface ITelemetryInitializerHandler extends ILegacyUnloadHook {
        remove(): void;
    }

    /**
     * Telemety item supported in Core
     */
    interface ITelemetryItem {
        /**
         * CommonSchema Version of this SDK
         */
        ver?: string;
        /**
         * Unique name of the telemetry item
         */
        name: string;
        /**
         * Timestamp when item was sent
         */
        time?: string;
        /**
         * Identifier of the resource that uniquely identifies which resource data is sent to
         */
        iKey?: string;
        /**
         * System context properties of the telemetry item, example: ip address, city etc
         */
        ext?: {
            [key: string]: any;
        };
        /**
         * System context property extensions that are not global (not in ctx)
         */
        tags?: Tags;
        /**
         * Custom data
         */
        data?: ICustomProperties;
        /**
         * Telemetry type used for part B
         */
        baseType?: string;
        /**
         * Based on schema for part B
         */
        baseData?: {
            [key: string]: any;
        };
    }

    /**
     * Configuration provided to SDK core
     */
    interface ITelemetryPlugin extends ITelemetryProcessor, IPlugin {
        /**
         * Set next extension for telemetry processing, this is not optional as plugins should use the
         * processNext() function of the passed IProcessTelemetryContext instead. It is being kept for
         * now for backward compatibility only.
         */
        setNextPlugin?: (next: ITelemetryPlugin | ITelemetryPluginChain) => void;
        /**
         * Priority of the extension
         */
        readonly priority: number;
    }

    /**
     * Configuration provided to SDK core
     */
    interface ITelemetryPluginChain extends ITelemetryProcessor {
        /**
         * Returns the underlying plugin that is being proxied for the processTelemetry call
         */
        getPlugin: () => ITelemetryPlugin;
        /**
         * Returns the next plugin
         */
        getNext: () => ITelemetryPluginChain;
        /**
         * This plugin is being unloaded and should remove any hooked events and cleanup any global/scoped values, after this
         * call the plugin will be removed from the telemetry processing chain and will no longer receive any events..
         * @param unloadCtx - The unload context to use for this call.
         * @param unloadState - The details of the unload operation
         */
        unload?: (unloadCtx: IProcessTelemetryUnloadContext, unloadState: ITelemetryUnloadState) => void;
    }

    interface ITelemetryProcessor {
        /**
         * Call back for telemetry processing before it it is sent
         * @param env - This is the current event being reported
         * @param itemCtx - This is the context for the current request, ITelemetryPlugin instances
         * can optionally use this to access the current core instance or define / pass additional information
         * to later plugins (vs appending items to the telemetry item)
         */
        processTelemetry: (env: ITelemetryItem, itemCtx?: IProcessTelemetryContext) => void;
        /**
         * The the plugin should re-evaluate configuration and update any cached configuration settings or
         * plugins. If implemented this method will be called whenever a plugin is added or removed and if
         * the configuration has bee updated.
         * @param updateCtx - This is the context that should be used during updating.
         * @param updateState - The details / state of the update process, it holds details like the current and previous configuration.
         * @returns boolean - true if the plugin has or will call updateCtx.processNext(), this allows the plugin to perform any asynchronous operations.
         */
        update?: (updateCtx: IProcessTelemetryUpdateContext, updateState: ITelemetryUpdateState) => void | boolean;
    }

    interface ITelemetryUnloadState {
        reason: TelemetryUnloadReason;
        isAsync: boolean;
        flushComplete?: boolean;
    }

    interface ITelemetryUpdateState {
        /**
         * Identifies the reason for the update notification, this is a bitwise numeric value
         */
        reason: TelemetryUpdateReason;
        /**
         * This is a new active configuration that should be used
         */
        cfg?: IConfiguration;
        /**
         * The detected changes
         */
        oldCfg?: IConfiguration;
        /**
         * If this is a configuration update this was the previous configuration that was used
         */
        newConfig?: IConfiguration;
        /**
         * Was the new config requested to be merged with the existing config
         */
        merge?: boolean;
        /**
         * This holds a collection of plugins that have been added (if the reason identifies that one or more plugins have been added)
         */
        added?: IPlugin[];
        /**
         * This holds a collection of plugins that have been removed (if the reason identifies that one or more plugins have been removed)
         */
        removed?: IPlugin[];
    }

    /**
     * Identifies frequency of items sent
     * Default: send data on 28th every 3 month each year
     */
    interface IThrottleInterval {
        /**
         * Identifies month interval that items can be sent
         * For example, if it is set to 2 and start date is in Jan, items will be sent out every two months (Jan, March, May etc.)
         * If both monthInterval and dayInterval are undefined, it will be set to 3
         */
        monthInterval?: number;
        /**
         * Identifies days Interval from start date that items can be sent
         * Default: undefined
         */
        dayInterval?: number;
        /**
         * Identifies days within each month that items can be sent
         * If both monthInterval and dayInterval are undefined, it will be default to [28]
         */
        daysOfMonth?: number[];
    }

    /**
     * Identifies limit number/percentage of items sent per time
     * If both are provided, minimum number between the two will be used
     */
    interface IThrottleLimit {
        /**
         * Identifies sampling percentage of items per time
         * The percentage is set to 4 decimal places, for example: 1 means 0.0001%
         * Default: 100 (0.01%)
         */
        samplingRate?: number;
        /**
         * Identifies limit number of items per time
         * Default: 1
         */
        maxSendNumber?: number;
    }

    /**
     * Identifies basic config
     */
    interface IThrottleMgrConfig {
        /**
         * Identifies if throttle is disabled
         * Default: false
         */
        disabled?: boolean;
        /**
         * Identifies limit number/percentage of items sent per time
         * Default: sampling percentage 0.01% with one item sent per time
         */
        limit?: IThrottleLimit;
        /**
         * Identifies frequency of items sent
         * Default: send data on 28th every 3 month each year
         */
        interval?: IThrottleInterval;
    }

    /**
     * A Timer handler which is returned from {@link scheduleTimeout} which contains functions to
     * cancel or restart (refresh) the timeout function.
     *
     * @since 0.4.4
     * @group Timer
     */
    interface ITimerHandler {
        /**
         * Cancels a timeout that was previously scheduled, after calling this function any previously
         * scheduled timer will not execute.
         * @example
         * ```ts
         * let theTimer = scheduleTimeout(...);
         * theTimer.cancel();
         * ```
         */
        cancel(): void;
        /**
         * Reschedules the timer to call its callback at the previously specified duration
         * adjusted to the current time. This is useful for refreshing a timer without allocating
         * a new JavaScript object.
         *
         * Using this on a timer that has already called its callback will reactivate the timer.
         * Calling on a timer that has not yet executed will just reschedule the current timer.
         * @example
         * ```ts
         * let theTimer = scheduleTimeout(...);
         * // The timer will be restarted (if already executed) or rescheduled (if it has not yet executed)
         * theTimer.refresh();
         * ```
         */
        refresh(): ITimerHandler;
        /**
         * When called, requests that the event loop not exit so long when the ITimerHandler is active.
         * Calling timer.ref() multiple times will have no effect. By default, all ITimerHandler objects
         * will create "ref'ed" instances, making it normally unnecessary to call timer.ref() unless
         * timer.unref() had been called previously.
         * @since 0.7.0
         * @returns the ITimerHandler instance
         * @example
         * ```ts
         * let theTimer = createTimeout(...);
         *
         * // Make sure the timer is referenced (the default) so that the runtime (Node) does not terminate
         * // if there is a waiting referenced timer.
         * theTimer.ref();
         * ```
         */
        ref(): this;
        /**
         * When called, the any active ITimerHandler instance will not require the event loop to remain
         * active (Node.js). If there is no other activity keeping the event loop running, the process may
         * exit before the ITimerHandler instance callback is invoked. Calling timer.unref() multiple times
         * will have no effect.
         * @since 0.7.0
         * @returns the ITimerHandler instance
         * @example
         * ```ts
         * let theTimer = createTimeout(...);
         *
         * // Unreference the timer so that the runtime (Node) may terminate if nothing else is running.
         * theTimer.unref();
         * ```
         */
        unref(): this;
        /**
         * If true, any running referenced `ITimerHandler` instance will keep the Node.js event loop active.
         * @since 0.7.0
         * @example
         * ```ts
         * let theTimer = createTimeout(...);
         *
         * // Unreference the timer so that the runtime (Node) may terminate if nothing else is running.
         * theTimer.unref();
         * let hasRef = theTimer.hasRef(); // false
         *
         * theTimer.ref();
         * hasRef = theTimer.hasRef(); // true
         * ```
         */
        hasRef(): boolean;
        /**
         * Gets or Sets a flag indicating if the underlying timer is currently enabled and running.
         * Setting the enabled flag to the same as it's current value has no effect, setting to `true`
         * when already `true` will not {@link ITimerHandler.refresh | refresh}() the timer.
         * And setting to 'false` will {@link ITimerHandler.cancel | cancel}() the timer.
         * @since 0.8.1
         * @example
         * ```ts
         * let theTimer = createTimeout(...);
         *
         * // Check if enabled
         * theTimer.enabled; // false
         *
         * // Start the timer
         * theTimer.enabled = true;     // Same as calling refresh()
         * theTimer.enabled; //true
         *
         * // Has no effect as it's already running
         * theTimer.enabled = true;
         *
         * // Will refresh / restart the time
         * theTimer.refresh()
         *
         * let theTimer = scheduleTimeout(...);
         *
         * // Check if enabled
         * theTimer.enabled; // true
         * ```
         */
        enabled: boolean;
    }

    interface ITraceTelemetry extends IPartC {
        /**
         * @description A message string
         * @type {string}
         * @memberof ITraceTelemetry
         */
        message: string;
        /**
         * @description Severity level of the logging message used for filtering in the portal
         * @type {SeverityLevel}
         * @memberof ITraceTelemetry
         */
        severityLevel?: SeverityLevel;
        /**
         * @description custom defiend iKey
         * @type {SeverityLevel}
         * @memberof ITraceTelemetry
         */
        iKey?: string;
    }

    /**
     * An interface which provides automatic removal during unloading of the component
     */
    interface IUnloadHook {
        /**
         * Self remove the referenced component
         */
        rm: () => void;
    }

    /**
     * Interface which identifiesAdd this hook so that it is automatically removed during unloading
     * @param hooks - The single hook or an array of IInstrumentHook objects
     */
    interface IUnloadHookContainer {
        add: (hooks: IUnloadHook | IUnloadHook[] | Iterator<IUnloadHook> | ILegacyUnloadHook | ILegacyUnloadHook[] | Iterator<ILegacyUnloadHook>) => void;
        run: (logger?: IDiagnosticLogger) => void;
    }

    interface IWatchDetails<T = IConfiguration> {
        /**
         * The current config object
         */
        cfg: T;
        /**
         * Set the value against the provided config/name with the value, the property
         * will be converted to be dynamic (if not already) as long as the provided config
         * is already a tracked dynamic object.
         * @throws TypeError if the provided config is not a monitored dynamic config
         */
        set: <C, V>(theConfig: C, name: string, value: V) => V;
        /**
         * Set default values for the config if not present.
         * @param theConfig - The configuration object to set default on (if missing)
         * @param defaultValues - The default values to apply to the config
         */
        setDf: <C>(theConfig: C, defaultValues: IConfigDefaults<C>) => C;
        /**
         * Set this named property of the target as referenced, which will cause any object or array instance
         * to be updated in-place rather than being entirely replaced. All other values will continue to be replaced.
         * @returns The referenced properties current value
         */
        ref: <C, V = any>(target: C, name: string) => V;
        /**
         * Set this named property of the target as read-only, which will block this single named property from
         * ever being changed for the target instance.
         * This does NOT freeze or seal the instance, it just stops the direct re-assignment of the named property,
         * if the value is a non-primitive (ie. an object or array) it's properties will still be mutable.
         * @returns The referenced properties current value
         */
        rdOnly: <C, V = any>(target: C, name: string) => V;
    }

    interface IXDomainRequest extends XMLHttpRequestEventTarget {
        readonly responseText: string;
        send(payload: string): void;
        open(method: string, url: string): void;
        timeout: number;
        contentType: string;
        addEventListener(type: "error", listener: (ev: ErrorEvent) => any, useCapture?: boolean): void;
        addEventListener(type: "load" | "timeout", listener: (ev: Event) => any, useCapture?: boolean): void;
        addEventListener(type: "progress", listener: (ev: ProgressEvent) => any, useCapture?: boolean): void;
    }

    /**
     * The IXHROverride interface overrides the way HTTP requests are sent.
     */
    interface IXHROverride {
        sendPOST: SendPOSTFunction;
    }

    const LoggingSeverity: EnumValue<typeof eLoggingSeverity>;

    type LoggingSeverity = number | eLoggingSeverity;

    /**
     * this is the callback that will be called when the network status changes
     * @param onlineState this is the current network running state
     */
    type OfflineCallback = (onlineState: IOfflineState) => void;

    type OnCompleteCallback = (status: number, headers: {
        [headerName: string]: string;
    }, response?: string) => void;

    /**
     * Creates proxy functions on the target which internally will call the source version with all arguments passed to the target method.
     *
     * @param target - The target object to be assigned with the source properties and functions
     * @param source - The source object which will be assigned / called by setting / calling the targets proxies
     * @param functionsToProxy - An array of function names that will be proxied on the target
     * @param overwriteTarget - If false this will not replace any pre-existing name otherwise (the default) it will overwrite any existing name
     */
    function proxyFunctions<T, S>(target: T, source: S | (() => S), functionsToProxy: (keyof S)[], overwriteTarget?: boolean): T;

    /**
     * This defines the handler function for when a promise is rejected.
     * @param value - This is the value passed as part of resolving the Promise
     * @return This may return a value, another Promise or void. @see {@link IPromise.then} for how the value is handled.
     */
    type RejectedPromiseHandler<T = never> = (((reason: any) => T | IPromise<T> | PromiseLike<T>) | undefined | null);

    /**
     * This defines the handler function for when a promise is resolved.
     * @param value - This is the value passed as part of resolving the Promise
     * @return This may return a value, another Promise or void. @see {@link IPromise.then} for how the value is handled.
     */
    type ResolvedPromiseHandler<T, TResult1 = T> = (((value: T) => TResult1 | IPromise<TResult1> | PromiseLike<TResult1>) | undefined | null);

    class Sender extends BaseTelemetryPlugin implements IChannelControls {
        static constructEnvelope(orig: ITelemetryItem, iKey: string, logger: IDiagnosticLogger, convertUndefined?: any): IEnvelope;
        readonly priority: number;
        readonly identifier: string;
        /**
         * The configuration for this sender instance
         */
        readonly _senderConfig: ISenderConfig;
        /**
         * A method which will cause data to be send to the url
         */
        _sender: SenderFunction;
        /**
         * A send buffer object
         */
        _buffer: ISendBuffer;
        /**
         * AppId of this component parsed from some backend response.
         */
        _appId: string;
        protected _sample: ISample;
        constructor();
        /**
         * Pause the sending (transmission) of events, this will cause all events to be batched only until the maximum limits are
         * hit at which point new events are dropped. Will also cause events to NOT be sent during page unload, so if Session storage
         * is disabled events will be lost.
         * SessionStorage Limit is 2000 events, In-Memory (Array) Storage is 10,000 events (can be configured via the eventsLimitInMem).
         */
        pause(): void;
        /**
         * Resume the sending (transmission) of events, this will restart the timer and any batched events will be sent using the normal
         * send interval.
         */
        resume(): void;
        /**
         * Flush to send data immediately; channel should default to sending data asynchronously. If executing asynchronously (the default) and
         * you DO NOT pass a callback function then a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * will be returned which will resolve once the flush is complete. The actual implementation of the `IPromise`
         * will be a native Promise (if supported) or the default as supplied by [ts-async library](https://github.com/nevware21/ts-async)
         * @param async - send data asynchronously when true
         * @param callBack - if specified, notify caller when send is complete, the channel should return true to indicate to the caller that it will be called.
         * If the caller doesn't return true the caller should assume that it may never be called.
         * @param sendReason - specify the reason that you are calling "flush" defaults to ManualFlush (1) if not specified
         * @returns - If a callback is provided `true` to indicate that callback will be called after the flush is complete otherwise the caller
         * should assume that any provided callback will never be called, Nothing or if occurring asynchronously a
         * [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) which will be resolved once the unload is complete,
         * the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) will only be returned when no callback is provided
         * and async is true.
         */
        flush(async?: boolean, callBack?: (flushComplete?: boolean) => void): void | IPromise<boolean>;
        /**
         * Flush the batched events synchronously (if possible -- based on configuration).
         * Will not flush if the Send has been paused.
         */
        onunloadFlush(): void;
        initialize(config: IConfiguration & IConfig, core: IAppInsightsCore, extensions: IPlugin[], pluginChain?: ITelemetryPluginChain): void;
        processTelemetry(telemetryItem: ITelemetryItem, itemCtx?: IProcessTelemetryContext): void;
        /**
         * xhr state changes
         * @deprecated
         * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
         */
        _xhrReadyStateChange(xhr: XMLHttpRequest, payload: string[] | IInternalStorageItem[], countOfItemsInPayload: number): void;
        /**
         * Trigger the immediate send of buffered data; If executing asynchronously (the default) this may (not required) return
         * an [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html) that will resolve once the
         * send is complete. The actual implementation of the `IPromise` will be a native Promise (if supported) or the default
         * as supplied by [ts-async library](https://github.com/nevware21/ts-async)
         * @param async - Indicates if the events should be sent asynchronously
         * @param forcedSender - {SenderFunction} - Indicates the forcedSender, undefined if not passed
         * @returns - Nothing or optionally, if occurring asynchronously a [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * which will be resolved (or reject) once the send is complete, the [IPromise](https://nevware21.github.io/ts-async/typedoc/interfaces/IPromise.html)
         * should only be returned when async is true.
         */
        triggerSend(async?: boolean, forcedSender?: SenderFunction, sendReason?: SendRequestReason): void | IPromise<boolean>;
        /**
         * error handler
         * @Internal
         * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
         */
        _onError(payload: string[] | IInternalStorageItem[], message: string, event?: ErrorEvent): void;
        /**
         * partial success handler
         * @Internal
         * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
         */
        _onPartialSuccess(payload: string[] | IInternalStorageItem[], results: IBackendResponse): void;
        /**
         * success handler
         * @Internal
         * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
         */
        _onSuccess(payload: string[] | IInternalStorageItem[], countOfItemsInPayload: number): void;
        /**
         * xdr state changes
         * @deprecated
         * since version 3.2.0, if the payload is string[], this function is no-op (string[] is only used for backwards Compatibility)
         */
        _xdrOnLoad(xdr: IXDomainRequest, payload: string[] | IInternalStorageItem[]): void;
        /**
         * Add header to request
         * @param name - Header name.
         * @param value - Header value.
         */
        addHeader(name: string, value: string): void;
        /**
         * Check if there are no active requests being sent.
         * @returns True if idle, false otherwise.
         */
        isCompletelyIdle(): boolean;
        /**
         * Get Offline Serializer support
         * @returns internal Offline Serializer object
         */
        getOfflineSupport(): IInternalOfflineSupport;
        /**
         * Get Offline listener
         * @returns offlineListener
         * @since 3.3.4
         */
        getOfflineListener(): IOfflineListener;
    }

    type SenderFunction = (payload: string[] | IInternalStorageItem[], isAsync: boolean) => void | IPromise<boolean>;

    /**
     * SendPOSTFunction type defines how an HTTP POST request is sent to an ingestion server
     * @param payload - The payload object that should be sent, contains the url, bytes/string and headers for the request
     * @param oncomplete - The function to call once the request has completed whether a success, failure or timeout
     * @param sync - A boolean flag indicating whether the request should be sent as a synchronous request.
     */
    type SendPOSTFunction = (payload: IPayloadData, oncomplete: OnCompleteCallback, sync?: boolean) => void | IPromise<boolean>;

    /**
     * The EventsDiscardedReason enumeration contains a set of values that specify the reason for discarding an event.
     */
    const enum SendRequestReason {
        /**
         * No specific reason was specified
         */
        Undefined = 0,
        /**
         * Events are being sent based on the normal event schedule / timer.
         */
        NormalSchedule = 1,
        /**
         * A manual flush request was received
         */
        ManualFlush = 1,
        /**
         * Unload event is being processed
         */
        Unload = 2,
        /**
         * The event(s) being sent are sync events
         */
        SyncEvent = 3,
        /**
         * The Channel was resumed
         */
        Resumed = 4,
        /**
         * The event(s) being sent as a retry
         */
        Retry = 5,
        /**
         * The SDK is unloading
         */
        SdkUnload = 6,
        /**
         * Maximum batch size would be exceeded
         */
        MaxBatchSize = 10,
        /**
         * The Maximum number of events have already been queued
         */
        MaxQueuedEvents = 20
    }

    class SessionStorageSendBuffer extends BaseSendBuffer implements ISendBuffer {
        static VERSION: string;
        static BUFFER_KEY: string;
        static SENT_BUFFER_KEY: string;
        static MAX_BUFFER_SIZE: number;
        constructor(logger: IDiagnosticLogger, config: ISenderConfig);
        enqueue(payload: IInternalStorageItem): void;
        clear(): void;
        markAsSent(payload: IInternalStorageItem[]): void;
        clearSent(payload: IInternalStorageItem[]): void;
        createNew(newLogger?: IDiagnosticLogger, newConfig?: ISenderConfig, canUseSessionStorage?: boolean): ArraySendBuffer | SessionStorageSendBuffer;
    }

    /**
     * Defines the level of severity for the event.
     */
    const SeverityLevel: EnumValue<typeof eSeverityLevel>;

    type SeverityLevel = number | eSeverityLevel;

    interface Tags {
        [key: string]: any;
    }

    type TelemetryInitializerFunction = <T extends ITelemetryItem>(item: T) => boolean | void;

    /**
     * The TelemetryUnloadReason enumeration contains the possible reasons for why a plugin is being unloaded / torndown().
     */
    const enum TelemetryUnloadReason {
        /**
         * Teardown has been called without any context.
         */
        ManualTeardown = 0,
        /**
         * Just this plugin is being removed
         */
        PluginUnload = 1,
        /**
         * This instance of the plugin is being removed and replaced
         */
        PluginReplace = 2,
        /**
         * The entire SDK is being unloaded
         */
        SdkUnload = 50
    }

    /**
     * The TelemetryUpdateReason enumeration contains a set of bit-wise values that specify the reason for update request.
     */
    const enum TelemetryUpdateReason {
        /**
         * Unknown.
         */
        Unknown = 0,
        /**
         * The configuration has ben updated or changed
         */
        ConfigurationChanged = 1,
        /**
         * One or more plugins have been added
         */
        PluginAdded = 16,
        /**
         * One or more plugins have been removed
         */
        PluginRemoved = 32
    }

    /**
     * Throw an error exception with the specified optional message
     * @group Error
     * @param message
     */
    function throwError(message?: string): never;

    type UnloadHandler = (itemCtx: IProcessTelemetryUnloadContext, unloadState: ITelemetryUnloadState) => void;

    type WatcherFunction<T = IConfiguration> = (details: IWatchDetails<T>) => void;

}