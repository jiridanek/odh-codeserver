# Installation
> `npm install --save @types/markdown-it`

# Summary
This package contains type definitions for markdown-it (https://github.com/markdown-it/markdown-it).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/markdown-it

Additional Details
 * Last updated: Tue, 29 Nov 2016 22:40:06 GMT
 * File structure: ProperModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: MarkdownIt

# Credits
These definitions were written by York Yao <https://github.com/plantain-00/>.
