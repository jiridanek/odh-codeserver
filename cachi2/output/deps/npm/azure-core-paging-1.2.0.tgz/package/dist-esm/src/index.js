// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
import "@azure/core-asynciterator-polyfill";
export * from "./models";
export * from "./getPagedAsyncIterator";
//# sourceMappingURL=index.js.map