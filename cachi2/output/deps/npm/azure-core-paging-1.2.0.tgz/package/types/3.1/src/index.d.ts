import "@azure/core-asynciterator-polyfill";
export * from "./models";
export * from "./getPagedAsyncIterator";
//# sourceMappingURL=index.d.ts.map
