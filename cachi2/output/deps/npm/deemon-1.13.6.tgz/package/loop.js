const interval = setInterval(() => {
  console.log(new Date);
}, 100);
setTimeout(() => clearInterval(interval), 2000);