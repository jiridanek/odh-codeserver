#!/usr/bin/env node
require('./main.js');