"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createServer = createServer;
exports.createConnection = createConnection;
exports.spawnCommand = spawnCommand;
var path = require("path");
var net = require("net");
var os = require("os");
var fs = require("fs");
var cp = require("child_process");
var readline = require("readline");
var crypto = require("crypto");
var treekill = require("tree-kill");
var bl_1 = require("bl");
var KILL = 0;
var TALK = 1;
function getIPCHandle(command) {
    var scope = crypto
        .createHash("md5")
        .update(command.path)
        .update(command.args.toString())
        .update(command.cwd)
        .digest("hex");
    if (process.platform === "win32") {
        return "\\\\.\\pipe\\daemon-".concat(scope);
    }
    else {
        return path.join(process.env["XDG_RUNTIME_DIR"] || os.tmpdir(), "daemon-".concat(scope, ".sock"));
    }
}
function createServer(handle) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (c, e) {
                    var server = net.createServer();
                    server.on("error", e);
                    server.listen(handle, function () {
                        server.removeListener("error", e);
                        c(server);
                    });
                })];
        });
    });
}
function createConnection(handle) {
    return new Promise(function (c, e) {
        var socket = net.createConnection(handle, function () {
            socket.removeListener("error", e);
            c(socket);
        });
        socket.once("error", e);
    });
}
function spawnCommand(server, command, options) {
    var clients = new Set();
    var bl = new bl_1.BufferListStream();
    var child = cp.spawn(command.path, command.args, {
        shell: process.platform === "win32",
        windowsHide: true,
    });
    var onData = function (data) {
        bl.append(data);
        if (bl.length > 100000000) {
            // buffer caps at 100MB
            bl.consume(bl.length - 100000000);
        }
    };
    child.stdout.on("data", onData);
    child.stderr.on("data", onData);
    var justSpawned = true;
    setTimeout(function () { return justSpawned = false; }, 210);
    var childExitCode;
    var childSignal;
    server.on("connection", function (socket) {
        socket.on("data", function (buffer) {
            var command = buffer[0];
            if (command === KILL) {
                treekill(child.pid);
            }
            else if (command === TALK) {
                var bufferStream = bl.duplicate();
                bufferStream.pipe(socket, { end: false });
                bufferStream.on("end", function () {
                    var e_1, _a;
                    if (childExitCode !== undefined || childSignal !== undefined) {
                        var exitCode_1 = childExitCode !== null && childExitCode !== void 0 ? childExitCode : 1;
                        var totalCount_1 = 1;
                        var doneCount_1 = 0;
                        var cb = function () {
                            if (++doneCount_1 === totalCount_1) {
                                server.close();
                                process.exit(exitCode_1);
                            }
                        };
                        try {
                            for (var clients_1 = __values(clients), clients_1_1 = clients_1.next(); !clients_1_1.done; clients_1_1 = clients_1.next()) {
                                var client = clients_1_1.value;
                                totalCount_1++;
                                client.end(new Uint8Array([exitCode_1]), cb);
                            }
                        }
                        catch (e_1_1) { e_1 = { error: e_1_1 }; }
                        finally {
                            try {
                                if (clients_1_1 && !clients_1_1.done && (_a = clients_1.return)) _a.call(clients_1);
                            }
                            finally { if (e_1) throw e_1.error; }
                        }
                        socket.write("[deemon] Daemon was stopped when client attached (exit code ".concat(childExitCode, ", signal ").concat(childSignal, ").\n"));
                        socket.end(new Uint8Array([exitCode_1]), cb);
                        return;
                    }
                    child.stdout.pipe(socket, { end: false });
                    child.stderr.pipe(socket, { end: false });
                    clients.add(socket);
                    if (justSpawned) {
                        setTimeout(function () { return socket.write("[deemon] Spawned build daemon. Press Ctrl-C to detach, Ctrl-D to kill.\n"); }, 200);
                        justSpawned = false;
                    }
                    else {
                        setTimeout(function () { return socket.write("[deemon] Attached to running build daemon. Press Ctrl-C to detach, Ctrl-D to kill.\n"); }, 0);
                    }
                });
            }
        });
        socket.on("close", function () {
            if (clients.has(socket)) {
                child.stdout.unpipe(socket);
                child.stderr.unpipe(socket);
                clients.delete(socket);
            }
        });
    });
    child.on("close", function (code, signal) {
        var e_2, _a;
        if (options.wait && clients.size === 0) {
            childExitCode = code;
            childSignal = signal;
            return;
        }
        try {
            for (var clients_2 = __values(clients), clients_2_1 = clients_2.next(); !clients_2_1.done; clients_2_1 = clients_2.next()) {
                var client = clients_2_1.value;
                client.end(new Uint8Array([code !== null && code !== void 0 ? code : 1]));
                client.destroy();
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (clients_2_1 && !clients_2_1.done && (_a = clients_2.return)) _a.call(clients_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        server.close();
        process.exit(code !== null && code !== void 0 ? code : 1);
    });
}
function spawnDaemon(command, options) {
    var args = [process.argv[1], '--daemon'];
    if (options.wait) {
        args.push('--wait');
    }
    args.push.apply(args, __spreadArray([command.path], __read(command.args), false));
    cp.spawn(process.execPath, args, { detached: true, stdio: "ignore" });
}
function connect(command, handle, options) {
    return __awaiter(this, void 0, void 0, function () {
        var err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 9]);
                    return [4 /*yield*/, createConnection(handle)];
                case 1: return [2 /*return*/, _a.sent()];
                case 2:
                    err_1 = _a.sent();
                    if (!(options.attach && (err_1.code === "ENOENT" || err_1.code === "ECONNREFUSED"))) return [3 /*break*/, 3];
                    console.error("[deemon] No daemon running.");
                    process.exit(1);
                    return [3 /*break*/, 6];
                case 3:
                    if (!(err_1.code === "ECONNREFUSED")) return [3 /*break*/, 5];
                    return [4 /*yield*/, fs.promises.unlink(handle)];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 6];
                case 5:
                    if (err_1.code !== "ENOENT") {
                        throw err_1;
                    }
                    _a.label = 6;
                case 6:
                    spawnDaemon(command, options);
                    return [4 /*yield*/, new Promise(function (c) { return setTimeout(c, 200); })];
                case 7:
                    _a.sent();
                    return [4 /*yield*/, createConnection(handle)];
                case 8: return [2 /*return*/, _a.sent()];
                case 9: return [2 /*return*/];
            }
        });
    });
}
function main(command, options) {
    return __awaiter(this, void 0, void 0, function () {
        var handle, server, socket, lastByte, lastByteTimer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    handle = getIPCHandle(command);
                    if (!options.daemon) return [3 /*break*/, 2];
                    return [4 /*yield*/, createServer(handle)];
                case 1:
                    server = _a.sent();
                    return [2 /*return*/, spawnCommand(server, command, options)];
                case 2:
                    if (options.detach) {
                        spawnDaemon(command, options);
                        console.log("[deemon] Detached from build daemon.");
                        if (options.wait) {
                            console.log("[deemon] Daemon will wait for a client to connect before exiting.");
                        }
                        process.exit(0);
                    }
                    return [4 /*yield*/, connect(command, handle, options)];
                case 3:
                    socket = _a.sent();
                    if (options.kill) {
                        socket.write(new Uint8Array([KILL]));
                        return [2 /*return*/];
                    }
                    if (!options.restart) return [3 /*break*/, 6];
                    socket.write(new Uint8Array([KILL]));
                    return [4 /*yield*/, new Promise(function (c) { return setTimeout(c, 500); })];
                case 4:
                    _a.sent();
                    return [4 /*yield*/, connect(command, handle, options)];
                case 5:
                    socket = _a.sent();
                    _a.label = 6;
                case 6:
                    socket.write(new Uint8Array([TALK]));
                    readline.emitKeypressEvents(process.stdin);
                    if (process.stdin.isTTY && process.stdin.setRawMode) {
                        process.stdin.setRawMode(true);
                    }
                    process.stdin.on("keypress", function (code) {
                        if (code === "\u0003") {
                            // ctrl c
                            console.log("[deemon] Detached from build daemon.");
                            process.exit(0);
                        }
                        else if (code === "\u0004") {
                            // ctrl d
                            console.log("[deemon] Killed build daemon.");
                            socket.write(new Uint8Array([KILL]));
                            process.exit(0);
                        }
                    });
                    lastByte = null;
                    lastByteTimer = null;
                    socket.on('data', function (data) {
                        clearTimeout(lastByteTimer);
                        if (data.length === 0)
                            return;
                        if (lastByte) {
                            process.stdout.write(lastByte);
                        }
                        lastByte = data.slice(data.length - 1);
                        if (data.length > 1) {
                            process.stdout.write(data.slice(0, data.length - 1));
                            lastByteTimer = setTimeout(function () { return process.stdout.write(lastByte); }, 100);
                        }
                    });
                    socket.on("close", function () {
                        var code = lastByte ? lastByte[0] : 0;
                        console.log("[deemon] Build daemon exited with code", code);
                        process.exit(code);
                    });
                    return [2 /*return*/];
            }
        });
    });
}
if (process.argv.length < 3) {
    console.error("Usage: npx deemon [OPTS] COMMAND [...ARGS]\nOptions:\n  --kill     Kill the currently running daemon\n  --detach   Detach the daemon\n  --wait     Wait for a client to connect before exiting the daemon (only valid with --detach)\n  --attach   Attach to the currently running daemon, exiting if it doesn't exist\n  --restart  Restart the daemon");
    process.exit(1);
}
var commandPathIndex = process.argv.findIndex(function (arg, index) { return !/^--/.test(arg) && index >= 2; });
var _a = __read(process.argv.slice(commandPathIndex)), commandPath = _a[0], commandArgs = _a.slice(1);
var command = {
    path: commandPath,
    args: commandArgs,
    cwd: process.cwd(),
};
var optionsArgv = process.argv.slice(2, commandPathIndex);
var options = {
    daemon: optionsArgv.some(function (arg) { return arg === "--daemon"; }),
    kill: optionsArgv.some(function (arg) { return arg === "--kill"; }),
    restart: optionsArgv.some(function (arg) { return arg === "--restart"; }),
    detach: optionsArgv.some(function (arg) { return arg === "--detach"; }),
    wait: optionsArgv.some(function (arg) { return arg === "--wait"; }),
    attach: optionsArgv.some(function (arg) { return arg === "--attach"; })
};
main(command, options).catch(function (err) {
    console.error(err);
    process.exit(1);
});
