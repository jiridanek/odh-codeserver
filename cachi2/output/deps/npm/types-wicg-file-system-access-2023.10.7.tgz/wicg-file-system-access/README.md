# Installation
> `npm install --save @types/wicg-file-system-access`

# Summary
This package contains type definitions for wicg-file-system-access (https://github.com/WICG/file-system-access).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/wicg-file-system-access.

### Additional Details
 * Last updated: Fri, 03 Oct 2025 23:32:18 GMT
 * Dependencies: none

# Credits
These definitions were written by [Ingvar Stepanyan](https://github.com/RReverser).
