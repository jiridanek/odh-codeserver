"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IstanbulCoverageContext = exports.IstanbulMissingCoverageError = void 0;
const fs_1 = require("fs");
const path_1 = require("path");
const vscode = require("vscode");
const FINAL_COVERAGE_FILE_NAME = 'coverage-final.json';
class IstanbulMissingCoverageError extends Error {
    constructor(dir, err) {
        super(`Could not read ${FINAL_COVERAGE_FILE_NAME} in ${dir}. Make sure the test was run with "json" coverage enabled: ${err}`);
    }
}
exports.IstanbulMissingCoverageError = IstanbulMissingCoverageError;
/**
 * Handles mapping
 */
class IstanbulCoverageContext {
    constructor(defaultOptions) {
        this.defaultOptions = {
            removeCoverageDataAtEndOfRun: true,
            booleanCounts: false,
        };
        /**
         * Assignable to vscode.TestRunProfile.loadDetailedCoverage
         */
        this.loadDetailedCoverage = async (_testRun, file) => {
            if (!(file instanceof IstanbulFileCoverage)) {
                return [];
            }
            const opts = file.options;
            const details = [];
            const todo = [];
            for (const [key, branch] of Object.entries(file.original.branchMap)) {
                todo.push(Promise.all([
                    mapRange(opts, file.compiledUri, branch.loc),
                    ...branch.locations.map((l) => l.start.line !== undefined
                        ? mapRange(opts, file.compiledUri, l)
                        : // the implicit "else" case of 'if' statements are emitted as a
                            // branch with no range; use a zero-length range of the conditional
                            // end location to represent this.
                            mapRange(opts, file.compiledUri, { start: branch.loc.end, end: branch.loc.end })),
                ]).then(([loc, ...branches]) => {
                    if (!loc || branches.some((b) => !b)) {
                        // no-op
                    }
                    else {
                        let hits = 0;
                        const branchCoverage = [];
                        for (const [i, location] of branches.entries()) {
                            const branchHit = file.original.b[key][i];
                            hits += branchHit;
                            branchCoverage.push(new vscode.BranchCoverage(mapCount(opts, branchHit), location, branch.type === 'if' ? (i === 0 ? 'if' : 'else') : undefined));
                        }
                        details.push(new vscode.StatementCoverage(mapCount(opts, hits), loc, branchCoverage));
                    }
                }));
            }
            for (const [key, stmt] of Object.entries(file.original.statementMap)) {
                todo.push(mapRange(opts, file.compiledUri, stmt).then((loc) => {
                    if (loc) {
                        details.push(new vscode.StatementCoverage(mapCount(opts, file.original.s[key]), loc));
                    }
                }));
            }
            for (const [key, stmt] of Object.entries(file.original.fnMap)) {
                todo.push(mapRange(opts, file.compiledUri, stmt.loc).then((loc) => {
                    if (loc) {
                        details.push(new vscode.DeclarationCoverage(stmt.name, mapCount(opts, file.original.f[key]), loc));
                    }
                }));
            }
            await Promise.all(todo);
            return details;
        };
        Object.assign(this.defaultOptions, defaultOptions);
    }
    /**
     * Applies coverage written out to the given directory to the test run.
     * It expects Istanbul to have generated a "json" coverage format with the
     * directory containing a `coverage-final.json` file.
     * @throws IstanbulMissingCoverageError if the coverage file could not be read.
     */
    async apply(run, coverageDir, opts) {
        let coverage;
        try {
            coverage = JSON.parse(await fs_1.promises.readFile((0, path_1.join)(coverageDir, FINAL_COVERAGE_FILE_NAME), 'utf-8'));
        }
        catch (e) {
            throw new IstanbulMissingCoverageError(coverageDir, e);
        }
        const options = { ...this.defaultOptions, ...opts };
        if (options.removeCoverageDataAtEndOfRun) {
            const l = run.onDidDispose(() => {
                l.dispose();
                fs_1.promises.rm(coverageDir, { recursive: true }).catch(() => {
                    /* ignored */
                });
            });
        }
        return this.applyJson(run, coverage, options);
    }
    /**
     * Applies coverage from the Istanbul file format to the run.
     */
    async applyJson(run, files, opts) {
        const options = { ...this.defaultOptions, ...opts };
        await Promise.all(Object.values(files).map(async (entry) => {
            const compiledUri = vscode.Uri.file(entry.path);
            const originalUri = (await options.mapFileUri?.(compiledUri)) || compiledUri;
            run.addCoverage(new IstanbulFileCoverage(originalUri || compiledUri, entry, compiledUri, options));
        }));
    }
}
exports.IstanbulCoverageContext = IstanbulCoverageContext;
const mapRange = async (opts, uri, range) => {
    const [start, end] = await Promise.all([
        mapLocation(opts, uri, range.start),
        mapLocation(opts, uri, range.end),
    ]);
    if (start && end) {
        return new vscode.Range(start.range.start, end.range.end);
    }
    const some = start || end;
    if (some) {
        return some.range;
    }
    return undefined;
};
const mapLocation = async (opts, uri, location) => {
    const position = new vscode.Position(location.line - 1, location.column);
    // note: we intentionally don't await mapLocation here because we want to
    // propagate if it resolves to undefined.
    return opts.mapLocation?.(uri, position) || new vscode.Location(uri, position);
};
const mapCount = (opts, n) => (opts.booleanCounts ? n > 0 : n);
class IstanbulFileCoverage extends vscode.FileCoverage {
    constructor(uri, original, compiledUri, options) {
        super(uri, parseToSum(original.s), parseToSum(original.b), parseToSum(original.f));
        this.original = original;
        this.compiledUri = compiledUri;
        this.options = options;
    }
}
const parseToSum = (p) => {
    let covered = 0;
    let total = 0;
    for (const count of Object.values(p)) {
        if (count instanceof Array) {
            for (const c of count) {
                covered += c ? 1 : 0;
                total++;
            }
        }
        else {
            covered += count ? 1 : 0;
            total++;
        }
    }
    return new vscode.TestCoverageCount(covered, total);
};
