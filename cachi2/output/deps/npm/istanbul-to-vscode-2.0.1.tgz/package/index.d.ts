import { FileCoverageData } from 'istanbul-lib-coverage';
import * as vscode from 'vscode';
export interface IIstanbulCoverageOptions {
    /**
     * Whether coverage data should be removed when the run is disposed.
     * Defaults to true.
     */
    removeCoverageDataAtEndOfRun?: boolean;
    /**
     * If set to true, the executions are set as boolean (covered or not covered)
     * instead of counts. Tools that don't support fine-grained counts should
     * set this to true.
     */
    booleanCounts?: boolean;
    /**
     * Called to transform a URI seen in the coverage report. You can for example
     * apply sourcemap transformations here.
     */
    mapFileUri?(uri: vscode.Uri): Promise<vscode.Uri | undefined>;
    /**
     * Called to transform a location seen in the coverage report. You can for
     * example apply sourcemap transformations here.
     */
    mapLocation?(uri: vscode.Uri, position: vscode.Position): Promise<vscode.Location | undefined>;
}
export declare class IstanbulMissingCoverageError extends Error {
    constructor(dir: string, err: Error);
}
/**
 * Handles mapping
 */
export declare class IstanbulCoverageContext {
    private readonly defaultOptions;
    constructor(defaultOptions?: Partial<IIstanbulCoverageOptions>);
    /**
     * Applies coverage written out to the given directory to the test run.
     * It expects Istanbul to have generated a "json" coverage format with the
     * directory containing a `coverage-final.json` file.
     * @throws IstanbulMissingCoverageError if the coverage file could not be read.
     */
    apply(run: vscode.TestRun, coverageDir: string, opts?: Partial<IIstanbulCoverageOptions>): Promise<void>;
    /**
     * Applies coverage from the Istanbul file format to the run.
     */
    applyJson(run: vscode.TestRun, files: Record<string, FileCoverageData>, opts?: Partial<IIstanbulCoverageOptions>): Promise<void>;
    /**
     * Assignable to vscode.TestRunProfile.loadDetailedCoverage
     */
    readonly loadDetailedCoverage: vscode.TestRunProfile['loadDetailedCoverage'];
}
