const VERSION = "21.1.0";
export {
  VERSION
};
